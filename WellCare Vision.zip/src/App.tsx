import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ContentBriefProvider } from "@/contexts/ContentBriefContext";
import Landing from "./pages/Landing";
import Auth from "./pages/Auth";
import Brands from "./pages/Brands";
import AddBrand from "./pages/AddBrand";
import BrandDashboard from "./pages/BrandDashboard";
import CompetitorProfile from "./pages/CompetitorProfile";
import ObservationsPage from "./pages/ObservationsPage";
import ContentLibraryPage from "./pages/ContentLibraryPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <ContentBriefProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/brands" element={<Brands />} />
              <Route path="/brands/add" element={<AddBrand />} />
              <Route path="/brand/:brandId" element={<BrandDashboard />} />
              <Route path="/brand/:brandId/observations" element={<ObservationsPage />} />
              <Route path="/brand/:brandId/content" element={<ContentLibraryPage />} />
              <Route path="/brand/:brandId/competitor/:competitorId" element={<CompetitorProfile />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </ContentBriefProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
