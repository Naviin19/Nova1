import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Eye, 
  BookOpen, 
  FileText, 
  BarChart3, 
  Settings,
  Sparkles,
  Building2,
  ChevronRight
} from "lucide-react";
import { motion } from "framer-motion";

interface NavItem {
  icon: React.ElementType;
  label: string;
  active?: boolean;
  badge?: string;
}

const navItems: NavItem[] = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: Eye, label: "Observation Hub", badge: "3" },
  { icon: BookOpen, label: "Visitor Stories" },
  { icon: FileText, label: "Content" },
  { icon: BarChart3, label: "Performance" },
  { icon: Building2, label: "Brand Book" },
  { icon: Settings, label: "Settings" },
];

export function Sidebar() {
  return (
    <motion.aside 
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.4 }}
      className="w-72 h-screen bg-sidebar border-r border-sidebar-border flex flex-col"
    >
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.4 }}
          className="flex items-center gap-3"
        >
          <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
            <Sparkles className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display text-xl tracking-wider text-foreground">NOVA</h1>
            <p className="text-xs text-muted-foreground tracking-wide">HEALTHCARE INTEL</p>
          </div>
        </motion.div>
      </div>

      {/* Brand Selector */}
      <div className="px-4 py-4 border-b border-sidebar-border">
        <button className="w-full flex items-center justify-between px-3 py-2 bg-sidebar-accent text-sidebar-foreground text-sm hover:bg-muted transition-colors">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-primary/20 flex items-center justify-center">
              <span className="text-xs font-bold text-primary">H</span>
            </div>
            <span>HealthTech Expo 2024</span>
          </div>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item, index) => (
          <motion.button
            key={item.label}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 * index, duration: 0.3 }}
            className={cn(
              "w-full flex items-center justify-between px-3 py-2.5 text-sm transition-all duration-200",
              item.active
                ? "bg-sidebar-accent text-foreground border-l-[3px] border-l-accent"
                : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-foreground border-l-[3px] border-l-transparent"
            )}
          >
            <div className="flex items-center gap-3">
              <item.icon className="w-4 h-4" />
              <span>{item.label}</span>
            </div>
            {item.badge && (
              <span className="px-2 py-0.5 text-xs bg-primary text-primary-foreground">
                {item.badge}
              </span>
            )}
          </motion.button>
        ))}
      </nav>

      {/* User Section */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-3 py-2">
          <div className="w-8 h-8 bg-healthcare-teal/20 flex items-center justify-center">
            <span className="text-xs font-bold text-healthcare-teal">NR</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-foreground truncate">Naviin R.</p>
            <p className="text-xs text-muted-foreground truncate">Marketing Lead</p>
          </div>
        </div>
      </div>
    </motion.aside>
  );
}