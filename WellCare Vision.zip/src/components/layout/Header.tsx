import { Bell, Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export function Header() {
  return (
    <motion.header 
      initial={{ y: -10, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.4 }}
      className="h-16 border-b border-border bg-background/80 backdrop-blur-sm flex items-center justify-between px-6"
    >
      <div className="flex items-center gap-4">
        <h2 className="font-display text-lg tracking-wide">DASHBOARD</h2>
        <span className="text-muted-foreground hidden md:inline">|</span>
        <span className="text-sm text-muted-foreground hidden md:inline">HealthTech Expo India 2024</span>
      </div>

      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input 
            type="text"
            placeholder="Search content..."
            className="w-64 h-9 pl-9 pr-4 bg-muted border-2 border-transparent text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none transition-colors"
          />
        </div>

        {/* Notifications */}
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-4 h-4" />
          <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary text-[10px] text-primary-foreground flex items-center justify-center">
            4
          </span>
        </Button>

        {/* Create Button */}
        <Button className="gap-2 font-display text-xs tracking-wide">
          <Plus className="w-4 h-4" />
          CREATE CONTENT
        </Button>
      </div>
    </motion.header>
  );
}