import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";

const data = [
  { day: "Mon", reach: 45, engagement: 28 },
  { day: "Tue", reach: 52, engagement: 35 },
  { day: "Wed", reach: 78, engagement: 42 },
  { day: "Thu", reach: 65, engagement: 38 },
  { day: "Fri", reach: 89, engagement: 55 },
  { day: "Sat", reach: 72, engagement: 48 },
  { day: "Sun", reach: 95, engagement: 62 },
];

const maxValue = 100;

export function PerformanceChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6, duration: 0.5 }}
      className="bg-card border border-border p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-display text-lg tracking-wide">REACH PERFORMANCE</h3>
          <p className="text-sm text-muted-foreground">Last 7 days · Primary metric</p>
        </div>
        <div className="flex items-center gap-2 text-success text-sm">
          <TrendingUp className="w-4 h-4" />
          <span>+23% vs last week</span>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-6 mb-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-primary" />
          <span className="text-xs text-muted-foreground">Reach</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-accent" />
          <span className="text-xs text-muted-foreground">Engagement</span>
        </div>
      </div>

      {/* Chart */}
      <div className="flex items-end gap-4 h-48">
        {data.map((item, index) => (
          <div key={item.day} className="flex-1 flex flex-col items-center gap-2">
            <div className="w-full flex items-end gap-1 h-40">
              {/* Reach bar */}
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${(item.reach / maxValue) * 100}%` }}
                transition={{ delay: 0.7 + index * 0.05, duration: 0.4 }}
                className="flex-1 bg-primary"
              />
              {/* Engagement bar */}
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${(item.engagement / maxValue) * 100}%` }}
                transition={{ delay: 0.75 + index * 0.05, duration: 0.4 }}
                className="flex-1 bg-accent"
              />
            </div>
            <span className="text-xs text-muted-foreground">{item.day}</span>
          </div>
        ))}
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-border">
        <div>
          <p className="text-2xl font-display text-foreground">496K</p>
          <p className="text-xs text-muted-foreground">Total Reach</p>
        </div>
        <div>
          <p className="text-2xl font-display text-foreground">5.2%</p>
          <p className="text-xs text-muted-foreground">Avg. Engagement</p>
        </div>
        <div>
          <p className="text-2xl font-display text-foreground">847</p>
          <p className="text-xs text-muted-foreground">Conversions</p>
        </div>
      </div>
    </motion.div>
  );
}