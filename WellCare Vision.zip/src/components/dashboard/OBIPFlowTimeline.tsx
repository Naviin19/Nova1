import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Eye, 
  Brain, 
  Lightbulb, 
  GitBranch, 
  Sparkles,
  FileText,
  Send,
  BarChart3,
  ChevronRight,
  TrendingUp,
  Users,
  Zap,
  CheckCircle2,
  Clock,
  Target
} from "lucide-react";
import { cn } from "@/lib/utils";

interface OBIPFlowItem {
  id: string;
  observationId: string;
  observationTitle: string;
  rawObservation: string;
  behavior: string;
  insight: string;
  pattern: string;
  sprinkle: string;
  contentBriefId?: string;
  contentTitle?: string;
  contentType?: "image" | "video" | "article";
  publishedAt?: string;
  status: "observation" | "brief" | "content" | "published" | "measured";
  metrics?: {
    impressions: string;
    engagement: string;
    conversions: number;
    roi: string;
  };
  createdAt: string;
}

// Mock timeline data
const timelineData: OBIPFlowItem[] = [
  {
    id: "flow-1",
    observationId: "obs-1",
    observationTitle: "Telemedicine Adoption Surge",
    rawObservation: "Post-pandemic video consultations have grown 340% and stabilized at 25% of total OPD visits",
    behavior: "Patients prefer video consultations for follow-ups and minor ailments",
    insight: "Convenience trumps traditional care preferences when quality is maintained",
    pattern: "Peak usage between 7-9 PM for working professionals",
    sprinkle: "Subvert expectations: Show the doctor who learned more from telemedicine than patients did",
    contentBriefId: "brief-1",
    contentTitle: "The Doctor Who Learned to Listen Again",
    contentType: "video",
    publishedAt: "Jan 15, 2024",
    status: "measured",
    metrics: {
      impressions: "245K",
      engagement: "5.1%",
      conversions: 89,
      roi: "4.2x"
    },
    createdAt: "Jan 10, 2024"
  },
  {
    id: "flow-2",
    observationId: "obs-2",
    observationTitle: "Corporate Insurance Growth",
    rawObservation: "Corporate health insurance coverage expanded 28% in the last year",
    behavior: "Employees actively comparing hospital networks before enrollment",
    insight: "Network breadth is the new quality signal for HR decision-makers",
    pattern: "Q1 sees highest insurance renewals and network additions",
    sprinkle: "Use specificity: Replace 'quality care' with actual outcome numbers that HR can present",
    contentBriefId: "brief-2",
    contentTitle: "What Your HR Doesn't Tell You About Hospital Networks",
    contentType: "article",
    publishedAt: "Jan 12, 2024",
    status: "measured",
    metrics: {
      impressions: "67K",
      engagement: "4.8%",
      conversions: 34,
      roi: "2.8x"
    },
    createdAt: "Jan 8, 2024"
  },
  {
    id: "flow-3",
    observationId: "obs-3",
    observationTitle: "Apollo AI Diagnostic Launch",
    rawObservation: "Launched AI-powered diagnostic center with 15-minute cancer screening",
    behavior: "Competitors are consolidating messaging around AI capabilities",
    insight: "AI is becoming a shortcut decision-making signal for buyers",
    pattern: "First-mover perception in AI diagnostics creates lasting competitive advantage",
    sprinkle: "Challenge assumptions: What if faster diagnosis isn't what patients actually need?",
    contentBriefId: "brief-3",
    contentTitle: "Speed vs. Certainty: The Diagnostic Dilemma",
    contentType: "image",
    status: "published",
    createdAt: "Jan 14, 2024"
  },
  {
    id: "flow-4",
    observationId: "obs-4",
    observationTitle: "Medical Tourism Inquiry Surge",
    rawObservation: "International patient inquiries up 45% from Middle East and Africa",
    behavior: "Patients researching online 6-8 weeks before travel",
    insight: "Trust is built through digital touchpoints before any physical interaction",
    pattern: "Cardiac and orthopedic procedures most sought after",
    sprinkle: "Personify the insight: Follow a patient's 8-week journey from Google to operating table",
    contentBriefId: "brief-4",
    contentTitle: "8 Weeks to Trust: A Medical Tourist's Journey",
    contentType: "video",
    status: "content",
    createdAt: "Jan 16, 2024"
  },
  {
    id: "flow-5",
    observationId: "obs-5",
    observationTitle: "Nurse Burnout Documentation",
    rawObservation: "Nursing administrators increasingly documenting burnout metrics as compliance risk",
    behavior: "Head nurses collecting data on shift coverage and overtime for Joint Commission",
    insight: "Burnout is being reframed as regulatory risk to unlock budget",
    pattern: "Hospitals presenting burnout as compliance risk secured 40% more FTE additions",
    sprinkle: "Embrace vulnerability: Show the real numbers your hospital doesn't want to share",
    status: "brief",
    createdAt: "Jan 17, 2024"
  },
  {
    id: "flow-6",
    observationId: "obs-6",
    observationTitle: "CMO Data Consumption Shift",
    rawObservation: "CMOs at teaching hospitals review clinical dashboards 4x more frequently",
    behavior: "Building personal data narratives connecting patient outcomes to equipment requests",
    insight: "They're curating evidence—every metric is ammunition for capital requests",
    pattern: "CMOs who present data stories are 2.5x more likely to secure equipment budgets",
    sprinkle: "",
    status: "observation",
    createdAt: "Jan 18, 2024"
  }
];

const statusConfig = {
  observation: { 
    label: "Observation", 
    icon: Eye, 
    color: "text-healthcare-teal", 
    bg: "bg-healthcare-teal/10",
    border: "border-healthcare-teal"
  },
  brief: { 
    label: "Brief Created", 
    icon: FileText, 
    color: "text-healthcare-navy", 
    bg: "bg-healthcare-navy/10",
    border: "border-healthcare-navy"
  },
  content: { 
    label: "Content Ready", 
    icon: Sparkles, 
    color: "text-primary", 
    bg: "bg-primary/10",
    border: "border-primary"
  },
  published: { 
    label: "Published", 
    icon: Send, 
    color: "text-accent", 
    bg: "bg-accent/10",
    border: "border-accent"
  },
  measured: { 
    label: "Measured", 
    icon: BarChart3, 
    color: "text-success", 
    bg: "bg-success/10",
    border: "border-success"
  }
};

const stageOrder = ["observation", "brief", "content", "published", "measured"];

export function OBIPFlowTimeline() {
  const [selectedItem, setSelectedItem] = useState<OBIPFlowItem | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const filteredData = filterStatus === "all" 
    ? timelineData 
    : timelineData.filter(item => item.status === filterStatus);

  // Conversion metrics
  const observationCount = timelineData.length;
  const briefCount = timelineData.filter(i => stageOrder.indexOf(i.status) >= 1).length;
  const contentCount = timelineData.filter(i => stageOrder.indexOf(i.status) >= 2).length;
  const publishedCount = timelineData.filter(i => stageOrder.indexOf(i.status) >= 3).length;
  const measuredCount = timelineData.filter(i => i.status === "measured").length;

  const conversionRates = {
    obsToBrief: ((briefCount / observationCount) * 100).toFixed(0),
    briefToContent: briefCount > 0 ? ((contentCount / briefCount) * 100).toFixed(0) : "0",
    contentToPublish: contentCount > 0 ? ((publishedCount / contentCount) * 100).toFixed(0) : "0",
    avgROI: timelineData
      .filter(i => i.metrics?.roi)
      .reduce((acc, i) => acc + parseFloat(i.metrics!.roi), 0) / measuredCount || 0
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-xl overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-healthcare-teal/20 to-primary/20 flex items-center justify-center rounded-lg">
              <GitBranch className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-display text-lg tracking-wide">OBIP FLOW TIMELINE</h3>
              <p className="text-sm text-muted-foreground">Observation → Content → Results</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">Avg ROI:</span>
            <span className="font-display text-primary">{conversionRates.avgROI.toFixed(1)}x</span>
          </div>
        </div>

        {/* Conversion Funnel */}
        <div className="bg-muted/30 rounded-lg p-4 border border-border">
          <div className="flex items-center justify-between">
            {[
              { stage: "Observations", count: observationCount, icon: Eye, rate: null },
              { stage: "Briefs", count: briefCount, icon: FileText, rate: conversionRates.obsToBrief },
              { stage: "Content", count: contentCount, icon: Sparkles, rate: conversionRates.briefToContent },
              { stage: "Published", count: publishedCount, icon: Send, rate: conversionRates.contentToPublish },
              { stage: "Measured", count: measuredCount, icon: BarChart3, rate: null },
            ].map((item, index, arr) => (
              <div key={item.stage} className="flex items-center">
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto mb-2 bg-card border border-border rounded-lg flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <p className="font-display text-xl">{item.count}</p>
                  <p className="text-xs text-muted-foreground">{item.stage}</p>
                </div>
                {index < arr.length - 1 && (
                  <div className="mx-3 flex flex-col items-center">
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    {item.rate && (
                      <span className="text-xs text-primary font-medium">{item.rate}%</span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-6 py-3 border-b border-border flex items-center gap-2 overflow-x-auto">
        <button
          onClick={() => setFilterStatus("all")}
          className={cn(
            "px-3 py-1.5 text-xs font-display tracking-wide rounded-lg transition-all whitespace-nowrap",
            filterStatus === "all" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
          )}
        >
          All ({timelineData.length})
        </button>
        {Object.entries(statusConfig).map(([key, config]) => {
          const count = timelineData.filter(i => i.status === key).length;
          return (
            <button
              key={key}
              onClick={() => setFilterStatus(key)}
              className={cn(
                "px-3 py-1.5 text-xs font-display tracking-wide rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap",
                filterStatus === key ? `${config.bg} ${config.color}` : "bg-muted text-muted-foreground hover:text-foreground"
              )}
            >
              <config.icon className="w-3 h-3" />
              {config.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Timeline */}
      <div className="p-6 max-h-[500px] overflow-y-auto">
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 top-0 bottom-0 w-px bg-border" />

          <div className="space-y-4">
            {filteredData.map((item, index) => {
              const config = statusConfig[item.status];
              const stageIndex = stageOrder.indexOf(item.status);
              
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="relative pl-14"
                >
                  {/* Stage indicator */}
                  <div className={cn(
                    "absolute left-3 w-6 h-6 rounded-full flex items-center justify-center border-2",
                    config.bg, config.border
                  )}>
                    <config.icon className={cn("w-3 h-3", config.color)} />
                  </div>

                  {/* Content card */}
                  <button
                    onClick={() => setSelectedItem(selectedItem?.id === item.id ? null : item)}
                    className={cn(
                      "w-full text-left p-4 rounded-lg border transition-all",
                      selectedItem?.id === item.id 
                        ? "border-primary bg-primary/5" 
                        : "border-border hover:border-primary/50 bg-card"
                    )}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-sm">{item.observationTitle}</p>
                        {item.contentTitle && (
                          <p className="text-xs text-primary mt-1">→ {item.contentTitle}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {item.contentType && (
                          <span className="text-[10px] px-2 py-0.5 bg-muted rounded-full capitalize">
                            {item.contentType}
                          </span>
                        )}
                        <span className={cn("text-[10px] px-2 py-0.5 rounded-full", config.bg, config.color)}>
                          {config.label}
                        </span>
                      </div>
                    </div>

                    {/* Progress bar */}
                    <div className="flex gap-1 mb-2">
                      {stageOrder.map((stage, i) => (
                        <div 
                          key={stage}
                          className={cn(
                            "h-1 flex-1 rounded-full",
                            i <= stageIndex ? "bg-primary" : "bg-muted"
                          )}
                        />
                      ))}
                    </div>

                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {item.createdAt}
                      </span>
                      {item.metrics && (
                        <span className="flex items-center gap-1 text-success">
                          <TrendingUp className="w-3 h-3" />
                          {item.metrics.roi} ROI
                        </span>
                      )}
                    </div>
                  </button>

                  {/* Expanded details */}
                  <AnimatePresence>
                    {selectedItem?.id === item.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-2 ml-0 overflow-hidden"
                      >
                        <div className="p-4 bg-muted/30 rounded-lg border border-border space-y-4">
                          {/* OBIP Flow */}
                          <div className="grid grid-cols-2 gap-3">
                            {[
                              { icon: Eye, label: "Observation", value: item.rawObservation, color: "healthcare-teal" },
                              { icon: Brain, label: "Behavior", value: item.behavior, color: "healthcare-navy" },
                              { icon: Lightbulb, label: "Insight", value: item.insight, color: "primary" },
                              { icon: GitBranch, label: "Pattern", value: item.pattern, color: "accent" },
                            ].map((step) => (
                              <div key={step.label} className={`p-3 bg-${step.color}/5 border-l-2 border-l-${step.color} rounded-r-lg`}>
                                <div className="flex items-center gap-1.5 mb-1">
                                  <step.icon className={`w-3 h-3 text-${step.color}`} />
                                  <span className="text-[10px] font-display tracking-wide">{step.label}</span>
                                </div>
                                <p className="text-xs text-muted-foreground line-clamp-2">{step.value}</p>
                              </div>
                            ))}
                          </div>

                          {/* Sprinkle */}
                          {item.sprinkle && (
                            <div className="p-3 bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg border border-primary/20">
                              <div className="flex items-center gap-1.5 mb-1">
                                <Zap className="w-3 h-3 text-primary" />
                                <span className="text-[10px] font-display tracking-wide text-primary">THE SPRINKLE</span>
                              </div>
                              <p className="text-xs text-foreground">{item.sprinkle}</p>
                            </div>
                          )}

                          {/* Metrics */}
                          {item.metrics && (
                            <div className="grid grid-cols-4 gap-2">
                              {[
                                { label: "Impressions", value: item.metrics.impressions, icon: Users },
                                { label: "Engagement", value: item.metrics.engagement, icon: Target },
                                { label: "Conversions", value: item.metrics.conversions.toString(), icon: CheckCircle2 },
                                { label: "ROI", value: item.metrics.roi, icon: TrendingUp },
                              ].map((metric) => (
                                <div key={metric.label} className="text-center p-2 bg-card rounded-lg border border-border">
                                  <metric.icon className="w-4 h-4 mx-auto mb-1 text-primary" />
                                  <p className="font-display text-sm">{metric.value}</p>
                                  <p className="text-[10px] text-muted-foreground">{metric.label}</p>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
