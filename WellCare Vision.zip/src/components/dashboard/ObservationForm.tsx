import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Eye, 
  Brain, 
  Lightbulb, 
  GitBranch, 
  Sparkles,
  X,
  Save,
  ChevronRight,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ObservationFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (observation: ObservationData) => void;
}

export interface ObservationData {
  id: string;
  type: "customer" | "competition" | "market";
  title: string;
  rawObservation: string;
  behavior: string;
  insight: string;
  pattern: string;
  source: string;
  importance: "high" | "medium" | "low";
  tags: string[];
  createdAt: string;
}

const steps = [
  { id: "observation", label: "Observation", icon: Eye, desc: "What did you see?" },
  { id: "behavior", label: "Behavior", icon: Brain, desc: "What are they doing?" },
  { id: "insight", label: "Insight", icon: Lightbulb, desc: "Why are they doing it?" },
  { id: "pattern", label: "Pattern", icon: GitBranch, desc: "What does it mean?" },
];

const typeOptions = [
  { id: "customer", label: "Customer Intel", color: "bg-healthcare-teal" },
  { id: "competition", label: "Competitor Intel", color: "bg-warning" },
  { id: "market", label: "Market Intel", color: "bg-healthcare-sky" },
];

export function ObservationForm({ isOpen, onClose, onSave }: ObservationFormProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    type: "customer" as "customer" | "competition" | "market",
    title: "",
    rawObservation: "",
    behavior: "",
    insight: "",
    pattern: "",
    source: "",
    importance: "medium" as "high" | "medium" | "low",
    tags: [] as string[],
  });
  const [tagInput, setTagInput] = useState("");

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSave = () => {
    const observation: ObservationData = {
      id: `obs-${Date.now()}`,
      ...formData,
      createdAt: new Date().toISOString(),
    };
    onSave(observation);
    handleReset();
  };

  const handleReset = () => {
    setCurrentStep(0);
    setFormData({
      type: "customer",
      title: "",
      rawObservation: "",
      behavior: "",
      insight: "",
      pattern: "",
      source: "",
      importance: "medium",
      tags: [],
    });
    setTagInput("");
    onClose();
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({ ...formData, tags: [...formData.tags, tagInput.trim()] });
      setTagInput("");
    }
  };

  const removeTag = (tag: string) => {
    setFormData({ ...formData, tags: formData.tags.filter(t => t !== tag) });
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0: return formData.rawObservation.trim().length > 10;
      case 1: return formData.behavior.trim().length > 10;
      case 2: return formData.insight.trim().length > 10;
      case 3: return formData.pattern.trim().length > 10;
      default: return false;
    }
  };

  const canSubmit = () => {
    return formData.title.trim() && 
           formData.rawObservation.trim() && 
           formData.behavior.trim() && 
           formData.insight.trim() && 
           formData.pattern.trim();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={handleReset}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-3xl bg-card border border-border rounded-xl overflow-hidden max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-6 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 flex items-center justify-center rounded-lg">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-display text-xl tracking-wide">NEW OBSERVATION</h2>
                <p className="text-sm text-muted-foreground">Document the O-B-I-P flow</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={handleReset}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Progress Steps */}
          <div className="px-6 py-4 bg-muted/30 border-b border-border">
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <button
                    onClick={() => setCurrentStep(index)}
                    className={cn(
                      "flex flex-col items-center gap-2 transition-all",
                      currentStep >= index ? "opacity-100" : "opacity-40"
                    )}
                  >
                    <div className={cn(
                      "w-12 h-12 rounded-lg flex items-center justify-center border-2 transition-colors",
                      currentStep === index 
                        ? "border-primary bg-primary/10" 
                        : currentStep > index 
                          ? "border-primary/50 bg-primary/5"
                          : "border-border bg-muted"
                    )}>
                      <step.icon className={cn(
                        "w-5 h-5",
                        currentStep >= index ? "text-primary" : "text-muted-foreground"
                      )} />
                    </div>
                    <span className="text-xs font-medium">{step.label}</span>
                  </button>
                  {index < steps.length - 1 && (
                    <ChevronRight className="w-4 h-4 text-muted-foreground mx-2" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Form Content */}
          <div className="p-6 flex-1 overflow-y-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {/* Title & Type (always visible) */}
                {currentStep === 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Title</label>
                      <input
                        type="text"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder="Brief title for this observation..."
                        className="w-full h-10 px-4 bg-muted border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Type</label>
                      <div className="flex gap-2">
                        {typeOptions.map((type) => (
                          <button
                            key={type.id}
                            onClick={() => setFormData({ ...formData, type: type.id as typeof formData.type })}
                            className={cn(
                              "flex-1 py-2 px-3 text-xs font-medium rounded-lg border-2 transition-all",
                              formData.type === type.id
                                ? "border-primary bg-primary/10"
                                : "border-border hover:border-primary/50"
                            )}
                          >
                            <div className={cn("w-2 h-2 rounded-full mx-auto mb-1", type.color)} />
                            {type.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Step-specific content */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium mb-2">
                    {(() => {
                      const StepIcon = steps[currentStep].icon;
                      return <StepIcon className="w-4 h-4 text-primary" />;
                    })()}
                    {steps[currentStep].label}
                    <span className="text-muted-foreground font-normal">— {steps[currentStep].desc}</span>
                  </label>
                  <textarea
                    value={
                      currentStep === 0 ? formData.rawObservation :
                      currentStep === 1 ? formData.behavior :
                      currentStep === 2 ? formData.insight :
                      formData.pattern
                    }
                    onChange={(e) => {
                      const field = currentStep === 0 ? 'rawObservation' :
                                    currentStep === 1 ? 'behavior' :
                                    currentStep === 2 ? 'insight' : 'pattern';
                      setFormData({ ...formData, [field]: e.target.value });
                    }}
                    placeholder={
                      currentStep === 0 ? "What raw signal or data point did you observe? Be specific and factual..." :
                      currentStep === 1 ? "What behavior or action is happening as a result? What are people doing?" :
                      currentStep === 2 ? "Why is this happening? What's the underlying motivation or cause?" :
                      "What broader pattern does this reveal? How can we leverage this?"
                    }
                    rows={5}
                    className="w-full p-4 bg-muted border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                  />
                </div>

                {/* Source & Importance (on last step) */}
                {currentStep === 3 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Source</label>
                      <input
                        type="text"
                        value={formData.source}
                        onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                        placeholder="Where did this come from?"
                        className="w-full h-10 px-4 bg-muted border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Importance</label>
                      <div className="flex gap-2">
                        {["low", "medium", "high"].map((level) => (
                          <button
                            key={level}
                            onClick={() => setFormData({ ...formData, importance: level as typeof formData.importance })}
                            className={cn(
                              "flex-1 py-2 px-3 text-xs font-medium rounded-lg border-2 transition-all capitalize",
                              formData.importance === level
                                ? level === "high" 
                                  ? "border-error bg-error/10 text-error"
                                  : level === "medium"
                                    ? "border-warning bg-warning/10 text-warning"
                                    : "border-primary bg-primary/10 text-primary"
                                : "border-border hover:border-primary/50"
                            )}
                          >
                            {level}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-2">Tags</label>
                      <div className="flex gap-2 mb-2 flex-wrap">
                        {formData.tags.map((tag) => (
                          <span 
                            key={tag} 
                            className="px-2 py-1 text-xs bg-primary/10 text-primary rounded-full flex items-center gap-1"
                          >
                            {tag}
                            <button onClick={() => removeTag(tag)} className="hover:text-error">
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={tagInput}
                          onChange={(e) => setTagInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                          placeholder="Add tags..."
                          className="flex-1 h-10 px-4 bg-muted border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                        />
                        <Button variant="outline" onClick={addTag}>Add</Button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Validation hint */}
                {!isStepValid() && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <AlertCircle className="w-4 h-4" />
                    <span>Please provide at least 10 characters for this step</span>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-border flex items-center justify-between">
            <Button variant="ghost" onClick={currentStep === 0 ? handleReset : handleBack}>
              {currentStep === 0 ? "Cancel" : "Back"}
            </Button>
            <div className="flex gap-2">
              {currentStep < steps.length - 1 ? (
                <Button onClick={handleNext} disabled={!isStepValid()}>
                  Next <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              ) : (
                <Button onClick={handleSave} disabled={!canSubmit()}>
                  <Save className="w-4 h-4 mr-2" /> Save Observation
                </Button>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
