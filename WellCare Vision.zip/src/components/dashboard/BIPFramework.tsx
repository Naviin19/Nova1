import { motion } from "framer-motion";
import { Lightbulb, ArrowRight, Sparkles } from "lucide-react";
export function BIPFramework() {
  const steps = [{
    label: "Observation",
    description: "Capture authentic brand moments"
  }, {
    label: "OBIP",
    description: "One Big Idea + Persona"
  }, {
    label: "Sprinkle",
    description: "Add emotional storytelling"
  }, {
    label: "Content",
    description: "Generate platform-ready assets"
  }];
  return;
}