import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  Image as ImageIcon, 
  Video,
  Instagram,
  Linkedin,
  Twitter,
  Mail,
  Youtube,
  Copy,
  Check,
  Download,
  ChevronDown,
  Palette,
  Type,
  Layout,
  BarChart3,
  Eye,
  FileJson
} from "lucide-react";

interface Story {
  behavior: string;
  insight: string;
  pattern: string;
  sprinkle: string;
}

interface ContentOutput {
  type: "image" | "video";
  platform: string;
  prompt: string;
  jsonStructure: {
    contentType: string;
    dimensions: string;
    style: {
      colorPalette: string[];
      typography: string;
      mood: string;
    };
    elements: {
      headline: string;
      subheadline: string;
      cta: string;
      visualDescription: string;
    };
    measurement: {
      primaryKPI: string;
      secondaryKPIs: string[];
      targetBenchmark: string;
      trackingParams: string[];
    };
  };
}

const platforms = [
  { id: "instagram", label: "Instagram", icon: Instagram, formats: ["Post", "Story", "Reel", "Carousel"] },
  { id: "linkedin", label: "LinkedIn", icon: Linkedin, formats: ["Post", "Article", "Carousel"] },
  { id: "twitter", label: "Twitter/X", icon: Twitter, formats: ["Tweet", "Thread"] },
  { id: "email", label: "Email", icon: Mail, formats: ["Newsletter", "Drip Campaign"] },
  { id: "youtube", label: "YouTube", icon: Youtube, formats: ["Short", "Video"] },
];

const contentStyles = [
  { id: "professional", label: "Professional", description: "Clean, corporate aesthetic" },
  { id: "bold", label: "Bold & Modern", description: "High contrast, striking visuals" },
  { id: "warm", label: "Warm & Empathetic", description: "Soft tones, human-centered" },
  { id: "data-driven", label: "Data-Driven", description: "Charts, stats, infographics" },
];

interface StoryToContentGeneratorProps {
  story?: Story;
}

export function StoryToContentGenerator({ story }: StoryToContentGeneratorProps) {
  const [contentType, setContentType] = useState<"image" | "video">("image");
  const [selectedPlatform, setSelectedPlatform] = useState<string>("linkedin");
  const [selectedFormat, setSelectedFormat] = useState<string>("Carousel");
  const [selectedStyle, setSelectedStyle] = useState<string>("professional");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<ContentOutput | null>(null);
  const [copied, setCopied] = useState<"prompt" | "json" | null>(null);
  const [showJson, setShowJson] = useState(false);

  const defaultStory: Story = {
    behavior: "Hospital procurement directors spend 2-3x more time on pre-event research, downloading whitepapers and case studies before committing to booth visits.",
    insight: "The buying journey has fundamentally shifted left—decisions are being influenced long before the handshake at the booth.",
    pattern: "Mid-size hospitals (200-500 beds) face tighter budgets and more scrutiny, making pre-qualification essential.",
    sprinkle: "\"Last quarter's sepsis protocol didn't just save 12 lives—it saved $2.4M in extended ICU stays.\""
  };

  const currentStory = story || defaultStory;
  const currentPlatform = platforms.find(p => p.id === selectedPlatform);

  const handleGenerate = () => {
    setIsGenerating(true);
    
    setTimeout(() => {
      const output: ContentOutput = {
        type: contentType,
        platform: selectedPlatform,
        prompt: `Create a ${selectedFormat.toLowerCase()} for ${currentPlatform?.label} that captures the following insight: "${currentStory.insight}"

Visual Direction:
- Style: ${contentStyles.find(s => s.id === selectedStyle)?.label} with ${contentStyles.find(s => s.id === selectedStyle)?.description}
- Lead with the sprinkle quote: ${currentStory.sprinkle}
- Use healthcare-appropriate imagery: hospital settings, medical professionals, patient care moments
- Color palette: Teal (#14b8a6), Navy (#1e293b), with accent orange highlights
- Typography: Clean sans-serif headlines, readable body text

Content Structure:
- Hook: Open with the surprising statistic or quote
- Problem: Visualize the pattern (${currentStory.pattern.substring(0, 100)}...)
- Insight: The "aha" moment - why this matters
- Solution: Position your offering as the answer
- CTA: Clear next step for the viewer

Format Specifications:
- ${selectedFormat} format optimized for ${currentPlatform?.label}
- ${contentType === "video" ? "Motion graphics with subtle animations, 15-30 seconds" : "Static or carousel with visual hierarchy"}
- Mobile-first design consideration`,
        jsonStructure: {
          contentType: `${currentPlatform?.label} ${selectedFormat}`,
          dimensions: selectedPlatform === "instagram" && selectedFormat === "Story" 
            ? "1080x1920" 
            : selectedPlatform === "instagram" 
              ? "1080x1080" 
              : "1200x627",
          style: {
            colorPalette: ["#14b8a6", "#1e293b", "#f97316", "#ffffff"],
            typography: "Inter for body, Space Grotesk for headlines",
            mood: contentStyles.find(s => s.id === selectedStyle)?.label || "Professional"
          },
          elements: {
            headline: "The Buying Journey Has Shifted Left",
            subheadline: "78% of hospital buyers now require ROI proof before booth visit",
            cta: "Download the Pre-Event Playbook",
            visualDescription: "Split-screen showing traditional booth interaction vs. digital pre-research, with data overlay showing the 78% statistic"
          },
          measurement: {
            primaryKPI: "Engagement Rate",
            secondaryKPIs: ["Reach", "Saves", "Profile Visits", "Link Clicks"],
            targetBenchmark: selectedPlatform === "linkedin" ? "4.5% engagement" : "5.2% engagement",
            trackingParams: [
              "utm_source=" + selectedPlatform,
              "utm_medium=organic",
              "utm_campaign=hospital_procurement_q1",
              "utm_content=" + selectedFormat.toLowerCase()
            ]
          }
        }
      };
      
      setGeneratedContent(output);
      setIsGenerating(false);
    }, 2500);
  };

  const handleCopy = (type: "prompt" | "json") => {
    if (!generatedContent) return;
    const text = type === "prompt" 
      ? generatedContent.prompt 
      : JSON.stringify(generatedContent.jsonStructure, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 border-b border-border bg-gradient-to-r from-accent/10 to-primary/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-accent flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h2 className="font-display text-lg tracking-wide">STORY TO CONTENT</h2>
            <p className="text-xs text-muted-foreground">Transform your visitor story into platform-ready content</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Story Preview */}
        <div className="mb-6 p-4 bg-muted/30 border border-border">
          <p className="text-xs text-muted-foreground mb-2">SOURCE STORY</p>
          <p className="text-sm italic text-foreground">{currentStory.sprinkle}</p>
        </div>

        {/* Content Type Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-3">Content Type</label>
          <div className="flex gap-3">
            <button
              onClick={() => setContentType("image")}
              className={`flex-1 p-4 border flex flex-col items-center gap-2 transition-all ${
                contentType === "image" ? "border-primary bg-primary/10" : "border-border hover:border-muted-foreground"
              }`}
            >
              <ImageIcon className={`w-6 h-6 ${contentType === "image" ? "text-primary" : "text-muted-foreground"}`} />
              <span className="text-sm font-medium">Static Image</span>
              <span className="text-xs text-muted-foreground">Posts, carousels, graphics</span>
            </button>
            <button
              onClick={() => setContentType("video")}
              className={`flex-1 p-4 border flex flex-col items-center gap-2 transition-all ${
                contentType === "video" ? "border-primary bg-primary/10" : "border-border hover:border-muted-foreground"
              }`}
            >
              <Video className={`w-6 h-6 ${contentType === "video" ? "text-primary" : "text-muted-foreground"}`} />
              <span className="text-sm font-medium">Video Content</span>
              <span className="text-xs text-muted-foreground">Reels, shorts, animations</span>
            </button>
          </div>
        </div>

        {/* Platform Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-3">Target Platform</label>
          <div className="flex flex-wrap gap-2">
            {platforms.map((platform) => (
              <button
                key={platform.id}
                onClick={() => {
                  setSelectedPlatform(platform.id);
                  setSelectedFormat(platform.formats[0]);
                }}
                className={`flex items-center gap-2 px-3 py-2 border transition-all ${
                  selectedPlatform === platform.id 
                    ? "border-primary bg-primary/10" 
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <platform.icon className={`w-4 h-4 ${selectedPlatform === platform.id ? "text-primary" : "text-muted-foreground"}`} />
                <span className="text-sm">{platform.label}</span>
              </button>
            ))}
          </div>
          
          {/* Format Selection */}
          {currentPlatform && (
            <div className="mt-3 flex gap-2">
              {currentPlatform.formats.map((format) => (
                <button
                  key={format}
                  onClick={() => setSelectedFormat(format)}
                  className={`px-3 py-1 text-xs font-display tracking-wide transition-all ${
                    selectedFormat === format 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {format}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Style Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-3">Visual Style</label>
          <div className="grid grid-cols-2 gap-3">
            {contentStyles.map((style) => (
              <button
                key={style.id}
                onClick={() => setSelectedStyle(style.id)}
                className={`p-3 border text-left transition-all ${
                  selectedStyle === style.id 
                    ? "border-primary bg-primary/10" 
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <span className="text-sm font-medium block">{style.label}</span>
                <span className="text-xs text-muted-foreground">{style.description}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Generate Button */}
        <Button 
          onClick={handleGenerate} 
          disabled={isGenerating}
          className="w-full mb-6"
          size="lg"
        >
          {isGenerating ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full mr-2"
              />
              Generating Content Brief...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" /> Generate Content Brief
            </>
          )}
        </Button>

        {/* Generated Output */}
        <AnimatePresence>
          {generatedContent && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-4"
            >
              {/* Prompt Output */}
              <div className="border border-border">
                <div className="flex items-center justify-between p-3 bg-muted/30 border-b border-border">
                  <div className="flex items-center gap-2">
                    <Type className="w-4 h-4 text-primary" />
                    <span className="font-display text-sm tracking-wide">CONTENT PROMPT</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => handleCopy("prompt")}>
                    {copied === "prompt" ? (
                      <><Check className="w-3 h-3 mr-1 text-success" /> Copied</>
                    ) : (
                      <><Copy className="w-3 h-3 mr-1" /> Copy</>
                    )}
                  </Button>
                </div>
                <div className="p-4 max-h-48 overflow-y-auto">
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{generatedContent.prompt}</p>
                </div>
              </div>

              {/* JSON Structure */}
              <div className="border border-border">
                <button
                  onClick={() => setShowJson(!showJson)}
                  className="w-full flex items-center justify-between p-3 bg-muted/30 border-b border-border hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <FileJson className="w-4 h-4 text-accent" />
                    <span className="font-display text-sm tracking-wide">CONTENT STRUCTURE (JSON)</span>
                  </div>
                  <ChevronDown className={`w-4 h-4 transition-transform ${showJson ? "rotate-180" : ""}`} />
                </button>
                
                <AnimatePresence>
                  {showJson && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: "auto" }}
                      exit={{ height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="p-4 bg-background">
                        <div className="flex justify-end mb-2">
                          <Button variant="ghost" size="sm" onClick={() => handleCopy("json")}>
                            {copied === "json" ? (
                              <><Check className="w-3 h-3 mr-1 text-success" /> Copied</>
                            ) : (
                              <><Copy className="w-3 h-3 mr-1" /> Copy JSON</>
                            )}
                          </Button>
                        </div>
                        <pre className="text-xs text-muted-foreground overflow-x-auto p-3 bg-muted/30 border border-border">
                          {JSON.stringify(generatedContent.jsonStructure, null, 2)}
                        </pre>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Quick Preview Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { icon: Layout, label: "Format", value: generatedContent.jsonStructure.contentType },
                  { icon: Palette, label: "Style", value: generatedContent.jsonStructure.style.mood },
                  { icon: Eye, label: "Primary KPI", value: generatedContent.jsonStructure.measurement.primaryKPI },
                  { icon: BarChart3, label: "Target", value: generatedContent.jsonStructure.measurement.targetBenchmark },
                ].map((item) => (
                  <div key={item.label} className="p-3 bg-muted/30 border border-border">
                    <item.icon className="w-4 h-4 text-muted-foreground mb-2" />
                    <p className="text-xs text-muted-foreground">{item.label}</p>
                    <p className="text-sm font-medium truncate">{item.value}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
