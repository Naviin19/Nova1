import { useState } from "react";
import { motion } from "framer-motion";
import { PenTool, Send, BarChart3, Lightbulb, ArrowRight, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";
const stages = [{
  id: "create",
  icon: PenTool,
  label: "Create",
  count: 12,
  description: "Stories ready",
  color: "from-teal-500 to-teal-600"
}, {
  id: "publish",
  icon: Send,
  label: "Publish",
  count: 8,
  description: "Content live",
  color: "from-sky-500 to-sky-600"
}, {
  id: "measure",
  icon: BarChart3,
  label: "Measure",
  count: "847K",
  description: "Total reach",
  color: "from-violet-500 to-violet-600"
}, {
  id: "learn",
  icon: Lightbulb,
  label: "Learn",
  count: 15,
  description: "Insights found",
  color: "from-amber-500 to-amber-600"
}];
interface ContentFlywheelProps {
  onStageClick?: (stageId: string) => void;
  activeStage?: string;
}
export function ContentFlywheel({
  onStageClick,
  activeStage
}: ContentFlywheelProps) {
  const [hoveredStage, setHoveredStage] = useState<string | null>(null);
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    delay: 0.3,
    duration: 0.5
  }} className="bg-card border border-border rounded-xl overflow-hidden">
      {/* Header */}
      

      
    </motion.div>;
}