import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  User, 
  Lightbulb, 
  ChevronRight,
  Check,
  BookOpen,
  ArrowRight
} from "lucide-react";

interface Persona {
  id: string;
  label: string;
  icon: string;
  description: string;
}

interface Insight {
  id: string;
  title: string;
  description: string;
  source: string;
}

const personas: Persona[] = [
  { id: "cmo", label: "Chief Medical Officer", icon: "🏥", description: "Clinical leadership, patient outcomes focus" },
  { id: "procurement", label: "Procurement Director", icon: "📋", description: "Cost optimization, vendor management" },
  { id: "cio", label: "Healthcare CIO", icon: "💻", description: "Technology strategy, security focus" },
  { id: "nurse", label: "Nursing Administrator", icon: "👩‍⚕️", description: "Staff management, patient care quality" },
  { id: "ceo", label: "Hospital CEO", icon: "👔", description: "Strategic vision, reputation management" },
  { id: "clinical-ops", label: "Clinical Ops Manager", icon: "⚙️", description: "Operational efficiency, workflow optimization" },
];

const personaInsights: Record<string, Insight[]> = {
  cmo: [
    { id: "1", title: "ROI Evidence Demand", description: "78% of CMOs now require documented ROI before approving new equipment purchases", source: "ARCHER Research" },
    { id: "2", title: "Outcome Dashboard Obsession", description: "CMOs spend 3+ hours weekly cross-referencing patient satisfaction with clinical outcomes", source: "Executive Survey" },
    { id: "3", title: "Board Presentation Prep", description: "Every metric collected becomes ammunition for quarterly capital requests", source: "Leadership Interviews" },
  ],
  procurement: [
    { id: "1", title: "Risk Over Cost", description: "Willing to pay 15-20% premium for suppliers with proven stability and redundancy", source: "Procurement Trends" },
    { id: "2", title: "Supplier Red Flags", description: "Maintains personal documents logging delivery delays and quality issues", source: "Behavior Analysis" },
    { id: "3", title: "Peace of Mind Premium", description: "Budget supplier failures led to $80K+ in emergency costs, changing buying criteria", source: "Case Studies" },
  ],
  cio: [
    { id: "1", title: "Peer Network Intelligence", description: "Private WhatsApp groups with other CIOs provide faster threat alerts than vendors", source: "CIO Roundtable" },
    { id: "2", title: "Real-Time Security Monitoring", description: "Keeps cybersecurity news, EHR status, and peer channels permanently open", source: "Workflow Analysis" },
    { id: "3", title: "Vendor Skepticism", description: "$500K security audits tell them what they already know; peer intel prevents breaches", source: "Executive Interviews" },
  ],
  nurse: [
    { id: "1", title: "Burnout as Compliance Risk", description: "Reframing staff wellbeing as audit failure probability finally unlocks budget", source: "HR Analytics" },
    { id: "2", title: "Systematic Documentation", description: "Screenshots every staffing complaint for weekly HR and leadership meetings", source: "Behavior Study" },
    { id: "3", title: "Translation Strategy", description: "Stopped saying 'exhausted' in meetings; now uses 'medication error risk increases 34%'", source: "Direct Interviews" },
  ],
  ceo: [
    { id: "1", title: "Reputation Obsession", description: "Reviews Google reviews every Sunday evening, flags 1-star wait time complaints", source: "Executive Habits" },
    { id: "2", title: "Consumer-Driven Choices", description: "Patient decisions increasingly driven by online sentiment, not physician referrals", source: "Market Research" },
    { id: "3", title: "Experience Over Aesthetics", description: "$2M lobby renovation moved NPS less than a coffee cart in the waiting room", source: "Patient Surveys" },
  ],
  "clinical-ops": [
    { id: "1", title: "Workflow Bottleneck Focus", description: "Spends first hour daily reviewing previous day's OR turnaround times", source: "Operations Data" },
    { id: "2", title: "Staff Utilization Metrics", description: "Tracks individual clinician productivity but presents as team metrics to avoid conflict", source: "Leadership Study" },
    { id: "3", title: "Process Improvement ROI", description: "Quantifies every improvement in minutes saved × hourly rate × annual volume", source: "Financial Analysis" },
  ],
};

const mockStory = {
  behavior: "Dr. Sarah Chen reviews clinical outcome dashboards for 3+ hours weekly, often during early morning hours before rounds. She cross-references patient satisfaction scores with readmission rates, building a comprehensive data narrative.",
  insight: "She's not just tracking metrics—she's building a case. Every data point becomes ammunition for the quarterly board meeting where she advocates for new equipment or protocol changes.",
  pattern: "CMOs at mid-size hospitals (200-500 beds) face intense pressure to demonstrate ROI on clinical initiatives. They need evidence that speaks both patient care AND financial performance languages.",
  sprinkle: "\"Last quarter's sepsis protocol didn't just save 12 lives—it saved $2.4M in extended ICU stays. But you won't find that in any dashboard. You'll find it in the thank-you notes from families who got their loved ones home three days earlier.\""
};

interface VisitorStoryCreatorProps {
  onStoryComplete?: (story: typeof mockStory) => void;
}

export function VisitorStoryCreator({ onStoryComplete }: VisitorStoryCreatorProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);
  const [selectedInsight, setSelectedInsight] = useState<string | null>(null);
  const [generatedStory, setGeneratedStory] = useState<typeof mockStory | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateStory = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setGeneratedStory(mockStory);
      setIsGenerating(false);
      setStep(3);
    }, 2000);
  };

  const handleReset = () => {
    setStep(1);
    setSelectedPersona(null);
    setSelectedInsight(null);
    setGeneratedStory(null);
  };

  const handleComplete = () => {
    if (generatedStory && onStoryComplete) {
      onStoryComplete(generatedStory);
    }
  };

  const currentInsights = selectedPersona ? personaInsights[selectedPersona] : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 border-b border-border bg-gradient-to-r from-healthcare-teal/10 to-healthcare-navy/10">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
            <BookOpen className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="font-display text-lg tracking-wide">VISITOR STORY CREATOR</h2>
            <p className="text-xs text-muted-foreground">Persona → Insight → Story</p>
          </div>
        </div>
        
        {/* Progress Steps */}
        <div className="flex items-center gap-2">
          {[
            { num: 1, label: "Select Persona" },
            { num: 2, label: "Choose Insight" },
            { num: 3, label: "Generate Story" },
          ].map((s, index) => (
            <div key={s.num} className="flex items-center">
              <div className={`flex items-center gap-2 px-3 py-1 ${
                step >= s.num ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
              }`}>
                {step > s.num ? <Check className="w-3 h-3" /> : <span className="text-xs font-display">{s.num}</span>}
                <span className="text-xs font-display tracking-wide hidden sm:inline">{s.label}</span>
              </div>
              {index < 2 && <ChevronRight className="w-4 h-4 text-muted-foreground mx-1" />}
            </div>
          ))}
        </div>
      </div>

      <div className="p-6">
        <AnimatePresence mode="wait">
          {/* Step 1: Persona Selection */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <h3 className="font-display text-sm tracking-wide mb-4">SELECT A VISITOR PERSONA</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {personas.map((persona) => (
                  <button
                    key={persona.id}
                    onClick={() => setSelectedPersona(persona.id)}
                    className={`p-4 border text-left transition-all ${
                      selectedPersona === persona.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-muted-foreground"
                    }`}
                  >
                    <span className="text-2xl mb-2 block">{persona.icon}</span>
                    <span className="text-sm font-medium block mb-1">{persona.label}</span>
                    <span className="text-xs text-muted-foreground">{persona.description}</span>
                  </button>
                ))}
              </div>
              
              <div className="flex justify-end mt-6">
                <Button 
                  onClick={() => setStep(2)} 
                  disabled={!selectedPersona}
                >
                  Continue <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Insight Selection */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-sm tracking-wide">CHOOSE AN INSIGHT</h3>
                <button 
                  onClick={() => setStep(1)}
                  className="text-xs text-muted-foreground hover:text-foreground"
                >
                  ← Change Persona
                </button>
              </div>
              
              <div className="mb-4 p-3 bg-muted/30 border border-border">
                <p className="text-xs text-muted-foreground">Creating story for:</p>
                <p className="text-sm font-medium flex items-center gap-2">
                  {personas.find(p => p.id === selectedPersona)?.icon}
                  {personas.find(p => p.id === selectedPersona)?.label}
                </p>
              </div>
              
              <div className="space-y-3">
                {currentInsights.map((insight) => (
                  <button
                    key={insight.id}
                    onClick={() => setSelectedInsight(insight.id)}
                    className={`w-full p-4 border text-left transition-all ${
                      selectedInsight === insight.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-muted-foreground"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-6 h-6 flex items-center justify-center flex-shrink-0 ${
                        selectedInsight === insight.id ? "bg-primary" : "bg-muted"
                      }`}>
                        <Lightbulb className={`w-3 h-3 ${
                          selectedInsight === insight.id ? "text-primary-foreground" : "text-muted-foreground"
                        }`} />
                      </div>
                      <div>
                        <p className="font-medium text-sm mb-1">{insight.title}</p>
                        <p className="text-sm text-muted-foreground mb-2">{insight.description}</p>
                        <p className="text-xs text-muted-foreground">Source: {insight.source}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
              
              <div className="flex justify-between mt-6">
                <Button variant="outline" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button 
                  onClick={handleGenerateStory} 
                  disabled={!selectedInsight || isGenerating}
                >
                  {isGenerating ? (
                    <>Generating Story...</>
                  ) : (
                    <><Sparkles className="w-4 h-4 mr-2" /> Generate Story</>
                  )}
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Generated Story */}
          {step === 3 && generatedStory && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-sm tracking-wide">GENERATED VISITOR STORY</h3>
                <button 
                  onClick={handleReset}
                  className="text-xs text-muted-foreground hover:text-foreground"
                >
                  Start Over
                </button>
              </div>
              
              <div className="space-y-4">
                {[
                  { key: "behavior", label: "Behavior", icon: User, color: "border-l-healthcare-teal", content: generatedStory.behavior },
                  { key: "insight", label: "Insight", icon: Lightbulb, color: "border-l-healthcare-navy", content: generatedStory.insight },
                  { key: "pattern", label: "Pattern", icon: ArrowRight, color: "border-l-primary", content: generatedStory.pattern },
                  { key: "sprinkle", label: "Sprinkle", icon: Sparkles, color: "border-l-accent", content: generatedStory.sprinkle },
                ].map((item, index) => (
                  <motion.div
                    key={item.key}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-4 bg-muted/30 border-l-4 ${item.color}`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <item.icon className="w-4 h-4 text-muted-foreground" />
                      <span className="font-display text-xs tracking-wide">{item.label.toUpperCase()}</span>
                    </div>
                    <p className={`text-sm ${item.key === "sprinkle" ? "italic text-foreground" : "text-muted-foreground"}`}>
                      {item.content}
                    </p>
                  </motion.div>
                ))}
              </div>
              
              <div className="flex justify-between mt-6">
                <Button variant="outline" onClick={handleReset}>
                  Create Another
                </Button>
                <Button onClick={handleComplete}>
                  <Sparkles className="w-4 h-4 mr-2" /> Turn Into Content
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
