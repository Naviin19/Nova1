import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Building2, 
  Users, 
  Target, 
  Palette, 
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Plus,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface BrandOnboardingProps {
  onComplete: () => void;
  onSkip?: () => void;
}

const steps = [
  { id: 1, title: "Brand Details", icon: Building2, description: "Basic information about your brand" },
  { id: 2, title: "Target Personas", icon: Users, description: "Define your key audience segments" },
  { id: 3, title: "Content Goals", icon: Target, description: "Set your content marketing objectives" },
  { id: 4, title: "Brand Voice", icon: Palette, description: "Establish your communication style" },
];

const personaTemplates = [
  { id: "executive", label: "C-Suite Executive", description: "CEOs, CMOs, decision makers" },
  { id: "manager", label: "Department Manager", description: "Operations, IT, HR leaders" },
  { id: "specialist", label: "Technical Specialist", description: "Doctors, Engineers, Analysts" },
  { id: "buyer", label: "Procurement Buyer", description: "Purchasing, Vendor management" },
];

const goalOptions = [
  { id: "awareness", label: "Brand Awareness", description: "Increase visibility and reach" },
  { id: "leads", label: "Lead Generation", description: "Drive qualified prospects" },
  { id: "engagement", label: "Community Engagement", description: "Build loyal audience" },
  { id: "thought-leadership", label: "Thought Leadership", description: "Establish industry authority" },
];

const voiceOptions = [
  { id: "professional", label: "Professional", description: "Formal, authoritative, trustworthy" },
  { id: "friendly", label: "Friendly", description: "Warm, approachable, conversational" },
  { id: "innovative", label: "Innovative", description: "Forward-thinking, tech-savvy" },
  { id: "empathetic", label: "Empathetic", description: "Caring, patient-focused, supportive" },
];

export function BrandOnboarding({ onComplete, onSkip }: BrandOnboardingProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [brandName, setBrandName] = useState("");
  const [category, setCategory] = useState("");
  const [selectedPersonas, setSelectedPersonas] = useState<string[]>([]);
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string[]>([]);
  const [isCompleting, setIsCompleting] = useState(false);

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    setIsCompleting(true);
    setTimeout(() => {
      onComplete();
    }, 2000);
  };

  const toggleSelection = (id: string, selected: string[], setSelected: (val: string[]) => void) => {
    if (selected.includes(id)) {
      setSelected(selected.filter(s => s !== id));
    } else {
      setSelected([...selected, id]);
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1: return brandName.length > 2;
      case 2: return selectedPersonas.length > 0;
      case 3: return selectedGoals.length > 0;
      case 4: return selectedVoice.length > 0;
      default: return false;
    }
  };

  if (isCompleting) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center"
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
          className="text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.4, type: "spring", stiffness: 200 }}
            className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center"
          >
            <CheckCircle2 className="w-12 h-12 text-white" />
          </motion.div>
          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="font-display text-3xl mb-2"
          >
            BRAND CONFIGURED
          </motion.h2>
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="text-muted-foreground"
          >
            Your content intelligence hub is ready
          </motion.p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-8 flex justify-center gap-2"
          >
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-2 h-2 rounded-full bg-primary"
                animate={{ scale: [1, 1.5, 1] }}
                transition={{ duration: 0.6, delay: i * 0.2, repeat: Infinity }}
              />
            ))}
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center p-6"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-2xl bg-card border border-border rounded-2xl shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-6 border-b border-border bg-gradient-to-r from-primary/5 to-secondary/5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="font-display text-xl tracking-wide">BRAND SETUP</h2>
                <p className="text-sm text-muted-foreground">Configure your content intelligence hub</p>
              </div>
            </div>
            {onSkip && (
              <Button variant="ghost" size="sm" onClick={onSkip}>
                Skip for now
              </Button>
            )}
          </div>

          {/* Progress Steps */}
          <div className="flex items-center gap-2">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center flex-1">
                <div className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded-lg transition-all flex-1",
                  currentStep === step.id 
                    ? "bg-primary/10" 
                    : currentStep > step.id 
                      ? "bg-success/10" 
                      : "bg-muted/50"
                )}>
                  <div className={cn(
                    "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold",
                    currentStep === step.id 
                      ? "bg-primary text-primary-foreground" 
                      : currentStep > step.id 
                        ? "bg-success text-success-foreground" 
                        : "bg-muted text-muted-foreground"
                  )}>
                    {currentStep > step.id ? <CheckCircle2 className="w-4 h-4" /> : step.id}
                  </div>
                  <span className={cn(
                    "text-xs font-medium hidden sm:block",
                    currentStep >= step.id ? "text-foreground" : "text-muted-foreground"
                  )}>
                    {step.title}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div className={cn(
                    "w-4 h-0.5 mx-1",
                    currentStep > step.id ? "bg-success" : "bg-border"
                  )} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 min-h-[400px]">
          <AnimatePresence mode="wait">
            {/* Step 1: Brand Details */}
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="font-display text-lg mb-1">Tell us about your brand</h3>
                  <p className="text-sm text-muted-foreground">Basic information to personalize your experience</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Brand Name</label>
                    <input
                      type="text"
                      value={brandName}
                      onChange={(e) => setBrandName(e.target.value)}
                      placeholder="e.g., CarePlus Hospitals"
                      className="w-full px-4 py-3 bg-muted/50 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Industry / Category</label>
                    <input
                      type="text"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      placeholder="e.g., Healthcare, Hospital Services"
                      className="w-full px-4 py-3 bg-muted/50 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 2: Personas */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="font-display text-lg mb-1">Who are your target personas?</h3>
                  <p className="text-sm text-muted-foreground">Select the audience segments you want to reach</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {personaTemplates.map((persona) => (
                    <button
                      key={persona.id}
                      onClick={() => toggleSelection(persona.id, selectedPersonas, setSelectedPersonas)}
                      className={cn(
                        "p-4 rounded-xl border text-left transition-all",
                        selectedPersonas.includes(persona.id)
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      )}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium text-foreground">{persona.label}</p>
                          <p className="text-xs text-muted-foreground mt-1">{persona.description}</p>
                        </div>
                        {selectedPersonas.includes(persona.id) && (
                          <CheckCircle2 className="w-5 h-5 text-primary" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>

                <button className="flex items-center gap-2 text-sm text-primary hover:text-primary/80">
                  <Plus className="w-4 h-4" />
                  Add custom persona
                </button>
              </motion.div>
            )}

            {/* Step 3: Goals */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="font-display text-lg mb-1">What are your content goals?</h3>
                  <p className="text-sm text-muted-foreground">Select your primary marketing objectives</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {goalOptions.map((goal) => (
                    <button
                      key={goal.id}
                      onClick={() => toggleSelection(goal.id, selectedGoals, setSelectedGoals)}
                      className={cn(
                        "p-4 rounded-xl border text-left transition-all",
                        selectedGoals.includes(goal.id)
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      )}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium text-foreground">{goal.label}</p>
                          <p className="text-xs text-muted-foreground mt-1">{goal.description}</p>
                        </div>
                        {selectedGoals.includes(goal.id) && (
                          <CheckCircle2 className="w-5 h-5 text-primary" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Step 4: Voice */}
            {currentStep === 4 && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="font-display text-lg mb-1">Define your brand voice</h3>
                  <p className="text-sm text-muted-foreground">How should your content sound?</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {voiceOptions.map((voice) => (
                    <button
                      key={voice.id}
                      onClick={() => toggleSelection(voice.id, selectedVoice, setSelectedVoice)}
                      className={cn(
                        "p-4 rounded-xl border text-left transition-all",
                        selectedVoice.includes(voice.id)
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      )}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium text-foreground">{voice.label}</p>
                          <p className="text-xs text-muted-foreground mt-1">{voice.description}</p>
                        </div>
                        {selectedVoice.includes(voice.id) && (
                          <CheckCircle2 className="w-5 h-5 text-primary" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border bg-muted/30">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={handleBack}
              disabled={currentStep === 1}
              className={currentStep === 1 ? "invisible" : ""}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            <div className="text-sm text-muted-foreground">
              Step {currentStep} of {steps.length}
            </div>

            <Button
              onClick={handleNext}
              disabled={!canProceed()}
              className="bg-gradient-to-r from-primary to-secondary hover:opacity-90"
            >
              {currentStep === 4 ? (
                <>
                  Complete Setup
                  <CheckCircle2 className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  Continue
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
