import { motion } from "framer-motion";
import { AlertTriangle, Eye, TrendingUp, Activity, Target } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { cn } from "@/lib/utils";

interface Competitor {
  id: string;
  name: string;
  activity: "high" | "medium" | "low";
  lastUpdate: string;
  insight: string;
  campaigns: string[];
  adSpendChange: string;
}

const competitors: Competitor[] = [
  {
    id: "apollo-hospitals",
    name: "Apollo Hospitals",
    activity: "high",
    lastUpdate: "4h ago",
    insight: "Launched AI-powered diagnostic center with 15-minute cancer screening",
    campaigns: ["#HealthFirst", "#ApolloAI"],
    adSpendChange: "+35%"
  },
  {
    id: "fortis-healthcare",
    name: "Fortis Healthcare",
    activity: "high",
    lastUpdate: "1d ago",
    insight: "Expanded pediatric emergency network to 24/7 across all locations",
    campaigns: ["#ChildFirst", "#24x7Care"],
    adSpendChange: "+22%"
  },
  {
    id: "max-healthcare",
    name: "Max Healthcare",
    activity: "medium",
    lastUpdate: "2d ago",
    insight: "Partnered with international medical university for research collaboration",
    campaigns: ["#ResearchExcellence"],
    adSpendChange: "+12%"
  },
];

const activityStyles = {
  high: { dot: "bg-error animate-pulse", text: "text-error", bg: "bg-error/10" },
  medium: { dot: "bg-warning", text: "text-warning", bg: "bg-warning/10" },
  low: { dot: "bg-muted-foreground", text: "text-muted-foreground", bg: "bg-muted" },
};

export function CompetitorRadar() {
  const navigate = useNavigate();
  const { brandId } = useParams();

  const handleCompetitorClick = (competitorId: string) => {
    navigate(`/brand/${brandId || 'careplus-hospitals'}/competitor/${competitorId}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.9, duration: 0.5 }}
      className="bg-card border border-border rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-error/10 flex items-center justify-center">
            <Activity className="w-5 h-5 text-error" />
          </div>
          <div>
            <h3 className="font-display text-lg tracking-wide">COMPETITOR RADAR</h3>
            <p className="text-sm text-muted-foreground">Healthcare industry tracking</p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-error/10 text-error text-xs font-medium">
          <AlertTriangle className="w-3 h-3" />
          3 Active
        </span>
      </div>

      <div className="space-y-3">
        {competitors.map((comp, index) => {
          const style = activityStyles[comp.activity];
          return (
            <motion.div
              key={comp.name}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 1.0 + index * 0.1, duration: 0.3 }}
              onClick={() => handleCompetitorClick(comp.id)}
              className="p-4 rounded-xl border border-border hover:border-primary/30 hover:bg-muted/30 transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={cn("w-2 h-2 rounded-full", style.dot)} />
                  <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                    {comp.name}
                  </span>
                </div>
                <span className={cn("text-xs px-2 py-0.5 rounded-full", style.bg, style.text)}>
                  {comp.activity.toUpperCase()}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{comp.insight}</p>
              
              {/* Campaign Tags */}
              <div className="flex flex-wrap gap-1 mb-2">
                {comp.campaigns.map((campaign, i) => (
                  <span 
                    key={i}
                    className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary"
                  >
                    {campaign}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">{comp.lastUpdate}</span>
                <span className="text-success flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  {comp.adSpendChange} ad spend
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      <button 
        onClick={() => handleCompetitorClick('apollo-hospitals')}
        className="w-full mt-4 py-2.5 rounded-xl bg-muted text-sm text-foreground hover:bg-muted/80 transition-colors flex items-center justify-center gap-2"
      >
        <Target className="w-4 h-4" />
        Full Competitive Analysis
      </button>
    </motion.div>
  );
}
