import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Eye, 
  Brain, 
  Lightbulb, 
  GitBranch, 
  Sparkles,
  Wand2,
  Image,
  Video,
  FileText,
  Copy,
  Check,
  ChevronDown,
  Zap,
  Target,
  BarChart3,
  Save,
  CheckCircle2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useContentBriefs } from "@/contexts/ContentBriefContext";
import { toast } from "sonner";
import type { ObservationData } from "./ObservationForm";

interface OBIPToContentGeneratorProps {
  observation?: ObservationData | null;
  onBriefSaved?: () => void;
}

interface ContentOutput {
  type: "image" | "video" | "article";
  title: string;
  prompt: string;
  contentStructure: {
    format: string;
    dimensions: string;
    duration?: string;
    sections?: string[];
    visualStyle: string;
    tone: string;
    callToAction: string;
  };
  designSpec: {
    colorPalette: string[];
    typography: {
      headline: string;
      body: string;
    };
    layout: string;
    imagery: string;
  };
  measurementParams: {
    primaryKPI: string;
    secondaryKPIs: string[];
    targetAudience: string;
    conversionGoal: string;
    benchmarks: {
      impressions: string;
      engagement: string;
      conversion: string;
    };
  };
  jsonSpec: string;
}

const contentTypes = [
  { id: "image", label: "Static Image", icon: Image, desc: "Social media, ads, infographics" },
  { id: "video", label: "Video Content", icon: Video, desc: "Reels, stories, explainers" },
  { id: "article", label: "Article/Blog", icon: FileText, desc: "Long-form content, SEO pieces" },
];

export function OBIPToContentGenerator({ observation, onBriefSaved }: OBIPToContentGeneratorProps) {
  const [selectedType, setSelectedType] = useState<"image" | "video" | "article">("image");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<ContentOutput | null>(null);
  const [copied, setCopied] = useState(false);
  const [showJson, setShowJson] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [currentSprinkle, setCurrentSprinkle] = useState("");
  const { addBrief } = useContentBriefs();

  // The "Sprinkle" - pattern-breaking creative twist
  const generateSprinkle = (pattern: string): string => {
    const sprinkles = [
      "Flip the narrative: Instead of showing the problem, show the unexpected joy of the solution.",
      "Use contrast: Juxtapose the old way vs. the new reality in a split-screen format.",
      "Personify the insight: Give a human face to the data point - make it relatable.",
      "Challenge assumptions: Lead with a provocative question that makes them stop scrolling.",
      "Embrace vulnerability: Show the 'messy middle' that competitors hide.",
      "Create FOMO: Highlight what they're missing, not what they're getting.",
      "Use specificity: Replace generic claims with hyper-specific numbers and outcomes.",
      "Subvert expectations: Start with what they expect, then pivot to surprise.",
    ];
    return sprinkles[Math.floor(Math.random() * sprinkles.length)];
  };

  const generateContent = async () => {
    if (!observation) return;
    
    setIsGenerating(true);
    
    // Simulate AI generation delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const sprinkle = generateSprinkle(observation.pattern);
    setCurrentSprinkle(sprinkle);
    
    const contentOutput: ContentOutput = {
      type: selectedType,
      title: `Content from: ${observation.title}`,
      prompt: generatePrompt(observation, selectedType, sprinkle),
      contentStructure: {
        format: selectedType === "image" ? "Static carousel (4 slides)" : 
                selectedType === "video" ? "Short-form vertical video (9:16)" : 
                "Long-form SEO article",
        dimensions: selectedType === "image" ? "1080x1350px (Instagram)" :
                    selectedType === "video" ? "1080x1920px (Reels/TikTok)" :
                    "1200-1500 words",
        duration: selectedType === "video" ? "30-45 seconds" : undefined,
        sections: selectedType === "article" ? [
          "Hook: Pattern-breaking opener",
          "Problem: Behavior we observed",
          "Insight: Why this matters",
          "Solution: How we address it",
          "Proof: Evidence and outcomes",
          "CTA: Clear next step"
        ] : undefined,
        visualStyle: "Clean, professional healthcare aesthetic with warm accents",
        tone: "Authoritative yet approachable, data-driven with human touch",
        callToAction: "Schedule a consultation / Learn more / Download guide"
      },
      designSpec: {
        colorPalette: ["#0D9488", "#1E3A5F", "#22D3EE", "#FFFFFF"],
        typography: {
          headline: "Bold sans-serif (Montserrat or similar)",
          body: "Clean readable sans (Inter or similar)"
        },
        layout: selectedType === "image" ? 
          "Hero image with text overlay, supporting data visualization" :
          selectedType === "video" ?
          "Opening hook (0-3s), Pattern reveal (3-15s), Insight (15-30s), CTA (30-45s)" :
          "Inverted pyramid with scannable subheadings",
        imagery: "Real healthcare settings, diverse patients, modern technology, warm lighting"
      },
      measurementParams: {
        primaryKPI: selectedType === "image" ? "Engagement Rate" :
                    selectedType === "video" ? "View-through Rate" :
                    "Time on Page",
        secondaryKPIs: [
          "Click-through Rate",
          "Share Rate",
          "Comment Sentiment",
          "Lead Form Submissions"
        ],
        targetAudience: observation.type === "customer" ? "Healthcare decision-makers" :
                        observation.type === "competition" ? "Competitors' audience" :
                        "Industry stakeholders",
        conversionGoal: "Consultation booking or content download",
        benchmarks: {
          impressions: "10,000+ in first 48 hours",
          engagement: "4-6% engagement rate",
          conversion: "2-3% click-to-lead conversion"
        }
      },
      jsonSpec: ""
    };
    
    // Generate the embedded JSON structure
    contentOutput.jsonSpec = JSON.stringify({
      contentId: `content-${Date.now()}`,
      sourceObservation: observation.id,
      obipFlow: {
        observation: observation.rawObservation,
        behavior: observation.behavior,
        insight: observation.insight,
        pattern: observation.pattern
      },
      sprinkle: sprinkle,
      contentType: selectedType,
      structure: contentOutput.contentStructure,
      design: contentOutput.designSpec,
      measurement: contentOutput.measurementParams,
      generatedAt: new Date().toISOString()
    }, null, 2);
    
    setGeneratedContent(contentOutput);
    setIsGenerating(false);
    setIsSaved(false);
  };

  const handleSaveBrief = () => {
    if (!observation || !generatedContent) return;

    const brief = addBrief({
      observationId: observation.id,
      observationTitle: observation.title,
      obipFlow: {
        observation: observation.rawObservation,
        behavior: observation.behavior,
        insight: observation.insight,
        pattern: observation.pattern
      },
      sprinkle: currentSprinkle,
      contentType: selectedType,
      title: `${observation.title} - ${selectedType.charAt(0).toUpperCase() + selectedType.slice(1)} Content`,
      prompt: generatedContent.prompt,
      contentStructure: generatedContent.contentStructure,
      designSpec: generatedContent.designSpec,
      measurementParams: generatedContent.measurementParams
    });

    setIsSaved(true);
    toast.success("Brief saved to Content Library!", {
      description: `Brief ID: ${brief.id}`,
      action: {
        label: "View Library",
        onClick: () => window.location.href = `/brand/careplus-hospitals/content`
      }
    });
    onBriefSaved?.();
  };

  const generatePrompt = (obs: ObservationData, type: string, sprinkle: string): string => {
    const basePrompt = `
Create ${type === "image" ? "a compelling visual" : type === "video" ? "an engaging video" : "an informative article"} for CarePlus Hospital Network.

## SOURCE OBSERVATION (OBIP Flow):

**Observation:** ${obs.rawObservation}

**Behavior:** ${obs.behavior}

**Insight:** ${obs.insight}

**Pattern:** ${obs.pattern}

## CREATIVE TWIST (The Sprinkle):
${sprinkle}

## CONTENT REQUIREMENTS:

${type === "image" ? `
- Create a 4-slide carousel that tells a story
- Slide 1: Hook with the surprising insight
- Slide 2: Show the behavior/problem
- Slide 3: Reveal the pattern and what it means
- Slide 4: CarePlus solution + clear CTA
- Use healthcare-teal (#0D9488) as primary accent
- Include data visualization where relevant
- Maintain HIPAA-compliant imagery (no identifiable patients)
` : type === "video" ? `
- 30-45 second vertical video (9:16 aspect ratio)
- Hook in first 3 seconds (pattern-breaking statement)
- Build tension with the observed behavior
- Reveal the insight with visual evidence
- End with CarePlus positioning and CTA
- Use modern transitions, subtle motion graphics
- Include captions for silent viewing
- Healthcare-teal accents throughout
` : `
- 1200-1500 word SEO-optimized article
- H1: Attention-grabbing headline using the pattern
- Open with the behavior observation (hook)
- Build credibility with data and examples
- Connect to CarePlus expertise
- Include 3-5 internal/external links
- End with clear CTA and consultation option
- Target keywords: [derive from observation tags]
`}

## TONE & VOICE:
- Professional but not clinical
- Data-driven with human stories
- Confident without being arrogant
- Innovative and forward-thinking

## BRAND GUIDELINES:
- CarePlus Hospital Network
- Tagline: "Excellence in Healthcare, Compassion in Care"
- Never use fear-based messaging
- Focus on patient outcomes and innovation
`;

    return basePrompt.trim();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-xl overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center rounded-lg">
            <Wand2 className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-display text-lg tracking-wide">OBIP → CONTENT GENERATOR</h3>
            <p className="text-sm text-muted-foreground">Transform observations into content with the Sprinkle™</p>
          </div>
        </div>

        {/* OBIP Flow Visualization */}
        {observation && (
          <div className="bg-muted/30 rounded-lg p-4 border border-border">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">Active Observation: {observation.title}</span>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {[
                { icon: Eye, label: "O", value: observation.rawObservation },
                { icon: Brain, label: "B", value: observation.behavior },
                { icon: Lightbulb, label: "I", value: observation.insight },
                { icon: GitBranch, label: "P", value: observation.pattern },
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className="w-8 h-8 mx-auto mb-1 bg-primary/10 rounded-lg flex items-center justify-center">
                    <item.icon className="w-4 h-4 text-primary" />
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2">{item.value.slice(0, 50)}...</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Content Type Selection */}
      <div className="p-6 border-b border-border">
        <label className="block text-sm font-medium mb-3">Select Content Type</label>
        <div className="grid grid-cols-3 gap-3">
          {contentTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setSelectedType(type.id as typeof selectedType)}
              className={cn(
                "p-4 rounded-lg border-2 transition-all text-left",
                selectedType === type.id
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/50"
              )}
            >
              <type.icon className={cn(
                "w-6 h-6 mb-2",
                selectedType === type.id ? "text-primary" : "text-muted-foreground"
              )} />
              <p className="font-medium text-sm">{type.label}</p>
              <p className="text-xs text-muted-foreground">{type.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Generate Button */}
      <div className="p-6 border-b border-border">
        <Button 
          onClick={generateContent} 
          disabled={!observation || isGenerating}
          className="w-full"
          size="lg"
        >
          {isGenerating ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full mr-2"
              />
              Generating with Sprinkle™...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 mr-2" />
              Generate Content Brief
            </>
          )}
        </Button>
        {!observation && (
          <p className="text-xs text-muted-foreground text-center mt-2">
            Select an observation to generate content
          </p>
        )}
      </div>

      {/* Generated Output */}
      <AnimatePresence>
        {generatedContent && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t border-border"
          >
            {/* Prompt Section */}
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-display text-sm tracking-wide flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  GENERATED PROMPT
                </h4>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => copyToClipboard(generatedContent.prompt)}
                >
                  {copied ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <div className="bg-muted rounded-lg p-4 max-h-60 overflow-y-auto">
                <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono">
                  {generatedContent.prompt}
                </pre>
              </div>
            </div>

            {/* Structure & Design */}
            <div className="p-6 border-b border-border">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-display text-sm tracking-wide mb-3 flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    CONTENT STRUCTURE
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Format:</span>
                      <span>{generatedContent.contentStructure.format}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Dimensions:</span>
                      <span>{generatedContent.contentStructure.dimensions}</span>
                    </div>
                    {generatedContent.contentStructure.duration && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Duration:</span>
                        <span>{generatedContent.contentStructure.duration}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Style:</span>
                      <span className="text-right max-w-[60%]">{generatedContent.contentStructure.visualStyle}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-display text-sm tracking-wide mb-3 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    MEASUREMENT
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Primary KPI:</span>
                      <span>{generatedContent.measurementParams.primaryKPI}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Impressions:</span>
                      <span>{generatedContent.measurementParams.benchmarks.impressions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Engagement:</span>
                      <span>{generatedContent.measurementParams.benchmarks.engagement}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Conversion:</span>
                      <span>{generatedContent.measurementParams.benchmarks.conversion}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* JSON Spec Toggle & Save */}
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <button
                  onClick={() => setShowJson(!showJson)}
                  className="flex items-center gap-2 text-sm font-medium text-primary hover:underline"
                >
                  <ChevronDown className={cn(
                    "w-4 h-4 transition-transform",
                    showJson && "rotate-180"
                  )} />
                  {showJson ? "Hide" : "Show"} Embedded JSON Specification
                </button>
                
                <Button 
                  onClick={handleSaveBrief}
                  disabled={isSaved}
                  className={cn(
                    "transition-all",
                    isSaved && "bg-success hover:bg-success"
                  )}
                >
                  {isSaved ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Saved to Library
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save Brief to Library
                    </>
                  )}
                </Button>
              </div>
              
              <AnimatePresence>
                {showJson && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-muted-foreground">Complete content specification</span>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => copyToClipboard(generatedContent.jsonSpec)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="bg-muted rounded-lg p-4 max-h-60 overflow-y-auto">
                      <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono">
                        {generatedContent.jsonSpec}
                      </pre>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
