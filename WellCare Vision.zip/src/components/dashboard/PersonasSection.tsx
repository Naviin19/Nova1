import { motion } from "framer-motion";
import { 
  Users, 
  Target, 
  MessageSquare, 
  TrendingUp, 
  Heart,
  Stethoscope,
  Monitor,
  ShieldCheck,
  Briefcase,
  Package
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Persona {
  id: string;
  name: string;
  role: string;
  avatar: string;
  department: string;
  experience: string;
  painPoints: string[];
  goals: string[];
  contentPreferences: string[];
  engagementRate: string;
  reachPotential: string;
  icon: React.ElementType;
  color: string;
}

const personas: Persona[] = [
  {
    id: "persona-1",
    name: "Dr. Rajesh Sharma",
    role: "Chief Medical Officer",
    avatar: "RS",
    department: "Executive Leadership",
    experience: "28 years",
    painPoints: ["Staff retention", "Technology adoption", "Quality metrics"],
    goals: ["Improve patient outcomes", "Reduce readmission rates", "Implement AI diagnostics"],
    contentPreferences: ["Clinical research", "Leadership insights", "Industry trends"],
    engagementRate: "4.8%",
    reachPotential: "125K",
    icon: Stethoscope,
    color: "from-teal-500 to-teal-600"
  },
  {
    id: "persona-2",
    name: "Priya Nair",
    role: "Hospital Administrator",
    avatar: "PN",
    department: "Operations",
    experience: "20 years",
    painPoints: ["Budget constraints", "Regulatory compliance", "Operational efficiency"],
    goals: ["Optimize bed utilization", "Reduce operational costs", "Improve patient satisfaction"],
    contentPreferences: ["Case studies", "ROI analyses", "Best practices"],
    engagementRate: "5.2%",
    reachPotential: "89K",
    icon: Briefcase,
    color: "from-sky-500 to-sky-600"
  },
  {
    id: "persona-3",
    name: "Dr. Aisha Patel",
    role: "Head of Cardiology",
    avatar: "AP",
    department: "Cardiology",
    experience: "22 years",
    painPoints: ["Equipment upgrades", "Patient volume", "Research funding"],
    goals: ["Launch cardiac surgery center", "Increase minimally invasive procedures", "Publish research"],
    contentPreferences: ["Medical journals", "Procedure videos", "Conference presentations"],
    engagementRate: "6.1%",
    reachPotential: "156K",
    icon: Heart,
    color: "from-rose-500 to-rose-600"
  },
  {
    id: "persona-4",
    name: "Vikram Mehta",
    role: "IT Director",
    avatar: "VM",
    department: "Information Technology",
    experience: "14 years",
    painPoints: ["System integration", "Cybersecurity", "EMR optimization"],
    goals: ["Implement telemedicine", "Cloud migration", "AI-powered analytics"],
    contentPreferences: ["Tech demos", "Security updates", "Integration guides"],
    engagementRate: "3.9%",
    reachPotential: "67K",
    icon: Monitor,
    color: "from-violet-500 to-violet-600"
  },
  {
    id: "persona-5",
    name: "Sister Mary Joseph",
    role: "Chief Nursing Officer",
    avatar: "MJ",
    department: "Nursing",
    experience: "32 years",
    painPoints: ["Nurse burnout", "Training needs", "Patient safety"],
    goals: ["Improve nurse-to-patient ratios", "Implement bedside technology", "Reduce medical errors"],
    contentPreferences: ["Patient stories", "Training materials", "Wellness content"],
    engagementRate: "5.8%",
    reachPotential: "112K",
    icon: ShieldCheck,
    color: "from-emerald-500 to-emerald-600"
  },
  {
    id: "persona-6",
    name: "Arjun Krishnamurthy",
    role: "Procurement Director",
    avatar: "AK",
    department: "Supply Chain",
    experience: "18 years",
    painPoints: ["Vendor management", "Cost control", "Supply disruptions"],
    goals: ["Reduce procurement costs 15%", "Improve vendor relationships", "Just-in-time inventory"],
    contentPreferences: ["Product comparisons", "Pricing analyses", "Vendor reviews"],
    engagementRate: "4.2%",
    reachPotential: "45K",
    icon: Package,
    color: "from-amber-500 to-amber-600"
  }
];

export function PersonasSection() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-display text-xl tracking-wide">CAREPLUS PERSONAS</h2>
            <p className="text-sm text-muted-foreground">6 key audience segments for content targeting</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Target className="w-4 h-4 text-primary" />
            <span>Avg. Engagement: <span className="text-foreground font-medium">5.0%</span></span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <TrendingUp className="w-4 h-4 text-success" />
            <span>Total Reach: <span className="text-foreground font-medium">594K</span></span>
          </div>
        </div>
      </div>

      {/* Persona Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {personas.map((persona, index) => (
          <motion.div
            key={persona.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ y: -4 }}
            className="group bg-card border border-border rounded-xl p-5 hover:border-primary/50 transition-all cursor-pointer"
          >
            {/* Header */}
            <div className="flex items-start gap-4 mb-4">
              <div className={cn(
                "w-14 h-14 rounded-xl bg-gradient-to-br flex items-center justify-center text-white font-display text-lg shadow-lg",
                persona.color
              )}>
                {persona.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-foreground group-hover:text-primary transition-colors">
                  {persona.name}
                </h3>
                <p className="text-sm text-muted-foreground">{persona.role}</p>
                <div className="flex items-center gap-2 mt-1">
                  <persona.icon className="w-3 h-3 text-primary" />
                  <span className="text-xs text-muted-foreground">{persona.department}</span>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Engagement</p>
                <p className="font-display text-lg text-primary">{persona.engagementRate}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Reach</p>
                <p className="font-display text-lg text-foreground">{persona.reachPotential}</p>
              </div>
            </div>

            {/* Pain Points */}
            <div className="mb-4">
              <p className="text-xs font-medium text-muted-foreground mb-2">PAIN POINTS</p>
              <div className="flex flex-wrap gap-1">
                {persona.painPoints.map((point, i) => (
                  <span 
                    key={i}
                    className="text-xs px-2 py-0.5 rounded-full bg-error/10 text-error"
                  >
                    {point}
                  </span>
                ))}
              </div>
            </div>

            {/* Goals */}
            <div className="mb-4">
              <p className="text-xs font-medium text-muted-foreground mb-2">GOALS</p>
              <div className="flex flex-wrap gap-1">
                {persona.goals.slice(0, 2).map((goal, i) => (
                  <span 
                    key={i}
                    className="text-xs px-2 py-0.5 rounded-full bg-success/10 text-success"
                  >
                    {goal}
                  </span>
                ))}
                {persona.goals.length > 2 && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                    +{persona.goals.length - 2}
                  </span>
                )}
              </div>
            </div>

            {/* Content Preferences */}
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-2">CONTENT PREFERENCES</p>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-3 h-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  {persona.contentPreferences.join(", ")}
                </span>
              </div>
            </div>

            {/* Experience badge */}
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Experience: {persona.experience}</span>
                <button className="text-xs text-primary hover:text-primary/80 transition-colors">
                  Create Story →
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
