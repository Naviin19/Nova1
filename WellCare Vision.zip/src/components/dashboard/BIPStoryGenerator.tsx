import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  User, 
  Brain, 
  Lightbulb, 
  TrendingUp, 
  Wand2,
  RefreshCw,
  Copy,
  Check,
  ChevronRight
} from "lucide-react";

const presetPersonas = [
  { id: "cmo", label: "Chief Medical Officer", icon: "🏥" },
  { id: "procurement", label: "Hospital Procurement Director", icon: "📋" },
  { id: "nurse", label: "Head Nurse Administrator", icon: "👩‍⚕️" },
  { id: "cio", label: "Healthcare CIO", icon: "💻" },
  { id: "ceo", label: "Hospital CEO", icon: "👔" },
];

const mockStories: Record<string, { behavior: string; insight: string; pattern: string; sprinkle: string }> = {
  "cmo": {
    behavior: "Dr. Sarah Chen, CMO at Metro Health, spends 3+ hours weekly reviewing clinical outcome dashboards. She frequently cross-references patient satisfaction scores with readmission rates, often during early morning hours before rounds.",
    insight: "She's not just tracking metrics—she's building a case. Every data point she collects becomes ammunition for the quarterly board meeting where she advocates for new equipment or protocol changes.",
    pattern: "CMOs at mid-size hospitals (200-500 beds) are under intense pressure to demonstrate ROI on clinical initiatives. They need evidence that speaks both the language of patient care AND financial performance.",
    sprinkle: "\"Last quarter's sepsis protocol didn't just save 12 lives—it saved $2.4M in extended ICU stays. But you won't find that in any dashboard. You'll find it in the thank-you notes from families who got their loved ones home three days earlier.\""
  },
  "procurement": {
    behavior: "Michael Torres opens vendor comparison spreadsheets at least 4 times per week. He maintains a personal 'red flag' document where he logs delivery delays and quality issues, even for approved vendors.",
    insight: "He's been burned before. Three years ago, a medical device supplier went bankrupt mid-contract, leaving his hospital scrambling. Now, he investigates supplier financial health as obsessively as product specs.",
    pattern: "Hospital procurement leaders are shifting from pure cost optimization to risk mitigation. They'll pay 15-20% premium for suppliers with proven stability and redundancy in their supply chain.",
    sprinkle: "\"The cheapest ventilator in the catalog cost us $80,000 in expedited shipping when our 'budget' supplier couldn't deliver during the winter surge. Now I calculate the 'peace of mind premium' into every purchase order.\""
  },
  "nurse": {
    behavior: "Lisa Mendez, Head Nurse at Sunrise Medical Center, sends 23 text messages per shift on average. Most are quick check-ins with floor nurses, but she screenshots every staffing complaint for her weekly meeting with HR.",
    insight: "She's not just managing schedules—she's documenting a systemic problem. The screenshots are evidence for her pitch to hire three additional FTEs before the next Joint Commission audit.",
    pattern: "Nursing administrators are increasingly translating burnout metrics into compliance risk language. 'Staff wellbeing' gets ignored; 'audit failure probability' gets budget allocation.",
    sprinkle: "\"I stopped saying 'my nurses are exhausted' in leadership meetings. Now I say 'our medication error risk increases 34% when shift coverage drops below threshold.' Same problem, different language. Finally getting traction.\""
  },
  "cio": {
    behavior: "James Park keeps three browser tabs permanently open: his EHR system status page, a cybersecurity news aggregator, and a private Slack channel with CIOs from other health systems.",
    insight: "He learned from the 2023 ransomware attack on a neighboring hospital. Now he's building an informal intelligence network—real-time threat sharing with peers who face the same attackers.",
    pattern: "Healthcare CIOs are moving from vendor-reliant security to peer-collaborative defense. The most effective threat intelligence isn't coming from expensive consultants—it's coming from WhatsApp groups.",
    sprinkle: "\"The $500K security audit told me what I already knew. The group text from my friend at St. Mary's—warning me about a phishing campaign targeting our exact EHR version—that's what actually prevented the breach.\""
  },
  "ceo": {
    behavior: "Robert Williams reviews his hospital's Google reviews every Sunday evening. He personally flags any 1-star review that mentions wait times and forwards them to his operations team by Monday 6 AM.",
    insight: "Public perception keeps him up at night. He knows one viral negative review can undo years of reputation building. His proactive Sunday ritual is his way of controlling the narrative before it controls him.",
    pattern: "Hospital CEOs are becoming reputation-obsessed in ways that weren't true five years ago. Consumer healthcare choices are increasingly driven by online sentiment, not physician referrals.",
    sprinkle: "\"We spent $2M on that lobby renovation. Beautiful marble, designer furniture. You know what moved our NPS score? Putting a coffee cart in the waiting room. Patients don't remember the marble. They remember feeling cared for.\""
  }
};

export function BIPStoryGenerator() {
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);
  const [customPersona, setCustomPersona] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedStory, setGeneratedStory] = useState<typeof mockStories["cmo"] | null>(null);
  const [activeStep, setActiveStep] = useState<number>(0);
  const [copied, setCopied] = useState(false);

  const handleGenerate = () => {
    const personaKey = selectedPersona || "cmo";
    setIsGenerating(true);
    setGeneratedStory(null);
    setActiveStep(0);

    // Simulate AI generation with staged reveals
    setTimeout(() => {
      setGeneratedStory(mockStories[personaKey] || mockStories["cmo"]);
      setIsGenerating(false);
      // Animate through steps
      [0, 1, 2, 3].forEach((step, index) => {
        setTimeout(() => setActiveStep(step + 1), 400 * (index + 1));
      });
    }, 1500);
  };

  const handleCopy = () => {
    if (!generatedStory) return;
    const fullText = `BEHAVIOR:\n${generatedStory.behavior}\n\nINSIGHT:\n${generatedStory.insight}\n\nPATTERN:\n${generatedStory.pattern}\n\nSPRINKLE:\n${generatedStory.sprinkle}`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    setSelectedPersona(null);
    setCustomPersona("");
    setGeneratedStory(null);
    setActiveStep(0);
  };

  const steps = [
    { key: "behavior", label: "Behavior", icon: User, color: "bg-healthcare-teal", content: generatedStory?.behavior },
    { key: "insight", label: "Insight", icon: Lightbulb, color: "bg-healthcare-navy", content: generatedStory?.insight },
    { key: "pattern", label: "Pattern", icon: TrendingUp, color: "bg-primary", content: generatedStory?.pattern },
    { key: "sprinkle", label: "Sprinkle", icon: Sparkles, color: "bg-accent", content: generatedStory?.sprinkle },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border overflow-hidden"
    >
      {/* Header */}
      <div className="p-6 border-b border-border bg-gradient-to-r from-healthcare-teal/10 to-healthcare-navy/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
            <Wand2 className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="font-display text-lg tracking-wide">BIP STORY GENERATOR</h2>
            <p className="text-xs text-muted-foreground">Transform personas into compelling narratives</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Persona Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-foreground mb-3">
            Select a Healthcare Persona
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 mb-4">
            {presetPersonas.map((persona) => (
              <button
                key={persona.id}
                onClick={() => {
                  setSelectedPersona(persona.id);
                  setCustomPersona("");
                }}
                className={`p-3 border text-left transition-all duration-200 ${
                  selectedPersona === persona.id
                    ? "border-primary bg-primary/10 ring-1 ring-primary"
                    : "border-border hover:border-muted-foreground bg-card hover:bg-muted/50"
                }`}
              >
                <span className="text-xl mb-1 block">{persona.icon}</span>
                <span className="text-xs font-medium leading-tight block">{persona.label}</span>
              </button>
            ))}
          </div>

          <div className="relative">
            <Brain className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Or describe a custom persona..."
              value={customPersona}
              onChange={(e) => {
                setCustomPersona(e.target.value);
                if (e.target.value) setSelectedPersona(null);
              }}
              className="w-full h-11 pl-10 pr-4 bg-sidebar-accent border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        </div>

        {/* Generate Button */}
        <div className="flex gap-3 mb-6">
          <Button 
            onClick={handleGenerate} 
            disabled={isGenerating || (!selectedPersona && !customPersona)}
            className="flex-1"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Generating Story...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate BIP + Sprinkle
              </>
            )}
          </Button>
          {generatedStory && (
            <Button variant="outline" onClick={handleReset}>
              <RefreshCw className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Generated Story */}
        <AnimatePresence mode="wait">
          {isGenerating && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-12"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="w-12 h-12 border-2 border-primary border-t-transparent rounded-full mb-4"
              />
              <p className="text-muted-foreground text-sm">Analyzing persona patterns...</p>
            </motion.div>
          )}

          {generatedStory && !isGenerating && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              {/* Step Progress */}
              <div className="flex items-center gap-2 mb-6">
                {steps.map((step, index) => (
                  <div key={step.key} className="flex items-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: activeStep > index ? 1 : 0.5 }}
                      className={`w-8 h-8 flex items-center justify-center transition-colors ${
                        activeStep > index ? step.color : "bg-muted"
                      }`}
                    >
                      <step.icon className={`w-4 h-4 ${activeStep > index ? "text-white" : "text-muted-foreground"}`} />
                    </motion.div>
                    {index < steps.length - 1 && (
                      <ChevronRight className={`w-4 h-4 mx-1 ${activeStep > index ? "text-foreground" : "text-muted"}`} />
                    )}
                  </div>
                ))}
              </div>

              {/* Story Cards */}
              <div className="space-y-3">
                {steps.map((step, index) => (
                  <AnimatePresence key={step.key}>
                    {activeStep > index && (
                      <motion.div
                        initial={{ opacity: 0, x: -20, height: 0 }}
                        animate={{ opacity: 1, x: 0, height: "auto" }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className={`border-l-4 ${
                          index === 0 ? "border-l-healthcare-teal" :
                          index === 1 ? "border-l-healthcare-navy" :
                          index === 2 ? "border-l-primary" :
                          "border-l-accent"
                        } bg-muted/30 p-4`}>
                          <div className="flex items-center gap-2 mb-2">
                            <step.icon className={`w-4 h-4 ${
                              index === 0 ? "text-healthcare-teal" :
                              index === 1 ? "text-healthcare-navy" :
                              index === 2 ? "text-primary" :
                              "text-accent"
                            }`} />
                            <span className="font-display text-sm tracking-wide">{step.label.toUpperCase()}</span>
                          </div>
                          <p className={`text-sm leading-relaxed ${
                            index === 3 ? "italic text-foreground" : "text-muted-foreground"
                          }`}>
                            {step.content}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                ))}
              </div>

              {/* Copy Button */}
              {activeStep >= 4 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-end pt-4"
                >
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 mr-2 text-green-500" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Full Story
                      </>
                    )}
                  </Button>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Empty State */}
        {!generatedStory && !isGenerating && (
          <div className="text-center py-8 text-muted-foreground">
            <Brain className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Select a persona to generate a BIP + Sprinkle story</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
