import { motion } from "framer-motion";
import { useState } from "react";
import { BarChart3, TrendingUp, TrendingDown, Eye, Heart, MessageCircle, Share2, Users, Target, ArrowUpRight, ArrowDownRight, Building2, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, Legend, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { carePlusData } from "@/data/healthcareMockData";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
const overviewMetrics = [{
  label: "Total Patients",
  value: "2.4M",
  change: 12,
  trend: "up"
}, {
  label: "Bed Occupancy",
  value: "87%",
  change: 5,
  trend: "up"
}, {
  label: "Patient Satisfaction",
  value: "4.6/5",
  change: 6,
  trend: "up"
}, {
  label: "Readmission Rate",
  value: "3.2%",
  change: -11,
  trend: "down"
}];

// Department performance data for charts
const departmentPerformanceData = carePlusData.departments.map(dept => ({
  name: dept.name.length > 10 ? dept.name.substring(0, 10) + '...' : dept.name,
  fullName: dept.name,
  annualCases: dept.annualCases,
  revenue: parseInt(dept.revenue.replace('₹', '').replace('Cr', '')) * 10000000,
  revenueDisplay: dept.revenue,
  satisfaction: dept.patientSatisfaction * 20,
  staff: dept.staff,
  beds: dept.beds,
  growth: parseInt(dept.growth.replace('+', '').replace('%', ''))
}));

// Monthly trend data for departments
const monthlyDepartmentTrends = [{
  month: "Jul",
  Cardiology: 980,
  Oncology: 650,
  Orthopedics: 780,
  Neurology: 520,
  Pediatrics: 1450,
  Emergency: 3600
}, {
  month: "Aug",
  Cardiology: 1050,
  Oncology: 680,
  Orthopedics: 820,
  Neurology: 540,
  Pediatrics: 1520,
  Emergency: 3750
}, {
  month: "Sep",
  Cardiology: 1120,
  Oncology: 720,
  Orthopedics: 850,
  Neurology: 580,
  Pediatrics: 1580,
  Emergency: 3850
}, {
  month: "Oct",
  Cardiology: 1080,
  Oncology: 750,
  Orthopedics: 890,
  Neurology: 560,
  Pediatrics: 1620,
  Emergency: 3920
}, {
  month: "Nov",
  Cardiology: 1150,
  Oncology: 780,
  Orthopedics: 920,
  Neurology: 590,
  Pediatrics: 1680,
  Emergency: 4050
}, {
  month: "Dec",
  Cardiology: 1200,
  Oncology: 820,
  Orthopedics: 960,
  Neurology: 620,
  Pediatrics: 1750,
  Emergency: 4200
}];

// Persona engagement over time
const personaEngagementTrends = [{
  month: "Jul",
  "CMO": 4200,
  "Administrator": 3800,
  "Cardiology Head": 5100,
  "IT Director": 3200,
  "Nursing Officer": 4800,
  "Procurement": 2800
}, {
  month: "Aug",
  "CMO": 4500,
  "Administrator": 4100,
  "Cardiology Head": 5400,
  "IT Director": 3400,
  "Nursing Officer": 5100,
  "Procurement": 3000
}, {
  month: "Sep",
  "CMO": 4800,
  "Administrator": 4300,
  "Cardiology Head": 5800,
  "IT Director": 3600,
  "Nursing Officer": 5400,
  "Procurement": 3200
}, {
  month: "Oct",
  "CMO": 5100,
  "Administrator": 4600,
  "Cardiology Head": 6100,
  "IT Director": 3800,
  "Nursing Officer": 5600,
  "Procurement": 3400
}, {
  month: "Nov",
  "CMO": 5400,
  "Administrator": 4900,
  "Cardiology Head": 6400,
  "IT Director": 4000,
  "Nursing Officer": 5900,
  "Procurement": 3600
}, {
  month: "Dec",
  "CMO": 5800,
  "Administrator": 5200,
  "Cardiology Head": 6800,
  "IT Director": 4200,
  "Nursing Officer": 6200,
  "Procurement": 3900
}];

// Colors for charts
const DEPARTMENT_COLORS = ["hsl(var(--primary))", "hsl(var(--accent))", "hsl(180, 70%, 45%)", "hsl(280, 70%, 50%)", "hsl(45, 90%, 50%)", "hsl(0, 70%, 55%)"];
const PERSONA_COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899", "#06b6d4"];

// Department radar data
const departmentRadarData = carePlusData.departments.map(dept => ({
  department: dept.name.length > 8 ? dept.name.substring(0, 8) : dept.name,
  cases: Math.min(100, dept.annualCases / 450),
  satisfaction: dept.patientSatisfaction * 20,
  growth: parseInt(dept.growth.replace('+', '').replace('%', '')) * 4,
  capacity: dept.beds / 80 * 100
}));
const platformPerformance = [{
  platform: "LinkedIn",
  impressions: "847K",
  engagement: "4.2%",
  leads: 342,
  color: "bg-[#0A66C2]"
}, {
  platform: "Instagram",
  impressions: "624K",
  engagement: "5.8%",
  leads: 128,
  color: "bg-[#E4405F]"
}, {
  platform: "Twitter/X",
  impressions: "412K",
  engagement: "2.1%",
  leads: 89,
  color: "bg-foreground"
}, {
  platform: "YouTube",
  impressions: "298K",
  engagement: "6.4%",
  leads: 67,
  color: "bg-[#FF0000]"
}, {
  platform: "Email",
  impressions: "182K",
  engagement: "42%",
  leads: 621,
  color: "bg-healthcare-teal"
}];
export function MeasureTab() {
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} exit={{
    opacity: 0,
    y: -20
  }} className="space-y-6">
      {/* Overview Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {overviewMetrics.map((metric, index) => <motion.div key={metric.label} initial={{
        opacity: 0,
        y: 10
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        delay: index * 0.1
      }} className="bg-card border border-border p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">{metric.label}</span>
              <div className={cn("flex items-center gap-1 text-xs px-2 py-0.5 rounded-full", metric.trend === "up" && metric.change > 0 ? "text-success bg-success/10" : "text-success bg-success/10")}>
                {metric.trend === "up" ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                {Math.abs(metric.change)}%
              </div>
            </div>
            <p className="font-display text-2xl">{metric.value}</p>
          </motion.div>)}
      </div>

      {/* Persona Engagement Section */}
      <div className="space-y-6">
        <div className="flex items-center gap-2 mb-6">
          <Users className="w-5 h-5 text-primary" />
          <h2 className="font-display text-lg tracking-wide">PERSONA ENGAGEMENT</h2>
        </div>

        {/* Persona Engagement Trends */}
        <div className="bg-card border border-border p-6 rounded-lg">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h3 className="font-display text-lg tracking-wide">PERSONA ENGAGEMENT OVER TIME</h3>
                <p className="text-sm text-muted-foreground">Monthly engagement by persona role</p>
              </div>
            </div>
          </div>

          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={personaEngagementTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickFormatter={value => `${(value / 1000).toFixed(1)}K`} />
                <Tooltip contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px'
              }} />
                <Legend wrapperStyle={{
                fontSize: '11px'
              }} iconSize={8} />
                <Area type="monotone" dataKey="CMO" stackId="1" stroke={PERSONA_COLORS[0]} fill={PERSONA_COLORS[0]} fillOpacity={0.6} />
                <Area type="monotone" dataKey="Administrator" stackId="1" stroke={PERSONA_COLORS[1]} fill={PERSONA_COLORS[1]} fillOpacity={0.6} />
                <Area type="monotone" dataKey="Cardiology Head" stackId="1" stroke={PERSONA_COLORS[2]} fill={PERSONA_COLORS[2]} fillOpacity={0.6} />
                <Area type="monotone" dataKey="IT Director" stackId="1" stroke={PERSONA_COLORS[3]} fill={PERSONA_COLORS[3]} fillOpacity={0.6} />
                <Area type="monotone" dataKey="Nursing Officer" stackId="1" stroke={PERSONA_COLORS[4]} fill={PERSONA_COLORS[4]} fillOpacity={0.6} />
                <Area type="monotone" dataKey="Procurement" stackId="1" stroke={PERSONA_COLORS[5]} fill={PERSONA_COLORS[5]} fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Persona Cards */}
          <div className="bg-card border border-border p-6 rounded-lg">
            <h3 className="font-display tracking-wide mb-6">PERSONA DETAILS</h3>
            <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
              {carePlusData.personas.map((persona, index) => <motion.div key={persona.id} initial={{
              opacity: 0,
              x: -10
            }} animate={{
              opacity: 1,
              x: 0
            }} transition={{
              delay: index * 0.1
            }} className="p-4 rounded-lg border border-border hover:border-primary/50 transition-all cursor-pointer group">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-medium" style={{
                  backgroundColor: PERSONA_COLORS[index % PERSONA_COLORS.length]
                }}>
                      {persona.avatar}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{persona.name}</p>
                      <p className="text-xs text-muted-foreground">{persona.role}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-primary">{persona.engagementRate}</p>
                      <p className="text-xs text-muted-foreground">Engagement</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="p-2 bg-muted/30 rounded">
                      <p className="text-xs text-muted-foreground">Reach</p>
                      <p className="text-sm font-medium">{persona.reachPotential}</p>
                    </div>
                    <div className="p-2 bg-muted/30 rounded">
                      <p className="text-xs text-muted-foreground">Department</p>
                      <p className="text-sm font-medium truncate">{persona.department.split(' ')[0]}</p>
                    </div>
                    <div className="p-2 bg-muted/30 rounded">
                      <p className="text-xs text-muted-foreground">Experience</p>
                      <p className="text-sm font-medium">{persona.experience}</p>
                    </div>
                  </div>
                </motion.div>)}
            </div>
          </div>

          {/* Platform Performance */}
          <div className="bg-card border border-border p-6 rounded-lg">
            <h3 className="font-display tracking-wide mb-6">PLATFORM PERFORMANCE</h3>
            
            <div className="space-y-4">
              {platformPerformance.map((platform, index) => <motion.div key={platform.platform} initial={{
              opacity: 0,
              x: 10
            }} animate={{
              opacity: 1,
              x: 0
            }} transition={{
              delay: index * 0.1
            }} className="p-4 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", platform.color)}>
                        <span className="text-white text-xs font-bold">
                          {platform.platform[0]}
                        </span>
                      </div>
                      <span className="font-medium text-sm">{platform.platform}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">{platform.impressions} imp.</span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-3">
                    <div className="text-center p-2 bg-muted/30 rounded">
                      <p className="text-xs text-muted-foreground">Engagement</p>
                      <p className="font-display text-sm text-primary">{platform.engagement}</p>
                    </div>
                    <div className="text-center p-2 bg-muted/30 rounded">
                      <p className="text-xs text-muted-foreground">Leads</p>
                      <p className="font-display text-sm text-primary">{platform.leads}</p>
                    </div>
                    <div className="text-center p-2 bg-muted/30 rounded">
                      <p className="text-xs text-muted-foreground">Conv. Rate</p>
                      <p className="font-display text-sm text-primary">
                        {(platform.leads / parseInt(platform.impressions.replace('K', '000')) * 100).toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </motion.div>)}
            </div>
          </div>
        </div>

        {/* Top Content by Persona */}
        <div className="bg-card border border-border p-6 rounded-lg">
          <h3 className="font-display tracking-wide mb-6">TOP PERFORMING CONTENT BY PERSONA</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-xs font-display tracking-wide text-muted-foreground">CONTENT</th>
                  <th className="text-left py-3 px-4 text-xs font-display tracking-wide text-muted-foreground">PERSONA</th>
                  <th className="text-left py-3 px-4 text-xs font-display tracking-wide text-muted-foreground">PLATFORM</th>
                  <th className="text-right py-3 px-4 text-xs font-display tracking-wide text-muted-foreground">IMPRESSIONS</th>
                  <th className="text-right py-3 px-4 text-xs font-display tracking-wide text-muted-foreground">ENGAGEMENT</th>
                  <th className="text-right py-3 px-4 text-xs font-display tracking-wide text-muted-foreground">CONVERSIONS</th>
                </tr>
              </thead>
              <tbody>
                {carePlusData.contentPerformance.map((content, index) => <motion.tr key={content.id} initial={{
                opacity: 0,
                y: 10
              }} animate={{
                opacity: 1,
                y: 0
              }} transition={{
                delay: index * 0.1
              }} className="border-b border-border hover:bg-muted/30">
                    <td className="py-3 px-4 text-sm">{content.title}</td>
                    <td className="py-3 px-4">
                      <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                        {content.persona}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-muted-foreground">{content.platform}</td>
                    <td className="py-3 px-4 text-sm text-right">{content.impressions}</td>
                    <td className="py-3 px-4 text-sm text-right text-success">{content.engagementRate}</td>
                    <td className="py-3 px-4 text-sm text-right font-medium text-primary">{content.conversions}</td>
                  </motion.tr>)}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </motion.div>;
}