import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  PenTool, 
  Sparkles, 
  FileText, 
  Users,
  ChevronRight,
  Clock,
  Target,
  Zap,
  Layers
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const contentTypes = [
  { id: "social", label: "Social Post", icon: "📱", description: "LinkedIn, Twitter, Instagram", count: 8 },
  { id: "blog", label: "Blog Article", icon: "📝", description: "Long-form content", count: 3 },
  { id: "video", label: "Video Script", icon: "🎬", description: "Reels, shorts, presentations", count: 4 },
  { id: "email", label: "Email Campaign", icon: "📧", description: "Newsletters, drip sequences", count: 2 },
  { id: "whitepaper", label: "Whitepaper", icon: "📊", description: "Research & reports", count: 1 },
  { id: "infographic", label: "Infographic", icon: "📈", description: "Data visualization", count: 2 },
];

const recentDrafts = [
  { 
    id: "1", 
    title: "Hospital Procurement ROI Framework",
    type: "blog",
    persona: "Procurement Director",
    status: "draft",
    lastEdited: "2 hours ago",
    progress: 65
  },
  { 
    id: "2", 
    title: "AI Diagnostics: 5 Key Benefits",
    type: "social",
    persona: "Healthcare CIO",
    status: "review",
    lastEdited: "4 hours ago",
    progress: 90
  },
  { 
    id: "3", 
    title: "Patient Experience Transformation",
    type: "video",
    persona: "Hospital CEO",
    status: "draft",
    lastEdited: "1 day ago",
    progress: 40
  },
];

const templates = [
  { id: "1", name: "ROI Case Study", description: "Showcase measurable outcomes", uses: 24 },
  { id: "2", name: "Problem-Solution", description: "Address pain points directly", uses: 18 },
  { id: "3", name: "Expert Interview", description: "Thought leadership format", uses: 12 },
  { id: "4", name: "Data Storytelling", description: "Statistics with narrative", uses: 31 },
];

export function CreateTab() {
  const [selectedType, setSelectedType] = useState<string | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "In Progress", value: "8", icon: PenTool, color: "text-healthcare-teal" },
          { label: "In Review", value: "4", icon: Clock, color: "text-warning" },
          { label: "Ready to Publish", value: "6", icon: Target, color: "text-success" },
          { label: "Published This Week", value: "12", icon: Zap, color: "text-primary" },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-card border border-border p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <stat.icon className={cn("w-5 h-5", stat.color)} />
              <span className="font-display text-2xl">{stat.value}</span>
            </div>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Quick Create Section */}
      <div className="bg-card border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-display text-lg tracking-wide">QUICK CREATE</h3>
              <p className="text-sm text-muted-foreground">Select content type to start</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {contentTypes.map((type) => (
            <button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={cn(
                "p-4 border text-center transition-all",
                selectedType === type.id
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50"
              )}
            >
              <span className="text-2xl mb-2 block">{type.icon}</span>
              <span className="text-sm font-medium block mb-1">{type.label}</span>
              <span className="text-xs text-muted-foreground">{type.count} drafts</span>
            </button>
          ))}
        </div>

        <AnimatePresence>
          {selectedType && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="border-t border-border pt-6"
            >
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Creating: <span className="text-foreground font-medium">
                    {contentTypes.find(t => t.id === selectedType)?.label}
                  </span>
                </p>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setSelectedType(null)}>
                    Cancel
                  </Button>
                  <Button>
                    <Sparkles className="w-4 h-4 mr-2" /> Start with AI
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Drafts */}
        <div className="lg:col-span-2 bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-muted flex items-center justify-center">
                <FileText className="w-4 h-4 text-muted-foreground" />
              </div>
              <h3 className="font-display tracking-wide">RECENT DRAFTS</h3>
            </div>
            <Button variant="ghost" size="sm">
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>

          <div className="space-y-3">
            {recentDrafts.map((draft, index) => (
              <motion.div
                key={draft.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 border border-border hover:border-primary/50 transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-medium text-sm group-hover:text-primary transition-colors">
                      {draft.title}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Users className="w-3 h-3" /> {draft.persona}
                      </span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground">{draft.lastEdited}</span>
                    </div>
                  </div>
                  <span className={cn(
                    "px-2 py-0.5 text-[10px] font-display tracking-wide",
                    draft.status === "review" 
                      ? "bg-warning/10 text-warning" 
                      : "bg-muted text-muted-foreground"
                  )}>
                    {draft.status.toUpperCase()}
                  </span>
                </div>
                
                {/* Progress bar */}
                <div className="h-1 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${draft.progress}%` }}
                    transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                    className={cn(
                      "h-full",
                      draft.progress >= 80 ? "bg-success" : 
                      draft.progress >= 50 ? "bg-primary" : "bg-warning"
                    )}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Templates */}
        <div className="bg-card border border-border p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 bg-muted flex items-center justify-center">
              <Layers className="w-4 h-4 text-muted-foreground" />
            </div>
            <h3 className="font-display tracking-wide">TEMPLATES</h3>
          </div>

          <div className="space-y-3">
            {templates.map((template, index) => (
              <motion.button
                key={template.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="w-full p-4 border border-border hover:border-primary/50 text-left transition-all group"
              >
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium group-hover:text-primary transition-colors">
                    {template.name}
                  </p>
                  <span className="text-xs text-muted-foreground">{template.uses} uses</span>
                </div>
                <p className="text-xs text-muted-foreground">{template.description}</p>
              </motion.button>
            ))}
          </div>

          <Button variant="outline" className="w-full mt-4">
            Browse All Templates
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
