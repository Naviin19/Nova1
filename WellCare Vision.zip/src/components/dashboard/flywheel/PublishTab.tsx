import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Send, 
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Instagram,
  Linkedin,
  Twitter,
  Youtube,
  Mail,
  Eye,
  Edit3,
  MoreHorizontal
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const scheduledContent = [
  {
    id: "1",
    title: "AI Diagnostics ROI Case Study",
    platform: "linkedin",
    scheduledTime: "Today, 2:00 PM",
    status: "scheduled",
    engagement: null,
    thumbnail: "📊"
  },
  {
    id: "2", 
    title: "Patient Safety Innovation Carousel",
    platform: "instagram",
    scheduledTime: "Today, 5:30 PM",
    status: "scheduled",
    engagement: null,
    thumbnail: "🏥"
  },
  {
    id: "3",
    title: "Procurement Best Practices Thread",
    platform: "twitter",
    scheduledTime: "Tomorrow, 9:00 AM",
    status: "scheduled",
    engagement: null,
    thumbnail: "💼"
  },
  {
    id: "4",
    title: "Healthcare CIO Interview",
    platform: "youtube",
    scheduledTime: "Jan 20, 10:00 AM",
    status: "scheduled",
    engagement: null,
    thumbnail: "🎬"
  },
];

const recentlyPublished = [
  {
    id: "1",
    title: "5 Trends Shaping Hospital Procurement",
    platform: "linkedin",
    publishedTime: "2 hours ago",
    engagement: { views: "12.4K", likes: 342, comments: 28, shares: 45 }
  },
  {
    id: "2",
    title: "MedTech Innovation Spotlight",
    platform: "instagram",
    publishedTime: "Yesterday",
    engagement: { views: "8.2K", likes: 1204, comments: 67, shares: 89 }
  },
  {
    id: "3",
    title: "Weekly Healthcare Digest",
    platform: "email",
    publishedTime: "2 days ago",
    engagement: { views: "4.8K", likes: null, comments: null, shares: null, opens: "42%", clicks: "18%" }
  },
];

const platformIcons: Record<string, typeof Linkedin> = {
  linkedin: Linkedin,
  instagram: Instagram,
  twitter: Twitter,
  youtube: Youtube,
  email: Mail
};

const calendarDays = [
  { day: "Mon", date: 15, posts: 2 },
  { day: "Tue", date: 16, posts: 1 },
  { day: "Wed", date: 17, posts: 3 },
  { day: "Thu", date: 18, posts: 2, isToday: true },
  { day: "Fri", date: 19, posts: 1 },
  { day: "Sat", date: 20, posts: 0 },
  { day: "Sun", date: 21, posts: 1 },
];

export function PublishTab() {
  const [selectedDay, setSelectedDay] = useState<number>(18);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Scheduled", value: "8", icon: Clock, color: "text-warning" },
          { label: "Published Today", value: "3", icon: Send, color: "text-primary" },
          { label: "Published This Week", value: "14", icon: CheckCircle2, color: "text-success" },
          { label: "Failed/Pending", value: "1", icon: AlertCircle, color: "text-error" },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-card border border-border p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <stat.icon className={cn("w-5 h-5", stat.color)} />
              <span className="font-display text-2xl">{stat.value}</span>
            </div>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Week Calendar */}
      <div className="bg-card border border-border p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary flex items-center justify-center">
              <Calendar className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-display text-lg tracking-wide">PUBLISHING CALENDAR</h3>
              <p className="text-sm text-muted-foreground">January 2025</p>
            </div>
          </div>
          <Button>
            <Send className="w-4 h-4 mr-2" /> Schedule New
          </Button>
        </div>

        <div className="grid grid-cols-7 gap-3 mb-6">
          {calendarDays.map((day, index) => (
            <motion.button
              key={day.date}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => setSelectedDay(day.date)}
              className={cn(
                "p-4 border text-center transition-all",
                selectedDay === day.date
                  ? "border-primary bg-primary/10"
                  : day.isToday
                    ? "border-accent bg-accent/5"
                    : "border-border hover:border-primary/50"
              )}
            >
              <p className="text-xs text-muted-foreground mb-1">{day.day}</p>
              <p className={cn(
                "font-display text-lg mb-2",
                day.isToday && "text-accent"
              )}>{day.date}</p>
              {day.posts > 0 ? (
                <div className="flex justify-center gap-1">
                  {Array.from({ length: Math.min(day.posts, 3) }).map((_, i) => (
                    <div key={i} className="w-1.5 h-1.5 rounded-full bg-primary" />
                  ))}
                  {day.posts > 3 && (
                    <span className="text-[10px] text-muted-foreground">+{day.posts - 3}</span>
                  )}
                </div>
              ) : (
                <div className="h-1.5" />
              )}
            </motion.button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Scheduled Content */}
        <div className="bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-warning/10 flex items-center justify-center">
                <Clock className="w-4 h-4 text-warning" />
              </div>
              <h3 className="font-display tracking-wide">SCHEDULED</h3>
            </div>
            <span className="text-sm text-muted-foreground">{scheduledContent.length} items</span>
          </div>

          <div className="space-y-3">
            {scheduledContent.map((item, index) => {
              const PlatformIcon = platformIcons[item.platform];
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 border border-border hover:border-primary/50 transition-all group"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-muted flex items-center justify-center text-xl flex-shrink-0">
                      {item.thumbnail}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <p className="text-sm font-medium truncate pr-4">{item.title}</p>
                        <button className="p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                        </button>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1.5">
                          <PlatformIcon className="w-3.5 h-3.5 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground capitalize">{item.platform}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">•</span>
                        <span className="text-xs text-warning">{item.scheduledTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-3 pt-3 border-t border-border">
                    <Button variant="ghost" size="sm" className="flex-1">
                      <Eye className="w-3 h-3 mr-1" /> Preview
                    </Button>
                    <Button variant="ghost" size="sm" className="flex-1">
                      <Edit3 className="w-3 h-3 mr-1" /> Edit
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Recently Published */}
        <div className="bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4 text-success" />
              </div>
              <h3 className="font-display tracking-wide">RECENTLY PUBLISHED</h3>
            </div>
          </div>

          <div className="space-y-3">
            {recentlyPublished.map((item, index) => {
              const PlatformIcon = platformIcons[item.platform];
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 border border-border hover:border-primary/50 transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-sm font-medium mb-1">{item.title}</p>
                      <div className="flex items-center gap-2">
                        <PlatformIcon className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{item.publishedTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-2">
                    {item.engagement.views && (
                      <div className="text-center p-2 bg-muted/30">
                        <p className="font-display text-sm text-primary">{item.engagement.views}</p>
                        <p className="text-[10px] text-muted-foreground">Views</p>
                      </div>
                    )}
                    {item.engagement.likes !== null && (
                      <div className="text-center p-2 bg-muted/30">
                        <p className="font-display text-sm text-primary">{item.engagement.likes}</p>
                        <p className="text-[10px] text-muted-foreground">Likes</p>
                      </div>
                    )}
                    {item.engagement.comments !== null && (
                      <div className="text-center p-2 bg-muted/30">
                        <p className="font-display text-sm text-primary">{item.engagement.comments}</p>
                        <p className="text-[10px] text-muted-foreground">Comments</p>
                      </div>
                    )}
                    {item.engagement.shares !== null && (
                      <div className="text-center p-2 bg-muted/30">
                        <p className="font-display text-sm text-primary">{item.engagement.shares}</p>
                        <p className="text-[10px] text-muted-foreground">Shares</p>
                      </div>
                    )}
                    {item.engagement.opens && (
                      <div className="text-center p-2 bg-muted/30 col-span-2">
                        <p className="font-display text-sm text-primary">{item.engagement.opens}</p>
                        <p className="text-[10px] text-muted-foreground">Open Rate</p>
                      </div>
                    )}
                    {item.engagement.clicks && (
                      <div className="text-center p-2 bg-muted/30 col-span-2">
                        <p className="font-display text-sm text-primary">{item.engagement.clicks}</p>
                        <p className="text-[10px] text-muted-foreground">Click Rate</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
