import { motion } from "framer-motion";
import { 
  Lightbulb, 
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Target,
  Users,
  FileText,
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const insights = [
  {
    id: "1",
    type: "success",
    title: "Video content outperforms static by 3.2x",
    description: "YouTube and Instagram Reels showing highest engagement rates. Consider shifting 20% of static content budget to video production.",
    impact: "High",
    actionable: true,
    category: "Content Type"
  },
  {
    id: "2",
    type: "opportunity",
    title: "Healthcare CIO segment underserved",
    description: "CIO persona shows highest conversion rate (4.8%) but receives only 15% of content. Significant growth opportunity.",
    impact: "High",
    actionable: true,
    category: "Audience"
  },
  {
    id: "3",
    type: "warning",
    title: "Email open rates declining",
    description: "Weekly newsletter open rates down 12% month-over-month. Subject line A/B testing recommended.",
    impact: "Medium",
    actionable: true,
    category: "Channel"
  },
  {
    id: "4",
    type: "success",
    title: "ROI-focused messaging resonates",
    description: "Content featuring specific ROI numbers sees 2.4x higher engagement than feature-focused content.",
    impact: "High",
    actionable: true,
    category: "Messaging"
  },
  {
    id: "5",
    type: "info",
    title: "Tuesday posts perform best",
    description: "LinkedIn posts published between 9-11 AM on Tuesdays consistently outperform other days by 28%.",
    impact: "Medium",
    actionable: true,
    category: "Timing"
  },
];

const recommendations = [
  {
    id: "1",
    title: "Create CIO-focused video series",
    description: "Based on persona engagement data, develop a 6-part video series addressing CIO pain points",
    effort: "Medium",
    potentialImpact: "+35% CIO engagement",
    status: "new"
  },
  {
    id: "2",
    title: "Revamp email subject lines",
    description: "Implement personalization and urgency in subject lines based on successful patterns",
    effort: "Low",
    potentialImpact: "+15% open rates",
    status: "in_progress"
  },
  {
    id: "3",
    title: "Launch Tuesday content push",
    description: "Reschedule top-tier content for Tuesday morning slots across all channels",
    effort: "Low",
    potentialImpact: "+20% engagement",
    status: "new"
  },
];

const patternRecognition = [
  { pattern: "ROI messaging", change: 42, direction: "up" },
  { pattern: "Video content", change: 38, direction: "up" },
  { pattern: "Case studies", change: 28, direction: "up" },
  { pattern: "Feature lists", change: -15, direction: "down" },
  { pattern: "Generic headers", change: -22, direction: "down" },
];

const feedbackLoop = [
  { stage: "Create", insight: "12 new story ideas generated from insights", count: 12 },
  { stage: "Publish", insight: "8 optimized posting times identified", count: 8 },
  { stage: "Measure", insight: "15 performance patterns detected", count: 15 },
  { stage: "Learn", insight: "5 actionable recommendations ready", count: 5 },
];

const getTypeConfig = (type: string) => {
  switch (type) {
    case "success":
      return { icon: CheckCircle2, color: "text-success", bg: "bg-success/10", border: "border-success/20" };
    case "warning":
      return { icon: AlertTriangle, color: "text-warning", bg: "bg-warning/10", border: "border-warning/20" };
    case "opportunity":
      return { icon: TrendingUp, color: "text-primary", bg: "bg-primary/10", border: "border-primary/20" };
    default:
      return { icon: Lightbulb, color: "text-healthcare-sky", bg: "bg-healthcare-sky/10", border: "border-healthcare-sky/20" };
  }
};

export function LearnTab() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      {/* Feedback Loop Banner */}
      <div className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 border border-primary/20 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary flex items-center justify-center">
              <RefreshCw className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-display text-lg tracking-wide">LEARNING LOOP ACTIVE</h3>
              <p className="text-sm text-muted-foreground">Insights flowing back into content creation</p>
            </div>
          </div>
          <Button>
            <Sparkles className="w-4 h-4 mr-2" /> Apply All Insights
          </Button>
        </div>

        <div className="grid grid-cols-4 gap-4">
          {feedbackLoop.map((item, index) => (
            <motion.div
              key={item.stage}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card/50 backdrop-blur border border-border p-4 text-center"
            >
              <p className="font-display text-sm tracking-wide mb-1">{item.stage}</p>
              <p className="font-display text-2xl text-primary mb-1">{item.count}</p>
              <p className="text-xs text-muted-foreground">{item.insight}</p>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Key Insights */}
        <div className="lg:col-span-2 bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-muted flex items-center justify-center">
                <Lightbulb className="w-4 h-4 text-muted-foreground" />
              </div>
              <h3 className="font-display tracking-wide">KEY INSIGHTS</h3>
            </div>
            <span className="text-sm text-muted-foreground">{insights.length} new</span>
          </div>

          <div className="space-y-3">
            {insights.map((insight, index) => {
              const config = getTypeConfig(insight.type);
              return (
                <motion.div
                  key={insight.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={cn(
                    "p-4 border transition-all hover:shadow-md",
                    config.border
                  )}
                >
                  <div className="flex items-start gap-4">
                    <div className={cn("w-8 h-8 flex items-center justify-center flex-shrink-0", config.bg)}>
                      <config.icon className={cn("w-4 h-4", config.color)} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-1">
                        <p className="text-sm font-medium">{insight.title}</p>
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "px-2 py-0.5 text-[10px] font-display",
                            insight.impact === "High" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                          )}>
                            {insight.impact.toUpperCase()}
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{insight.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">{insight.category}</span>
                        {insight.actionable && (
                          <Button variant="ghost" size="sm" className="h-6 text-xs">
                            Apply <ArrowRight className="w-3 h-3 ml-1" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Pattern Recognition */}
        <div className="space-y-6">
          <div className="bg-card border border-border p-6">
            <h3 className="font-display tracking-wide mb-6">PATTERN TRENDS</h3>
            
            <div className="space-y-4">
              {patternRecognition.map((pattern, index) => (
                <motion.div
                  key={pattern.pattern}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center justify-between"
                >
                  <span className="text-sm">{pattern.pattern}</span>
                  <div className={cn(
                    "flex items-center gap-1 text-sm font-medium",
                    pattern.direction === "up" ? "text-success" : "text-error"
                  )}>
                    {pattern.direction === "up" ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    {pattern.direction === "up" ? "+" : ""}{pattern.change}%
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-card border border-border p-6">
            <h3 className="font-display tracking-wide mb-6">RECOMMENDATIONS</h3>
            
            <div className="space-y-3">
              {recommendations.map((rec, index) => (
                <motion.div
                  key={rec.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 border border-border hover:border-primary/50 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-2">
                    <p className="text-sm font-medium">{rec.title}</p>
                    <span className={cn(
                      "px-2 py-0.5 text-[10px] font-display",
                      rec.status === "in_progress" ? "bg-warning/10 text-warning" : "bg-success/10 text-success"
                    )}>
                      {rec.status === "in_progress" ? "IN PROGRESS" : "NEW"}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{rec.description}</p>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Effort: {rec.effort}</span>
                    <span className="text-success font-medium">{rec.potentialImpact}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
