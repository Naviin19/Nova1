import { motion } from "framer-motion";
import { Eye, Users, Building2, TrendingUp, ExternalLink, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface ObservationHubProps {
  brandId?: string;
}

interface Observation {
  type: "customer" | "competition" | "market";
  title: string;
  insight: string;
  behavior?: string;
  source: string;
  timestamp: string;
  importance: "high" | "medium" | "low";
}

const observations: Observation[] = [
  {
    type: "market",
    title: "Telemedicine Adoption Surge",
    insight: "Post-pandemic video consultations have stabilized at 25% of total OPD visits",
    behavior: "Patients prefer video consultations for follow-ups and minor ailments",
    source: "Internal Analytics",
    timestamp: "2h ago",
    importance: "high",
  },
  {
    type: "competition",
    title: "Apollo Hospitals AI Launch",
    insight: "Launched AI-powered diagnostic center with 15-minute cancer screening capability",
    source: "Meta Ad Library",
    timestamp: "4h ago",
    importance: "high",
  },
  {
    type: "customer",
    title: "Corporate Insurance Growth",
    insight: "Corporate health insurance coverage expanded 28% - employees comparing hospital networks",
    behavior: "Q1 sees highest insurance renewals and network additions",
    source: "Industry Report",
    timestamp: "1d ago",
    importance: "high",
  },
  {
    type: "market",
    title: "Medical Tourism Surge",
    insight: "International patient inquiries up 45% from Middle East and Africa regions",
    behavior: "Patients researching online 6-8 weeks before travel",
    source: "Patient Analytics",
    timestamp: "3d ago",
    importance: "medium",
  },
];

const typeConfig = {
  customer: { icon: Users, color: "text-healthcare-teal", bg: "bg-healthcare-teal/10", label: "Customer" },
  competition: { icon: Building2, color: "text-warning", bg: "bg-warning/10", label: "Competitor" },
  market: { icon: TrendingUp, color: "text-healthcare-sky", bg: "bg-healthcare-sky/10", label: "Market" },
};

export function ObservationHub({ brandId = "careplus-hospitals" }: ObservationHubProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5, duration: 0.5 }}
      className="bg-card border border-border rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Eye className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-display text-lg tracking-wide">OBSERVATION HUB</h3>
            <p className="text-sm text-muted-foreground">CarePlus market intelligence</p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-medium">
          <Zap className="w-3 h-3" />
          4 NEW
        </span>
      </div>

      <div className="space-y-3">
        {observations.map((obs, index) => {
          const config = typeConfig[obs.type];
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + index * 0.1, duration: 0.3 }}
              className="group p-4 rounded-xl border border-border hover:border-primary/30 transition-all cursor-pointer"
            >
              <div className="flex items-start gap-3">
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0", config.bg)}>
                  <config.icon className={cn("w-4 h-4", config.color)} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-foreground">{obs.title}</p>
                      <span className={cn("text-[10px] px-1.5 py-0.5 rounded", config.bg, config.color)}>
                        {config.label}
                      </span>
                    </div>
                    {obs.importance === "high" && (
                      <span className="px-2 py-0.5 text-[10px] rounded-full bg-error/10 text-error font-medium">
                        HIGH
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">{obs.insight}</p>
                  {obs.behavior && (
                    <p className="text-xs text-primary/80 mb-2 italic">→ {obs.behavior}</p>
                  )}
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <ExternalLink className="w-3 h-3" />
                      {obs.source}
                    </span>
                    <span>{obs.timestamp}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <Link 
        to={`/brand/${brandId}/observations`}
        className="w-full mt-4 py-2.5 rounded-xl border-2 border-dashed border-border text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors flex items-center justify-center gap-2"
      >
        View All Observations
        <span className="text-xs bg-muted px-2 py-0.5 rounded-full">O-B-I-P Flow</span>
      </Link>
    </motion.div>
  );
}
