import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Sparkles, 
  Image, 
  Video, 
  FileText, 
  Wand2, 
  CheckCircle2,
  Layout,
  Type,
  Palette,
  Target,
  Clock,
  BarChart3,
  Download,
  Copy,
  RefreshCw,
  Layers,
  Eye,
  Zap
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ContentBrief {
  title: string;
  type: "social" | "blog" | "video" | "carousel";
  persona: string;
  story: string;
}

interface ContentBriefGeneratorProps {
  brief?: ContentBrief;
}

const mockBrief: ContentBrief = {
  title: "HealthFirst Cardiac Care Excellence",
  type: "social",
  persona: "Dr. Sarah Chen",
  story: "Dr. Sarah Chen showcases the advanced cardiac monitoring technology that helped save a patient's life through early detection."
};

const generationSteps = [
  { id: 1, label: "Analyzing Story Context", icon: FileText },
  { id: 2, label: "Extracting Visual Elements", icon: Image },
  { id: 3, label: "Building Layout Structure", icon: Layout },
  { id: 4, label: "Applying Brand Guidelines", icon: Palette },
  { id: 5, label: "Optimizing for Engagement", icon: Target },
  { id: 6, label: "Finalizing Content Brief", icon: CheckCircle2 },
];

const generatedMockup = {
  layout: {
    type: "Hero with Feature Grid",
    dimensions: "1080x1080",
    grid: "2x2 feature blocks below hero"
  },
  visual: {
    primaryImage: "Dr. Chen with cardiac monitoring equipment",
    overlay: "Gradient from brand-teal to transparent",
    icons: ["Heart monitor", "Stethoscope", "ECG wave", "Shield check"]
  },
  typography: {
    headline: "Market Deco Bold, 48px",
    subheadline: "Inter Medium, 24px",
    body: "Inter Regular, 16px",
    cta: "Market Deco Semibold, 18px"
  },
  colors: {
    primary: "#0D9488",
    secondary: "#0EA5E9",
    accent: "#F59E0B",
    background: "#F0FDFA",
    text: "#134E4A"
  },
  content: {
    headline: "Advanced Cardiac Care That Saves Lives",
    subheadline: "Early Detection Through Innovation",
    body: "Our state-of-the-art cardiac monitoring technology helped identify a critical condition 48 hours before symptoms appeared.",
    cta: "Learn More About Our Technology",
    hashtags: ["#CardiacCare", "#HealthcareInnovation", "#PatientFirst", "#HealthFirst"]
  },
  metrics: {
    targetEngagement: "4.2%",
    estimatedReach: "15,000+",
    bestPostTime: "Tuesday 10:00 AM",
    audienceMatch: "92%"
  }
};

const jsonStructure = `{
  "content_brief": {
    "id": "cb_001",
    "version": "1.0",
    "created_at": "${new Date().toISOString()}",
    
    "source": {
      "story_id": "vs_cardiac_001",
      "persona": "Dr. Sarah Chen",
      "observation_type": "behavior"
    },
    
    "content_spec": {
      "type": "social_post",
      "platform": "linkedin",
      "format": "image_with_text",
      "dimensions": {
        "width": 1080,
        "height": 1080
      }
    },
    
    "design_structure": {
      "layout": "hero_feature_grid",
      "sections": [
        {
          "type": "hero",
          "height": "60%",
          "elements": ["primary_image", "gradient_overlay", "headline"]
        },
        {
          "type": "feature_grid",
          "height": "40%",
          "columns": 2,
          "rows": 2,
          "elements": ["icon_blocks"]
        }
      ]
    },
    
    "measurement": {
      "kpis": ["engagement_rate", "reach", "saves", "shares"],
      "targets": {
        "engagement_rate": 0.042,
        "reach": 15000,
        "saves": 500,
        "shares": 200
      },
      "tracking": {
        "utm_source": "linkedin",
        "utm_medium": "social",
        "utm_campaign": "cardiac_care_2024"
      }
    }
  }
}`;

export function ContentBriefGenerator({ brief = mockBrief }: ContentBriefGeneratorProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [activeTab, setActiveTab] = useState<"preview" | "structure" | "json">("preview");

  const handleGenerate = () => {
    setIsGenerating(true);
    setCurrentStep(0);
    setShowResult(false);

    // Simulate generation steps
    generationSteps.forEach((_, index) => {
      setTimeout(() => {
        setCurrentStep(index + 1);
        if (index === generationSteps.length - 1) {
          setTimeout(() => {
            setIsGenerating(false);
            setShowResult(true);
          }, 500);
        }
      }, (index + 1) * 800);
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20">
            <Wand2 className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">AI Content Brief Generator</h2>
            <p className="text-sm text-muted-foreground">Transform stories into production-ready content briefs</p>
          </div>
        </div>
        <Button 
          onClick={handleGenerate} 
          disabled={isGenerating}
          className="bg-gradient-to-r from-primary to-secondary hover:opacity-90"
        >
          {isGenerating ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 mr-2" />
              Generate Brief
            </>
          )}
        </Button>
      </div>

      {/* Source Story Card */}
      <motion.div 
        className="p-4 rounded-xl bg-gradient-to-r from-primary/5 to-secondary/5 border border-primary/20"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-white shadow-sm">
            <FileText className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                Source Story
              </span>
              <span className="text-xs text-muted-foreground">{brief.persona}</span>
            </div>
            <h3 className="font-semibold text-foreground mb-1">{brief.title}</h3>
            <p className="text-sm text-muted-foreground">{brief.story}</p>
          </div>
        </div>
      </motion.div>

      {/* Generation Progress */}
      <AnimatePresence>
        {isGenerating && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="p-6 rounded-xl bg-card border border-border">
              <div className="flex items-center gap-2 mb-4">
                <Zap className="h-4 w-4 text-amber-500" />
                <span className="text-sm font-medium text-foreground">AI Processing</span>
              </div>
              <div className="space-y-3">
                {generationSteps.map((step, index) => (
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ 
                      opacity: currentStep >= step.id ? 1 : 0.4,
                      x: 0
                    }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className={cn(
                      "p-1.5 rounded-lg transition-all duration-300",
                      currentStep >= step.id 
                        ? "bg-primary/20 text-primary" 
                        : "bg-muted text-muted-foreground"
                    )}>
                      {currentStep > step.id ? (
                        <CheckCircle2 className="h-4 w-4" />
                      ) : (
                        <step.icon className={cn(
                          "h-4 w-4",
                          currentStep === step.id && "animate-pulse"
                        )} />
                      )}
                    </div>
                    <span className={cn(
                      "text-sm transition-colors",
                      currentStep >= step.id ? "text-foreground" : "text-muted-foreground"
                    )}>
                      {step.label}
                    </span>
                    {currentStep === step.id && (
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 0.8 }}
                        className="h-1 bg-gradient-to-r from-primary to-secondary rounded-full flex-1 max-w-[100px]"
                      />
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Generated Result */}
      <AnimatePresence>
        {showResult && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {/* Tab Navigation */}
            <div className="flex items-center gap-1 p-1 bg-muted rounded-xl">
              {[
                { id: "preview", label: "Visual Preview", icon: Eye },
                { id: "structure", label: "Design Structure", icon: Layers },
                { id: "json", label: "JSON Brief", icon: FileText },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all",
                    activeTab === tab.id
                      ? "bg-white text-foreground shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <tab.icon className="h-4 w-4" />
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="min-h-[500px]">
              <AnimatePresence mode="wait">
                {activeTab === "preview" && (
                  <motion.div
                    key="preview"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="grid grid-cols-1 lg:grid-cols-2 gap-6"
                  >
                    {/* Visual Mockup */}
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium text-muted-foreground">GENERATED MOCKUP</h3>
                      <div className="aspect-square rounded-2xl overflow-hidden bg-gradient-to-br from-teal-50 to-cyan-50 border border-border shadow-xl relative">
                        {/* Hero Section */}
                        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-teal-900/80" />
                        <div className="absolute top-0 left-0 right-0 h-[60%] bg-gradient-to-br from-primary/20 to-secondary/30 flex items-center justify-center">
                          <div className="text-center p-6">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/90 text-primary text-xs font-medium mb-4">
                              <Sparkles className="h-3 w-3" />
                              HealthFirst Medical
                            </div>
                            <h2 className="text-2xl font-bold text-teal-900 mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                              {generatedMockup.content.headline}
                            </h2>
                            <p className="text-sm text-teal-700">
                              {generatedMockup.content.subheadline}
                            </p>
                          </div>
                        </div>
                        
                        {/* Feature Grid */}
                        <div className="absolute bottom-0 left-0 right-0 h-[40%] grid grid-cols-2 gap-2 p-4">
                          {[
                            { icon: "❤️", label: "Cardiac Monitoring" },
                            { icon: "🔬", label: "Early Detection" },
                            { icon: "👨‍⚕️", label: "Expert Care" },
                            { icon: "🛡️", label: "Patient Safety" },
                          ].map((feature, i) => (
                            <motion.div
                              key={i}
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: 0.3 + i * 0.1 }}
                              className="bg-white/95 backdrop-blur rounded-xl p-3 flex flex-col items-center justify-center shadow-sm"
                            >
                              <span className="text-2xl mb-1">{feature.icon}</span>
                              <span className="text-xs font-medium text-teal-800 text-center">{feature.label}</span>
                            </motion.div>
                          ))}
                        </div>

                        {/* CTA */}
                        <div className="absolute bottom-4 left-4 right-4">
                          <div className="flex flex-wrap gap-1 justify-center">
                            {generatedMockup.content.hashtags.map((tag, i) => (
                              <span key={i} className="text-[10px] text-teal-600 bg-teal-50/80 px-2 py-0.5 rounded-full">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Regenerate
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Download className="h-4 w-4 mr-2" />
                          Export
                        </Button>
                      </div>
                    </div>

                    {/* Metrics & Details */}
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium text-muted-foreground">PREDICTED PERFORMANCE</h3>
                      
                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { label: "Target Engagement", value: generatedMockup.metrics.targetEngagement, icon: Target, color: "text-primary" },
                          { label: "Est. Reach", value: generatedMockup.metrics.estimatedReach, icon: BarChart3, color: "text-secondary" },
                          { label: "Best Post Time", value: generatedMockup.metrics.bestPostTime, icon: Clock, color: "text-amber-500" },
                          { label: "Audience Match", value: generatedMockup.metrics.audienceMatch, icon: CheckCircle2, color: "text-emerald-500" },
                        ].map((metric, i) => (
                          <motion.div
                            key={i}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2 + i * 0.1 }}
                            className="p-4 rounded-xl bg-card border border-border"
                          >
                            <div className={cn("flex items-center gap-2 mb-2", metric.color)}>
                              <metric.icon className="h-4 w-4" />
                              <span className="text-xs font-medium">{metric.label}</span>
                            </div>
                            <div className="text-2xl font-bold text-foreground">{metric.value}</div>
                          </motion.div>
                        ))}
                      </div>

                      {/* Content Copy */}
                      <div className="p-4 rounded-xl bg-card border border-border space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-foreground">Generated Copy</span>
                          <Button variant="ghost" size="sm">
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="space-y-2 text-sm">
                          <p className="font-semibold text-foreground">{generatedMockup.content.headline}</p>
                          <p className="text-muted-foreground">{generatedMockup.content.body}</p>
                          <p className="text-primary font-medium">{generatedMockup.content.cta} →</p>
                        </div>
                      </div>

                      {/* Platform Variants */}
                      <div className="p-4 rounded-xl bg-card border border-border">
                        <span className="text-sm font-medium text-foreground block mb-3">Platform Variants</span>
                        <div className="flex gap-2">
                          {["LinkedIn", "Instagram", "Twitter", "Facebook"].map((platform) => (
                            <button
                              key={platform}
                              className="px-3 py-1.5 rounded-lg bg-muted text-sm text-muted-foreground hover:bg-primary/10 hover:text-primary transition-colors"
                            >
                              {platform}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === "structure" && (
                  <motion.div
                    key="structure"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="grid grid-cols-1 md:grid-cols-3 gap-4"
                  >
                    {/* Layout */}
                    <div className="p-5 rounded-xl bg-card border border-border">
                      <div className="flex items-center gap-2 mb-4">
                        <Layout className="h-5 w-5 text-primary" />
                        <span className="font-semibold text-foreground">Layout</span>
                      </div>
                      <div className="space-y-3 text-sm">
                        <div>
                          <span className="text-muted-foreground">Type:</span>
                          <span className="ml-2 text-foreground">{generatedMockup.layout.type}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Dimensions:</span>
                          <span className="ml-2 text-foreground">{generatedMockup.layout.dimensions}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Grid:</span>
                          <span className="ml-2 text-foreground">{generatedMockup.layout.grid}</span>
                        </div>
                      </div>
                    </div>

                    {/* Typography */}
                    <div className="p-5 rounded-xl bg-card border border-border">
                      <div className="flex items-center gap-2 mb-4">
                        <Type className="h-5 w-5 text-secondary" />
                        <span className="font-semibold text-foreground">Typography</span>
                      </div>
                      <div className="space-y-3 text-sm">
                        {Object.entries(generatedMockup.typography).map(([key, value]) => (
                          <div key={key}>
                            <span className="text-muted-foreground capitalize">{key}:</span>
                            <span className="ml-2 text-foreground text-xs">{value}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Colors */}
                    <div className="p-5 rounded-xl bg-card border border-border">
                      <div className="flex items-center gap-2 mb-4">
                        <Palette className="h-5 w-5 text-amber-500" />
                        <span className="font-semibold text-foreground">Color Palette</span>
                      </div>
                      <div className="space-y-2">
                        {Object.entries(generatedMockup.colors).map(([name, color]) => (
                          <div key={name} className="flex items-center gap-2">
                            <div 
                              className="w-6 h-6 rounded-md border border-border"
                              style={{ backgroundColor: color }}
                            />
                            <span className="text-sm capitalize text-muted-foreground">{name}</span>
                            <span className="text-xs text-foreground ml-auto">{color}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Visual Elements */}
                    <div className="p-5 rounded-xl bg-card border border-border md:col-span-2">
                      <div className="flex items-center gap-2 mb-4">
                        <Image className="h-5 w-5 text-emerald-500" />
                        <span className="font-semibold text-foreground">Visual Elements</span>
                      </div>
                      <div className="space-y-3 text-sm">
                        <div>
                          <span className="text-muted-foreground">Primary Image:</span>
                          <span className="ml-2 text-foreground">{generatedMockup.visual.primaryImage}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Overlay:</span>
                          <span className="ml-2 text-foreground">{generatedMockup.visual.overlay}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Icons:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {generatedMockup.visual.icons.map((icon, i) => (
                              <span key={i} className="px-2 py-0.5 bg-muted rounded text-xs">{icon}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Measurement */}
                    <div className="p-5 rounded-xl bg-card border border-border">
                      <div className="flex items-center gap-2 mb-4">
                        <BarChart3 className="h-5 w-5 text-violet-500" />
                        <span className="font-semibold text-foreground">Tracking</span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="text-muted-foreground">KPIs to Track:</div>
                        <div className="flex flex-wrap gap-1">
                          {["Engagement", "Reach", "Saves", "Shares"].map((kpi) => (
                            <span key={kpi} className="px-2 py-0.5 bg-violet-50 text-violet-700 rounded text-xs">
                              {kpi}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === "json" && (
                  <motion.div
                    key="json"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                  >
                    <div className="relative">
                      <Button
                        variant="outline"
                        size="sm"
                        className="absolute top-4 right-4 z-10"
                      >
                        <Copy className="h-4 w-4 mr-2" />
                        Copy JSON
                      </Button>
                      <pre className="p-6 rounded-xl bg-slate-900 text-slate-100 overflow-x-auto text-sm">
                        <code>{jsonStructure}</code>
                      </pre>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Empty State */}
      {!isGenerating && !showResult && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center py-16 text-center"
        >
          <div className="p-4 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 mb-4">
            <Wand2 className="h-8 w-8 text-primary" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">Ready to Generate</h3>
          <p className="text-sm text-muted-foreground max-w-md mb-6">
            Click "Generate Brief" to transform your story into a complete content brief with visual mockups, 
            design specifications, and measurement parameters.
          </p>
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Image className="h-4 w-4" />
              <span>Visual Mockups</span>
            </div>
            <div className="flex items-center gap-2">
              <Layers className="h-4 w-4" />
              <span>Design Specs</span>
            </div>
            <div className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span>Metrics</span>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
