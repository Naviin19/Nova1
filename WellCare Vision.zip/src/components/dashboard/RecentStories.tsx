import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Clock, Target, Heart, Shield, Brain, Baby } from "lucide-react";
import { cn } from "@/lib/utils";
interface Story {
  id: string;
  persona: string;
  department: string;
  sprinkleType: string;
  keyMessage: string;
  status: "draft" | "approved" | "published";
  platform: string;
  reach?: string;
}
const stories: Story[] = [{
  id: "1",
  persona: "Dr. Aisha Patel",
  department: "Cardiology",
  sprinkleType: "Success Story",
  keyMessage: "Robotic cardiac surgery reduced recovery time by 60% - patient back to work in 5 days",
  status: "published",
  platform: "LinkedIn",
  reach: "245K"
}, {
  id: "2",
  persona: "Sister Mary Joseph",
  department: "Nursing",
  sprinkleType: "Human Touch",
  keyMessage: "32 years of nursing taught me that healing starts with listening",
  status: "published",
  platform: "Instagram",
  reach: "189K"
}, {
  id: "3",
  persona: "Vikram Mehta",
  department: "IT",
  sprinkleType: "Innovation",
  keyMessage: "Our AI diagnostics detected early-stage cancer 48 hours before symptoms appeared",
  status: "approved",
  platform: "LinkedIn"
}, {
  id: "4",
  persona: "Dr. Rajesh Sharma",
  department: "Leadership",
  sprinkleType: "Vision",
  keyMessage: "Healthcare isn't about beds and equipment—it's about the 2.4 million lives we touch every year",
  status: "draft",
  platform: "Multi-platform"
}];
const statusStyles = {
  draft: "bg-muted text-muted-foreground",
  approved: "bg-warning/10 text-warning",
  published: "bg-success/10 text-success"
};
const departmentIcons: Record<string, React.ReactNode> = {
  Cardiology: <Heart className="w-4 h-4" />,
  Nursing: <Shield className="w-4 h-4" />,
  IT: <Brain className="w-4 h-4" />,
  Leadership: <Target className="w-4 h-4" />
};
export function RecentStories() {
  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display text-lg tracking-wide">RECENT STORIES</h3>
        <button className="text-sm text-primary flex items-center gap-1 hover:underline">
          View all <ArrowRight className="w-4 h-4" />
        </button>
      </div>
      <div className="space-y-4">
        {stories.map((story, index) => (
          <motion.div
            key={story.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 border border-border rounded-lg hover:border-primary/50 transition-colors"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  {departmentIcons[story.department] || <Sparkles className="w-4 h-4" />}
                </div>
                <div>
                  <p className="font-medium text-sm">{story.persona}</p>
                  <p className="text-xs text-muted-foreground">{story.department}</p>
                </div>
              </div>
              <span className={cn("text-xs px-2 py-1 rounded-full", statusStyles[story.status])}>
                {story.status}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-2">{story.keyMessage}</p>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {story.platform}
              </span>
              {story.reach && (
                <span className="text-primary font-medium">{story.reach} reach</span>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}