import { motion } from "framer-motion";
import { Instagram, Linkedin, Twitter, Mail, Youtube, TrendingUp, ExternalLink, Play, Image, FileText } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface ContentItem {
  id: string;
  title: string;
  platform: "instagram" | "linkedin" | "twitter" | "email" | "youtube";
  format: string;
  type: "video" | "carousel" | "article" | "story";
  persona: string;
  reach: string;
  engagement: string;
  conversions: number;
  performance: "exceeds" | "meets" | "below";
}

const topContent: ContentItem[] = [
  {
    id: "1",
    title: "Dr. Patel's Heart Surgery Innovation",
    platform: "linkedin",
    format: "Video",
    type: "video",
    persona: "Dr. Aisha Patel",
    reach: "245K",
    engagement: "5.1%",
    conversions: 89,
    performance: "exceeds",
  },
  {
    id: "2",
    title: "Patient Recovery Journey: Back to Cricket",
    platform: "instagram",
    format: "Carousel",
    type: "carousel",
    persona: "Patient Story",
    reach: "189K",
    engagement: "9.6%",
    conversions: 156,
    performance: "exceeds",
  },
  {
    id: "3",
    title: "The Future of Healthcare: AI Diagnostics",
    platform: "linkedin",
    format: "Article",
    type: "article",
    persona: "Vikram Mehta",
    reach: "67K",
    engagement: "4.8%",
    conversions: 34,
    performance: "meets",
  },
  {
    id: "4",
    title: "Nursing Excellence: 32 Years of Care",
    platform: "instagram",
    format: "Story",
    type: "story",
    persona: "Sister Mary Joseph",
    reach: "124K",
    engagement: "7.2%",
    conversions: 67,
    performance: "exceeds",
  },
];

const platformIcons = {
  instagram: Instagram,
  linkedin: Linkedin,
  twitter: Twitter,
  email: Mail,
  youtube: Youtube,
};

const platformColors = {
  instagram: "text-pink-400 bg-pink-400/10",
  linkedin: "text-blue-400 bg-blue-400/10",
  twitter: "text-sky-400 bg-sky-400/10",
  email: "text-green-400 bg-green-400/10",
  youtube: "text-red-400 bg-red-400/10",
};

const typeIcons = {
  video: Play,
  carousel: Image,
  article: FileText,
  story: Image,
};

const performanceStyles = {
  exceeds: { label: "EXCEEDS", class: "bg-success/10 text-success" },
  meets: { label: "MEETS", class: "bg-warning/10 text-warning" },
  below: { label: "BELOW", class: "bg-error/10 text-error" },
};

export function TopContent() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.8, duration: 0.5 }}
      className="bg-card border border-border rounded-xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-display text-lg tracking-wide">TOP PERFORMING CONTENT</h3>
          <p className="text-sm text-muted-foreground">CarePlus best performers this month</p>
        </div>
        <Link 
          to="/content-library"
          className="text-primary text-sm flex items-center gap-1 hover:gap-2 transition-all"
        >
          View all <ExternalLink className="w-4 h-4" />
        </Link>
      </div>

      <div className="space-y-3">
        {topContent.map((content, index) => {
          const PlatformIcon = platformIcons[content.platform];
          const TypeIcon = typeIcons[content.type];
          const perf = performanceStyles[content.performance];
          
          return (
            <motion.div
              key={content.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.9 + index * 0.1, duration: 0.3 }}
              className="flex items-center gap-4 p-4 rounded-xl bg-muted/20 border border-border hover:border-primary/30 transition-all cursor-pointer group"
            >
              <div className={cn(
                "flex items-center justify-center w-12 h-12 rounded-xl",
                platformColors[content.platform]
              )}>
                <PlatformIcon className="w-5 h-5" />
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate mb-1 group-hover:text-primary transition-colors">
                  {content.title}
                </p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <TypeIcon className="w-3 h-3" />
                  <span>{content.format}</span>
                  <span>•</span>
                  <span className="text-primary">{content.persona}</span>
                </div>
              </div>
              
              <div className="hidden md:flex items-center gap-6 text-right">
                <div>
                  <p className="text-sm font-display text-foreground">{content.reach}</p>
                  <p className="text-xs text-muted-foreground">Reach</p>
                </div>
                <div>
                  <p className="text-sm font-display text-foreground">{content.engagement}</p>
                  <p className="text-xs text-muted-foreground">Eng. Rate</p>
                </div>
                <div>
                  <p className="text-sm font-display text-success">{content.conversions}</p>
                  <p className="text-xs text-muted-foreground">Leads</p>
                </div>
                <span className={cn(
                  "px-2 py-1 text-[10px] font-medium rounded-full",
                  perf.class
                )}>
                  {perf.label}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Quick Stats */}
      <div className="mt-4 pt-4 border-t border-border grid grid-cols-3 gap-4 text-center">
        <div>
          <p className="text-xs text-muted-foreground mb-1">Total Reach</p>
          <p className="font-display text-lg text-foreground">625K</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Avg. Engagement</p>
          <p className="font-display text-lg text-primary">6.7%</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-1">Total Conversions</p>
          <p className="font-display text-lg text-success">346</p>
        </div>
      </div>
    </motion.div>
  );
}
