import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { LucideIcon, TrendingUp, TrendingDown } from "lucide-react";
interface MetricCardProps {
  title: string;
  value: string;
  change: number;
  changeLabel: string;
  icon: LucideIcon;
  status?: "success" | "warning" | "error";
  index?: number;
}
export function MetricCard({
  title,
  value,
  change,
  changeLabel,
  icon: Icon,
  status = "success",
  index = 0
}: MetricCardProps) {
  const isPositive = change >= 0;
  return;
}