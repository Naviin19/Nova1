import { createContext, useContext, useState, ReactNode } from "react";

export interface ContentBrief {
  id: string;
  observationId: string;
  observationTitle: string;
  obipFlow: {
    observation: string;
    behavior: string;
    insight: string;
    pattern: string;
  };
  sprinkle: string;
  contentType: "image" | "video" | "article";
  title: string;
  prompt: string;
  contentStructure: {
    format: string;
    dimensions: string;
    duration?: string;
    sections?: string[];
    visualStyle: string;
    tone: string;
    callToAction: string;
  };
  designSpec: {
    colorPalette: string[];
    typography: {
      headline: string;
      body: string;
    };
    layout: string;
    imagery: string;
  };
  measurementParams: {
    primaryKPI: string;
    secondaryKPIs: string[];
    targetAudience: string;
    conversionGoal: string;
    benchmarks: {
      impressions: string;
      engagement: string;
      conversion: string;
    };
  };
  status: "draft" | "ready" | "published";
  createdAt: string;
  updatedAt: string;
}

interface ContentBriefContextType {
  briefs: ContentBrief[];
  addBrief: (brief: Omit<ContentBrief, "id" | "createdAt" | "updatedAt" | "status">) => ContentBrief;
  updateBrief: (id: string, updates: Partial<ContentBrief>) => void;
  deleteBrief: (id: string) => void;
  getBriefById: (id: string) => ContentBrief | undefined;
  getBriefsByObservation: (observationId: string) => ContentBrief[];
}

const ContentBriefContext = createContext<ContentBriefContextType | undefined>(undefined);

// Initial mock briefs
const initialBriefs: ContentBrief[] = [
  {
    id: "brief-1",
    observationId: "obs-1",
    observationTitle: "Telemedicine Adoption Surge",
    obipFlow: {
      observation: "Post-pandemic video consultations have grown 340% and stabilized at 25% of total OPD visits",
      behavior: "Patients prefer video consultations for follow-ups and minor ailments",
      insight: "Convenience trumps traditional care preferences when quality is maintained",
      pattern: "Peak usage between 7-9 PM for working professionals"
    },
    sprinkle: "Subvert expectations: Show the doctor who learned more from telemedicine than patients did",
    contentType: "video",
    title: "The Doctor Who Learned to Listen Again",
    prompt: "Create a compelling video showcasing how telemedicine transformed not just patient care, but how doctors approach consultations...",
    contentStructure: {
      format: "Short-form vertical video (9:16)",
      dimensions: "1080x1920px",
      duration: "45 seconds",
      visualStyle: "Documentary-style with warm tones",
      tone: "Reflective, authentic, human",
      callToAction: "Book a telemedicine consultation"
    },
    designSpec: {
      colorPalette: ["#0D9488", "#1E3A5F", "#22D3EE", "#FFFFFF"],
      typography: {
        headline: "Montserrat Bold",
        body: "Inter Regular"
      },
      layout: "Opening hook (0-5s), Story arc (5-35s), CTA (35-45s)",
      imagery: "Real doctor testimonial, screen recordings, patient reactions"
    },
    measurementParams: {
      primaryKPI: "View-through Rate",
      secondaryKPIs: ["Shares", "Comments", "Consultation Bookings"],
      targetAudience: "Working professionals 25-45",
      conversionGoal: "Telemedicine signup",
      benchmarks: {
        impressions: "200K+",
        engagement: "5%",
        conversion: "2%"
      }
    },
    status: "published",
    createdAt: "2024-01-10T10:00:00Z",
    updatedAt: "2024-01-15T14:30:00Z"
  },
  {
    id: "brief-2",
    observationId: "obs-2",
    observationTitle: "Corporate Insurance Growth",
    obipFlow: {
      observation: "Corporate health insurance coverage expanded 28% in the last year",
      behavior: "Employees actively comparing hospital networks before enrollment",
      insight: "Network breadth is the new quality signal for HR decision-makers",
      pattern: "Q1 sees highest insurance renewals and network additions"
    },
    sprinkle: "Use specificity: Replace 'quality care' with actual outcome numbers that HR can present",
    contentType: "article",
    title: "What Your HR Doesn't Tell You About Hospital Networks",
    prompt: "Create an informative article that empowers employees to make better healthcare decisions...",
    contentStructure: {
      format: "Long-form SEO article",
      dimensions: "1500-2000 words",
      sections: ["The Network Illusion", "Numbers That Matter", "Questions to Ask HR", "CarePlus Difference"],
      visualStyle: "Data-rich infographics with storytelling",
      tone: "Authoritative, helpful, transparent",
      callToAction: "Download our Hospital Network Comparison Guide"
    },
    designSpec: {
      colorPalette: ["#0D9488", "#1E3A5F", "#22D3EE", "#FFFFFF"],
      typography: {
        headline: "Montserrat Bold",
        body: "Inter Regular"
      },
      layout: "Inverted pyramid with scannable subheads",
      imagery: "Data visualizations, comparison charts, trust badges"
    },
    measurementParams: {
      primaryKPI: "Time on Page",
      secondaryKPIs: ["Guide Downloads", "Social Shares", "Backlinks"],
      targetAudience: "HR managers, corporate employees",
      conversionGoal: "Guide download + network inquiry",
      benchmarks: {
        impressions: "50K+",
        engagement: "4% (shares)",
        conversion: "3% (downloads)"
      }
    },
    status: "published",
    createdAt: "2024-01-08T09:00:00Z",
    updatedAt: "2024-01-12T11:00:00Z"
  }
];

export function ContentBriefProvider({ children }: { children: ReactNode }) {
  const [briefs, setBriefs] = useState<ContentBrief[]>(initialBriefs);

  const addBrief = (briefData: Omit<ContentBrief, "id" | "createdAt" | "updatedAt" | "status">): ContentBrief => {
    const newBrief: ContentBrief = {
      ...briefData,
      id: `brief-${Date.now()}`,
      status: "draft",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setBriefs(prev => [newBrief, ...prev]);
    return newBrief;
  };

  const updateBrief = (id: string, updates: Partial<ContentBrief>) => {
    setBriefs(prev => prev.map(brief => 
      brief.id === id 
        ? { ...brief, ...updates, updatedAt: new Date().toISOString() }
        : brief
    ));
  };

  const deleteBrief = (id: string) => {
    setBriefs(prev => prev.filter(brief => brief.id !== id));
  };

  const getBriefById = (id: string) => {
    return briefs.find(brief => brief.id === id);
  };

  const getBriefsByObservation = (observationId: string) => {
    return briefs.filter(brief => brief.observationId === observationId);
  };

  return (
    <ContentBriefContext.Provider value={{
      briefs,
      addBrief,
      updateBrief,
      deleteBrief,
      getBriefById,
      getBriefsByObservation
    }}>
      {children}
    </ContentBriefContext.Provider>
  );
}

export function useContentBriefs() {
  const context = useContext(ContentBriefContext);
  if (context === undefined) {
    throw new Error("useContentBriefs must be used within a ContentBriefProvider");
  }
  return context;
}
