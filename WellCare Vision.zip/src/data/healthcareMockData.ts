// CarePlus Hospital Network - Comprehensive Healthcare Mock Data

export const carePlusData = {
  brand: {
    id: "careplus-hospitals",
    name: "CarePlus Hospital Network",
    tagline: "Excellence in Healthcare, Compassion in Care",
    category: "Hospital Management & Healthcare Services",
    logo: "CP",
    color: "bg-healthcare-teal",
    founded: "1995",
    locations: 12,
    employees: 8500,
    annualPatients: "2.4M"
  },

  // Healthcare Personas
  personas: [
    {
      id: "persona-1",
      name: "Dr. Rajesh Sharma",
      role: "Chief Medical Officer",
      avatar: "RS",
      department: "Executive Leadership",
      age: 52,
      experience: "28 years",
      painPoints: ["Staff retention", "Technology adoption", "Quality metrics"],
      goals: ["Improve patient outcomes", "Reduce readmission rates", "Implement AI diagnostics"],
      contentPreferences: ["Clinical research", "Leadership insights", "Industry trends"],
      engagementRate: "4.8%",
      reachPotential: "125K"
    },
    {
      id: "persona-2",
      name: "Priya Nair",
      role: "Hospital Administrator",
      avatar: "PN",
      department: "Operations",
      age: 45,
      experience: "20 years",
      painPoints: ["Budget constraints", "Regulatory compliance", "Operational efficiency"],
      goals: ["Optimize bed utilization", "Reduce operational costs", "Improve patient satisfaction"],
      contentPreferences: ["Case studies", "ROI analyses", "Best practices"],
      engagementRate: "5.2%",
      reachPotential: "89K"
    },
    {
      id: "persona-3",
      name: "Dr. Aisha Patel",
      role: "Head of Cardiology",
      avatar: "AP",
      department: "Cardiology",
      age: 48,
      experience: "22 years",
      painPoints: ["Equipment upgrades", "Patient volume", "Research funding"],
      goals: ["Launch cardiac surgery center", "Increase minimally invasive procedures", "Publish research"],
      contentPreferences: ["Medical journals", "Procedure videos", "Conference presentations"],
      engagementRate: "6.1%",
      reachPotential: "156K"
    },
    {
      id: "persona-4",
      name: "Vikram Mehta",
      role: "IT Director",
      avatar: "VM",
      department: "Information Technology",
      age: 38,
      experience: "14 years",
      painPoints: ["System integration", "Cybersecurity", "EMR optimization"],
      goals: ["Implement telemedicine", "Cloud migration", "AI-powered analytics"],
      contentPreferences: ["Tech demos", "Security updates", "Integration guides"],
      engagementRate: "3.9%",
      reachPotential: "67K"
    },
    {
      id: "persona-5",
      name: "Sister Mary Joseph",
      role: "Chief Nursing Officer",
      avatar: "MJ",
      department: "Nursing",
      age: 55,
      experience: "32 years",
      painPoints: ["Nurse burnout", "Training needs", "Patient safety"],
      goals: ["Improve nurse-to-patient ratios", "Implement bedside technology", "Reduce medical errors"],
      contentPreferences: ["Patient stories", "Training materials", "Wellness content"],
      engagementRate: "5.8%",
      reachPotential: "112K"
    },
    {
      id: "persona-6",
      name: "Arjun Krishnamurthy",
      role: "Procurement Director",
      avatar: "AK",
      department: "Supply Chain",
      age: 42,
      experience: "18 years",
      painPoints: ["Vendor management", "Cost control", "Supply disruptions"],
      goals: ["Reduce procurement costs 15%", "Improve vendor relationships", "Implement just-in-time inventory"],
      contentPreferences: ["Product comparisons", "Pricing analyses", "Vendor reviews"],
      engagementRate: "4.2%",
      reachPotential: "45K"
    }
  ],

  // Hospital Departments
  departments: [
    {
      id: "dept-cardiology",
      name: "Cardiology",
      icon: "Heart",
      head: "Dr. Aisha Patel",
      staff: 145,
      beds: 80,
      procedures: ["Angioplasty", "Bypass Surgery", "Pacemaker Implantation", "Echo", "Stress Tests"],
      annualCases: 12500,
      revenue: "₹180Cr",
      growth: "+18%",
      patientSatisfaction: 4.7
    },
    {
      id: "dept-oncology",
      name: "Oncology",
      icon: "Shield",
      head: "Dr. Sunita Reddy",
      staff: 120,
      beds: 65,
      procedures: ["Chemotherapy", "Radiation", "Immunotherapy", "Surgical Oncology", "Bone Marrow Transplant"],
      annualCases: 8200,
      revenue: "₹145Cr",
      growth: "+22%",
      patientSatisfaction: 4.8
    },
    {
      id: "dept-orthopedics",
      name: "Orthopedics",
      icon: "Bone",
      head: "Dr. Ramesh Kumar",
      staff: 95,
      beds: 55,
      procedures: ["Joint Replacement", "Spine Surgery", "Sports Medicine", "Trauma Care", "Arthroscopy"],
      annualCases: 9800,
      revenue: "₹125Cr",
      growth: "+15%",
      patientSatisfaction: 4.6
    },
    {
      id: "dept-neurology",
      name: "Neurology",
      icon: "Brain",
      head: "Dr. Kavitha Menon",
      staff: 85,
      beds: 45,
      procedures: ["Brain Surgery", "Stroke Care", "Epilepsy Treatment", "Movement Disorders", "Neuro Rehab"],
      annualCases: 6500,
      revenue: "₹110Cr",
      growth: "+20%",
      patientSatisfaction: 4.5
    },
    {
      id: "dept-pediatrics",
      name: "Pediatrics",
      icon: "Baby",
      head: "Dr. Anjali Gupta",
      staff: 110,
      beds: 70,
      procedures: ["NICU Care", "Pediatric Surgery", "Vaccinations", "Growth Monitoring", "Allergy Treatment"],
      annualCases: 18500,
      revenue: "₹85Cr",
      growth: "+12%",
      patientSatisfaction: 4.9
    },
    {
      id: "dept-emergency",
      name: "Emergency Medicine",
      icon: "Siren",
      head: "Dr. Karthik Iyer",
      staff: 165,
      beds: 40,
      procedures: ["Trauma Care", "Critical Care", "Resuscitation", "Emergency Surgery", "Poison Control"],
      annualCases: 45000,
      revenue: "₹95Cr",
      growth: "+8%",
      patientSatisfaction: 4.4
    }
  ],

  // Key Metrics Dashboard
  metrics: {
    overview: [
      { label: "Total Patients", value: "2.4M", change: "+12%", trend: "up" },
      { label: "Bed Occupancy", value: "87%", change: "+5%", trend: "up" },
      { label: "Avg Stay Duration", value: "4.2 days", change: "-8%", trend: "down" },
      { label: "Patient Satisfaction", value: "4.6/5", change: "+0.3", trend: "up" }
    ],
    financial: [
      { label: "Annual Revenue", value: "₹1,250Cr", change: "+18%", trend: "up" },
      { label: "Operating Margin", value: "22%", change: "+3%", trend: "up" },
      { label: "Cost per Patient", value: "₹45,200", change: "-5%", trend: "down" },
      { label: "Insurance Claims", value: "₹890Cr", change: "+15%", trend: "up" }
    ],
    quality: [
      { label: "Readmission Rate", value: "3.2%", change: "-1.1%", trend: "down" },
      { label: "Infection Rate", value: "0.8%", change: "-0.3%", trend: "down" },
      { label: "Mortality Rate", value: "1.2%", change: "-0.2%", trend: "down" },
      { label: "Treatment Success", value: "94%", change: "+2%", trend: "up" }
    ]
  },

  // Medical Procedures for Content
  procedures: [
    {
      id: "proc-1",
      name: "Robotic Cardiac Surgery",
      department: "Cardiology",
      successRate: "98.5%",
      avgDuration: "4.5 hours",
      recovery: "5-7 days",
      cost: "₹8-12 lakhs",
      contentPotential: "high",
      storyAngles: ["Precision medicine", "Faster recovery", "Patient testimonials"]
    },
    {
      id: "proc-2",
      name: "Minimally Invasive Spine Surgery",
      department: "Orthopedics",
      successRate: "96%",
      avgDuration: "2 hours",
      recovery: "2-3 days",
      cost: "₹3-5 lakhs",
      contentPotential: "high",
      storyAngles: ["Same-day discharge", "Return to work faster", "Technology showcase"]
    },
    {
      id: "proc-3",
      name: "Gamma Knife Radiosurgery",
      department: "Neurology",
      successRate: "95%",
      avgDuration: "1-2 hours",
      recovery: "Same day",
      cost: "₹4-6 lakhs",
      contentPotential: "high",
      storyAngles: ["Non-invasive brain treatment", "Outpatient procedure", "Precision targeting"]
    },
    {
      id: "proc-4",
      name: "CAR-T Cell Therapy",
      department: "Oncology",
      successRate: "85%",
      avgDuration: "Ongoing treatment",
      recovery: "2-4 weeks",
      cost: "₹35-45 lakhs",
      contentPotential: "very high",
      storyAngles: ["Revolutionary cancer treatment", "Last hope stories", "Research breakthrough"]
    }
  ],

  // Recent Observations
  observations: {
    market: [
      {
        id: "obs-m1",
        type: "market",
        title: "Telemedicine Adoption Surge",
        insight: "Post-pandemic telemedicine consultations have grown 340% and stabilized at 25% of total OPD visits",
        behavior: "Patients prefer video consultations for follow-ups and minor ailments",
        pattern: "Peak usage between 7-9 PM for working professionals",
        source: "Internal Analytics",
        timestamp: "2h ago",
        importance: "high"
      },
      {
        id: "obs-m2",
        type: "market",
        title: "Health Insurance Penetration",
        insight: "Corporate health insurance coverage expanded 28% in the last year",
        behavior: "Employees actively comparing hospital networks before enrollment",
        pattern: "Q1 sees highest insurance renewals and network additions",
        source: "Industry Report",
        timestamp: "1d ago",
        importance: "high"
      },
      {
        id: "obs-m3",
        type: "market",
        title: "Medical Tourism Growth",
        insight: "International patient inquiries up 45% from Middle East and Africa",
        behavior: "Patients researching online 6-8 weeks before travel",
        pattern: "Cardiac and orthopedic procedures most sought after",
        source: "Patient Analytics",
        timestamp: "3d ago",
        importance: "medium"
      }
    ],
    competitor: [
      {
        id: "obs-c1",
        type: "competitor",
        name: "Apollo Hospitals",
        activity: "high",
        insight: "Launched AI-powered diagnostic center with 15-minute cancer screening",
        adSpend: "+35%",
        campaigns: ["#HealthFirst", "#ApolloAI"],
        timestamp: "4h ago"
      },
      {
        id: "obs-c2",
        type: "competitor",
        name: "Fortis Healthcare",
        activity: "high",
        insight: "Expanded pediatric emergency network to 24/7 across all locations",
        adSpend: "+22%",
        campaigns: ["#ChildFirst", "#24x7Care"],
        timestamp: "1d ago"
      },
      {
        id: "obs-c3",
        type: "competitor",
        name: "Max Healthcare",
        activity: "medium",
        insight: "Partnered with international medical university for research collaboration",
        adSpend: "+12%",
        campaigns: ["#ResearchExcellence"],
        timestamp: "2d ago"
      }
    ]
  },

  // Content Performance Data
  contentPerformance: [
    {
      id: "content-1",
      title: "Dr. Patel's Heart Surgery Innovation",
      type: "Video",
      platform: "LinkedIn",
      status: "published",
      persona: "Dr. Aisha Patel",
      impressions: "245K",
      engagement: "12.4K",
      engagementRate: "5.1%",
      conversions: 89,
      publishedAt: "2024-01-15"
    },
    {
      id: "content-2",
      title: "Patient Recovery Journey: Back to Cricket",
      type: "Carousel",
      platform: "Instagram",
      status: "published",
      persona: "Patient Story",
      impressions: "189K",
      engagement: "18.2K",
      engagementRate: "9.6%",
      conversions: 156,
      publishedAt: "2024-01-14"
    },
    {
      id: "content-3",
      title: "The Future of Healthcare: AI Diagnostics",
      type: "Article",
      platform: "LinkedIn",
      status: "published",
      persona: "Vikram Mehta",
      impressions: "67K",
      engagement: "3.2K",
      engagementRate: "4.8%",
      conversions: 34,
      publishedAt: "2024-01-13"
    },
    {
      id: "content-4",
      title: "Nursing Excellence: 32 Years of Care",
      type: "Story",
      platform: "Facebook",
      status: "published",
      persona: "Sister Mary Joseph",
      impressions: "124K",
      engagement: "8.9K",
      engagementRate: "7.2%",
      conversions: 67,
      publishedAt: "2024-01-12"
    }
  ],

  // Scheduled Content
  scheduledContent: [
    {
      id: "sched-1",
      title: "New Robotic Surgery Wing Launch",
      type: "Video",
      platform: "LinkedIn",
      scheduledFor: "Tomorrow, 10:00 AM",
      persona: "Dr. Rajesh Sharma",
      status: "ready"
    },
    {
      id: "sched-2",
      title: "World Cancer Day Campaign",
      type: "Campaign",
      platform: "Multi-platform",
      scheduledFor: "Feb 4, 2024",
      persona: "Dr. Sunita Reddy",
      status: "in_review"
    },
    {
      id: "sched-3",
      title: "Healthcare Budget Analysis 2024",
      type: "Infographic",
      platform: "Twitter",
      scheduledFor: "Jan 20, 10:30 AM",
      persona: "Priya Nair",
      status: "ready"
    }
  ]
};

export const healthcareInsights = [
  {
    type: "success",
    title: "Video Content Outperforms",
    description: "Procedure videos generate 3.2x more engagement than static images",
    impact: "+180% reach increase",
    category: "Content Strategy"
  },
  {
    type: "opportunity",
    title: "Untapped LinkedIn Audience",
    description: "Healthcare administrators segment shows 45% higher conversion potential",
    impact: "Est. 25K additional reach",
    category: "Audience"
  },
  {
    type: "warning",
    title: "Weekend Engagement Drop",
    description: "Content posted on weekends sees 40% lower engagement",
    impact: "Consider weekday scheduling",
    category: "Timing"
  },
  {
    type: "success",
    title: "Patient Stories Resonate",
    description: "Recovery journey content has highest share rate at 8.4%",
    impact: "Prioritize testimonials",
    category: "Content Type"
  }
];
