import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  ArrowLeft, 
  Building2, 
  Upload,
  Palette,
  Target,
  Users,
  FileText,
  Check,
  ChevronRight
} from "lucide-react";

const industries = [
  { id: "medical-devices", label: "Medical Devices & Equipment", icon: "🏥" },
  { id: "pharma", label: "Pharmaceuticals", icon: "💊" },
  { id: "digital-health", label: "Digital Health & Wellness", icon: "📱" },
  { id: "hospital-mgmt", label: "Hospital Management", icon: "🏨" },
  { id: "diagnostics", label: "Diagnostics & Imaging", icon: "🔬" },
  { id: "biotech", label: "Biotechnology", icon: "🧬" },
];

const brandColors = [
  { id: "teal", color: "bg-healthcare-teal", label: "Healthcare Teal" },
  { id: "navy", color: "bg-healthcare-navy", label: "Professional Navy" },
  { id: "accent", color: "bg-accent", label: "Vibrant Orange" },
  { id: "sky", color: "bg-healthcare-sky", label: "Trust Sky" },
  { id: "primary", color: "bg-primary", label: "Primary Green" },
];

const personas = [
  { id: "cmo", label: "Chief Medical Officer", selected: false },
  { id: "procurement", label: "Procurement Director", selected: false },
  { id: "cio", label: "Healthcare CIO", selected: false },
  { id: "nurse-admin", label: "Nursing Administrator", selected: false },
  { id: "ceo", label: "Hospital CEO", selected: false },
  { id: "clinical-ops", label: "Clinical Operations Manager", selected: false },
  { id: "it-director", label: "IT Director", selected: false },
  { id: "finance", label: "Finance Director", selected: false },
];

export default function AddBrand() {
  const navigate = useNavigate();
  const { user, isLoading } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [brandData, setBrandData] = useState({
    name: "",
    tagline: "",
    industry: "",
    website: "",
    primaryColor: "teal",
    logoInitials: "",
    description: "",
    selectedPersonas: [] as string[],
    voiceAttributes: [] as string[],
  });

  const voiceOptions = ["Professional", "Innovative", "Trustworthy", "Empathetic", "Bold", "Educational", "Patient-Centric", "Data-Driven"];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  const steps = [
    { id: 1, label: "Brand Basics", icon: Building2 },
    { id: 2, label: "Visual Identity", icon: Palette },
    { id: 3, label: "Target Personas", icon: Users },
    { id: 4, label: "Brand Voice", icon: FileText },
  ];

  const togglePersona = (personaId: string) => {
    setBrandData(prev => ({
      ...prev,
      selectedPersonas: prev.selectedPersonas.includes(personaId)
        ? prev.selectedPersonas.filter(p => p !== personaId)
        : [...prev.selectedPersonas, personaId]
    }));
  };

  const toggleVoice = (voice: string) => {
    setBrandData(prev => ({
      ...prev,
      voiceAttributes: prev.voiceAttributes.includes(voice)
        ? prev.voiceAttributes.filter(v => v !== voice)
        : prev.voiceAttributes.length < 4 
          ? [...prev.voiceAttributes, voice]
          : prev.voiceAttributes
    }));
  };

  const handleSubmit = () => {
    // In a real app, this would save to database
    navigate('/brand/careplus-hospitals');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/brands')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
                <Sparkles className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-display text-xl tracking-wider">NOVA</span>
            </div>
          </div>
          
          <div className="text-sm text-muted-foreground">
            Step {currentStep} of 4
          </div>
        </div>
      </motion.header>

      <main className="max-w-5xl mx-auto px-6 py-12">
        {/* Page Title */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="font-display text-4xl tracking-wide mb-3">
            ADD NEW <span className="text-primary">BRAND</span>
          </h1>
          <p className="text-muted-foreground text-lg">
            Set up your brand for intelligent content generation
          </p>
        </motion.div>

        {/* Progress Steps */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex items-center justify-center gap-2 mb-12"
        >
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <button
                onClick={() => setCurrentStep(step.id)}
                className={`flex items-center gap-2 px-4 py-2 transition-all ${
                  currentStep === step.id
                    ? "bg-primary text-primary-foreground"
                    : currentStep > step.id
                      ? "bg-success/20 text-success"
                      : "bg-muted text-muted-foreground"
                }`}
              >
                {currentStep > step.id ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <step.icon className="w-4 h-4" />
                )}
                <span className="font-display text-sm tracking-wide hidden sm:inline">{step.label}</span>
              </button>
              {index < steps.length - 1 && (
                <ChevronRight className="w-4 h-4 text-muted-foreground mx-2" />
              )}
            </div>
          ))}
        </motion.div>

        {/* Step Content */}
        <AnimatePresence mode="wait">
          {currentStep === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-card border border-border p-8"
            >
              <h2 className="font-display text-xl mb-6">BRAND BASICS</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Brand Name *</label>
                  <input
                    type="text"
                    value={brandData.name}
                    onChange={(e) => setBrandData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., HealthTech Expo India 2024"
                    className="w-full h-11 px-4 bg-muted border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Tagline</label>
                  <input
                    type="text"
                    value={brandData.tagline}
                    onChange={(e) => setBrandData(prev => ({ ...prev, tagline: e.target.value }))}
                    placeholder="e.g., Advancing Healthcare Innovation"
                    className="w-full h-11 px-4 bg-muted border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-2">Industry Category *</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {industries.map((industry) => (
                      <button
                        key={industry.id}
                        onClick={() => setBrandData(prev => ({ ...prev, industry: industry.id }))}
                        className={`p-4 border text-left transition-all ${
                          brandData.industry === industry.id
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-muted-foreground"
                        }`}
                      >
                        <span className="text-2xl mb-2 block">{industry.icon}</span>
                        <span className="text-sm font-medium">{industry.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Website URL</label>
                  <input
                    type="url"
                    value={brandData.website}
                    onChange={(e) => setBrandData(prev => ({ ...prev, website: e.target.value }))}
                    placeholder="https://example.com"
                    className="w-full h-11 px-4 bg-muted border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <textarea
                    value={brandData.description}
                    onChange={(e) => setBrandData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of your brand..."
                    rows={3}
                    className="w-full px-4 py-3 bg-muted border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {currentStep === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-card border border-border p-8"
            >
              <h2 className="font-display text-xl mb-6">VISUAL IDENTITY</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-sm font-medium mb-4">Brand Logo</label>
                  <div className="border-2 border-dashed border-border p-8 text-center hover:border-primary transition-colors cursor-pointer">
                    <Upload className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
                    <p className="text-sm text-muted-foreground mb-2">Drag & drop your logo here</p>
                    <p className="text-xs text-muted-foreground">or click to browse (PNG, SVG)</p>
                  </div>
                  
                  <div className="mt-4">
                    <label className="block text-sm font-medium mb-2">Or use initials</label>
                    <input
                      type="text"
                      maxLength={2}
                      value={brandData.logoInitials}
                      onChange={(e) => setBrandData(prev => ({ ...prev, logoInitials: e.target.value.toUpperCase() }))}
                      placeholder="HT"
                      className="w-20 h-11 px-4 bg-muted border border-border text-foreground text-center font-display text-lg focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-4">Primary Brand Color</label>
                  <div className="space-y-3">
                    {brandColors.map((color) => (
                      <button
                        key={color.id}
                        onClick={() => setBrandData(prev => ({ ...prev, primaryColor: color.id }))}
                        className={`w-full flex items-center gap-4 p-3 border transition-all ${
                          brandData.primaryColor === color.id
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-muted-foreground"
                        }`}
                      >
                        <div className={`w-10 h-10 ${color.color}`} />
                        <span className="text-sm font-medium">{color.label}</span>
                        {brandData.primaryColor === color.id && (
                          <Check className="w-4 h-4 text-primary ml-auto" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Preview */}
              <div className="mt-8 pt-8 border-t border-border">
                <label className="block text-sm font-medium mb-4">Preview</label>
                <div className="flex items-center gap-4 p-6 bg-muted/30">
                  <div className={`w-16 h-16 ${brandColors.find(c => c.id === brandData.primaryColor)?.color || 'bg-primary'} flex items-center justify-center text-white font-display text-xl`}>
                    {brandData.logoInitials || "BR"}
                  </div>
                  <div>
                    <h3 className="font-display text-lg">{brandData.name || "Brand Name"}</h3>
                    <p className="text-sm text-muted-foreground">{brandData.tagline || "Your tagline here"}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {currentStep === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-card border border-border p-8"
            >
              <h2 className="font-display text-xl mb-2">TARGET PERSONAS</h2>
              <p className="text-muted-foreground text-sm mb-6">
                Select the key decision-makers and influencers you want to reach
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {personas.map((persona) => (
                  <button
                    key={persona.id}
                    onClick={() => togglePersona(persona.id)}
                    className={`p-4 border text-left transition-all ${
                      brandData.selectedPersonas.includes(persona.id)
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-muted-foreground"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <Target className={`w-5 h-5 ${brandData.selectedPersonas.includes(persona.id) ? 'text-primary' : 'text-muted-foreground'}`} />
                      {brandData.selectedPersonas.includes(persona.id) && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <span className="text-sm font-medium">{persona.label}</span>
                  </button>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-muted/30 border border-border">
                <p className="text-sm text-muted-foreground">
                  <strong className="text-foreground">{brandData.selectedPersonas.length}</strong> personas selected. 
                  NOVA will generate tailored BIP stories for each persona.
                </p>
              </div>
            </motion.div>
          )}

          {currentStep === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-card border border-border p-8"
            >
              <h2 className="font-display text-xl mb-2">BRAND VOICE</h2>
              <p className="text-muted-foreground text-sm mb-6">
                Select up to 4 attributes that define your brand's communication style
              </p>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
                {voiceOptions.map((voice) => (
                  <button
                    key={voice}
                    onClick={() => toggleVoice(voice)}
                    disabled={brandData.voiceAttributes.length >= 4 && !brandData.voiceAttributes.includes(voice)}
                    className={`p-3 border text-center transition-all ${
                      brandData.voiceAttributes.includes(voice)
                        ? "border-primary bg-primary/10"
                        : brandData.voiceAttributes.length >= 4
                          ? "border-border text-muted-foreground opacity-50 cursor-not-allowed"
                          : "border-border hover:border-muted-foreground"
                    }`}
                  >
                    <span className="text-sm font-medium">{voice}</span>
                  </button>
                ))}
              </div>
              
              {/* Summary */}
              <div className="p-6 bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/30">
                <h3 className="font-display text-lg mb-4">BRAND SUMMARY</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Name:</span>
                    <p className="font-medium">{brandData.name || "Not set"}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Industry:</span>
                    <p className="font-medium">{industries.find(i => i.id === brandData.industry)?.label || "Not set"}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Target Personas:</span>
                    <p className="font-medium">{brandData.selectedPersonas.length} selected</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Voice Attributes:</span>
                    <p className="font-medium">{brandData.voiceAttributes.join(", ") || "Not set"}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation Buttons */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex justify-between mt-8"
        >
          <Button
            variant="outline"
            onClick={() => setCurrentStep(prev => Math.max(1, prev - 1))}
            disabled={currentStep === 1}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Previous
          </Button>
          
          {currentStep < 4 ? (
            <Button onClick={() => setCurrentStep(prev => prev + 1)}>
              Next <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleSubmit}>
              <Sparkles className="w-4 h-4 mr-2" /> Create Brand
            </Button>
          )}
        </motion.div>
      </main>
    </div>
  );
}
