import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, ArrowRight, Mail, CheckCircle, Shield } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

export default function Auth() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    
    setIsSubmitting(true);
    
    // Simulate a brief loading state for UX
    await new Promise(resolve => setTimeout(resolve, 800));
    
    login(email);
    setIsSuccess(true);
    
    // Brief success state then redirect
    await new Promise(resolve => setTimeout(resolve, 1000));
    navigate('/brands');
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left Panel - Branding */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="hidden lg:flex lg:w-1/2 bg-card sunburst-pattern relative flex-col justify-between p-12 overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10" />
        
        {/* Floating decorative elements */}
        <motion.div 
          className="absolute top-20 right-20 w-48 h-48 bg-primary/10 blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 6, repeat: Infinity }}
        />
        <motion.div 
          className="absolute bottom-40 left-10 w-32 h-32 bg-accent/10 blur-3xl"
          animate={{ 
            scale: [1, 1.3, 1],
            opacity: [0.2, 0.4, 0.2]
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        
        <div className="relative">
          <motion.div 
            className="flex items-center gap-3 mb-20"
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 400 }}
          >
            <div className="w-12 h-12 bg-primary flex items-center justify-center glow-teal">
              <Sparkles className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="font-display text-2xl tracking-wider">NOVA</span>
          </motion.div>
        </div>

        <div className="relative">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 border border-primary/20 mb-6 text-sm text-primary"
          >
            <Shield className="w-3.5 h-3.5" />
            Enterprise-grade Security
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="font-display text-5xl tracking-wide leading-tight mb-6"
          >
            INTELLIGENCE
            <br />
            <span className="text-gradient">MEETS IMPACT</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-xl text-muted-foreground max-w-md"
          >
            Transform market observations into compelling healthcare narratives 
            that drive measurable results.
          </motion.p>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="relative grid grid-cols-3 gap-6"
        >
          {[
            { value: "50+", label: "Brands" },
            { value: "2M+", label: "Reach" },
            { value: "98%", label: "Retention" },
          ].map((stat, index) => (
            <motion.div 
              key={stat.label} 
              className="text-center p-4 bg-background/50 border border-border backdrop-blur-sm hover:border-primary/30 transition-colors duration-300"
              whileHover={{ y: -2 }}
              transition={{ type: "spring", stiffness: 400 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              style={{ animationDelay: `${0.6 + index * 0.1}s` }}
            >
              <div className="font-display text-2xl text-primary">{stat.value}</div>
              <div className="text-xs text-muted-foreground uppercase tracking-wide">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      {/* Right Panel - Auth Form */}
      <div className="flex-1 flex items-center justify-center p-8 relative">
        {/* Subtle background pattern */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-primary/5 blur-3xl" />
        </div>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="w-full max-w-md relative z-10"
        >
          {/* Mobile Logo */}
          <motion.div 
            className="lg:hidden flex items-center gap-3 mb-12 justify-center"
            whileHover={{ scale: 1.02 }}
          >
            <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl tracking-wider">NOVA</span>
          </motion.div>

          <div className="text-center mb-10">
            <motion.h2 
              className="font-display text-3xl tracking-wide mb-3"
              layout
            >
              {isSuccess ? "WELCOME ABOARD" : "SIGN IN"}
            </motion.h2>
            <motion.p 
              className="text-muted-foreground"
              layout
            >
              {isSuccess 
                ? "Redirecting you to your dashboard..."
                : "Enter your email to access your healthcare intelligence hub"
              }
            </motion.p>
          </div>

          <AnimatePresence mode="wait">
            {isSuccess ? (
              <motion.div 
                key="success"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="flex flex-col items-center gap-6"
              >
                <motion.div 
                  className="w-20 h-20 bg-primary/20 flex items-center justify-center glow-teal"
                  animate={{ 
                    scale: [1, 1.1, 1],
                    boxShadow: [
                      "0 0 20px hsl(168 80% 32% / 0.4)",
                      "0 0 40px hsl(168 80% 32% / 0.6)",
                      "0 0 20px hsl(168 80% 32% / 0.4)"
                    ]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <CheckCircle className="w-10 h-10 text-primary" />
                </motion.div>
                <p className="text-center text-muted-foreground">
                  Welcome, <span className="text-foreground font-medium">{email}</span>
                </p>
              </motion.div>
            ) : (
              <motion.form 
                key="form"
                onSubmit={handleSubmit} 
                className="space-y-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                    Email Address
                  </label>
                  <motion.div 
                    className="relative"
                    animate={{ 
                      scale: isFocused ? 1.01 : 1,
                    }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Mail className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors duration-300 ${isFocused ? 'text-primary' : 'text-muted-foreground'}`} />
                    <Input
                      type="email"
                      placeholder="you@healthcare.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      onFocus={() => setIsFocused(true)}
                      onBlur={() => setIsFocused(false)}
                      className={`pl-12 h-14 bg-card border-2 text-lg transition-all duration-300 ${
                        isFocused 
                          ? 'border-primary shadow-lg shadow-primary/10' 
                          : 'border-border hover:border-muted-foreground'
                      }`}
                      required
                    />
                  </motion.div>
                  <motion.p 
                    className="text-xs text-muted-foreground flex items-center gap-1.5"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <span className="text-primary">💡</span> Tip: Use "admin@" in your email for admin access
                  </motion.p>
                </div>

                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full h-14 text-lg btn-premium group"
                  disabled={isSubmitting || !email.trim()}
                >
                  {isSubmitting ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full"
                    />
                  ) : (
                    <>
                      Continue 
                      <motion.span
                        className="ml-2"
                        animate={{ x: [0, 4, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        <ArrowRight className="w-5 h-5" />
                      </motion.span>
                    </>
                  )}
                </Button>
              </motion.form>
            )}
          </AnimatePresence>

          <motion.p 
            className="text-center text-sm text-muted-foreground mt-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            By continuing, you agree to NOVA's Terms of Service and Privacy Policy.
          </motion.p>

          <motion.div 
            className="mt-12 pt-8 border-t border-border"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <p className="text-center text-xs text-muted-foreground mb-4 uppercase tracking-wide">
              Trusted by healthcare leaders
            </p>
            <div className="flex items-center justify-center gap-8 opacity-50">
              {["MedTech", "HealthCorp", "CareFirst"].map((name, i) => (
                <motion.span 
                  key={name} 
                  className="font-display text-sm tracking-wider"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 + i * 0.1 }}
                >
                  {name}
                </motion.span>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
