import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { ObservationForm, ObservationData } from "@/components/dashboard/ObservationForm";
import { OBIPToContentGenerator } from "@/components/dashboard/OBIPToContentGenerator";
import { OBIPFlowTimeline } from "@/components/dashboard/OBIPFlowTimeline";
import { 
  Sparkles, 
  ArrowLeft, 
  Eye,
  Users,
  Building2,
  TrendingUp,
  ChevronRight,
  Brain,
  Lightbulb,
  GitBranch,
  Filter,
  Plus,
  Search,
  ExternalLink,
  Wand2,
  LayoutGrid,
  GitCommit
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Observation {
  id: string;
  type: "customer" | "competition" | "market";
  category: "market" | "competitor";
  title: string;
  rawObservation: string;
  behavior: string;
  insight: string;
  pattern: string;
  source: string;
  timestamp: string;
  importance: "high" | "medium" | "low";
  tags: string[];
}

const observations: Observation[] = [
  {
    id: "1",
    type: "customer",
    category: "market",
    title: "Hospital Procurement Behavior Shift",
    rawObservation: "78% of hospital buyers now require ROI proof before booth visit at medical expos",
    behavior: "Procurement directors are spending 2-3x more time on pre-event research, downloading whitepapers and case studies before committing to booth visits.",
    insight: "The buying journey has fundamentally shifted left—decisions are being influenced long before the handshake at the booth.",
    pattern: "Mid-size hospitals (200-500 beds) are leading this shift. They face tighter budgets and more scrutiny, making pre-qualification essential.",
    source: "ARCHER Deep Research",
    timestamp: "2h ago",
    importance: "high",
    tags: ["procurement", "trade shows", "ROI"]
  },
  {
    id: "2",
    type: "customer",
    category: "market",
    title: "Nurse Burnout Documentation",
    rawObservation: "Nursing administrators increasingly documenting burnout metrics as compliance risk evidence",
    behavior: "Head nurses are systematically collecting data on shift coverage, medication errors, and overtime hours—not for HR, but for Joint Commission preparation.",
    insight: "Burnout isn't being sold as a wellbeing issue anymore. It's being reframed as a regulatory and patient safety risk to unlock budget.",
    pattern: "This reframing works. Hospitals that presented burnout as compliance risk secured 40% more FTE additions.",
    source: "Healthcare Admin Survey Q3",
    timestamp: "5h ago",
    importance: "high",
    tags: ["nursing", "burnout", "compliance"]
  },
  {
    id: "3",
    type: "customer",
    category: "market",
    title: "CMO Data Consumption Patterns",
    rawObservation: "CMOs at teaching hospitals review clinical dashboards 4x more frequently than community hospital counterparts",
    behavior: "Teaching hospital CMOs are building personal data narratives—connecting patient outcomes to equipment requests in weekly leadership meetings.",
    insight: "They're not just consuming data, they're curating evidence. Every metric is ammunition for the next capital request.",
    pattern: "CMOs who present data stories (not just data) are 2.5x more likely to secure equipment budgets within 90 days.",
    source: "Executive Interview Series",
    timestamp: "1d ago",
    importance: "medium",
    tags: ["CMO", "data", "budgeting"]
  },
  {
    id: "4",
    type: "competition",
    category: "competitor",
    title: "Siemens Healthineers AI-First Campaign",
    rawObservation: "New AI-first messaging across all channels with 'Precision Medicine' positioning",
    behavior: "Siemens has consolidated all product messaging under a unified AI narrative, eliminating individual product campaigns.",
    insight: "They're betting that AI is the decision-making shortcut—buyers will choose the 'AI leader' without deep product comparison.",
    pattern: "This mirrors B2B tech consolidation trends. The 'platform play' is coming to medical devices.",
    source: "Meta Ad Library",
    timestamp: "4h ago",
    importance: "high",
    tags: ["siemens", "AI", "positioning"]
  },
  {
    id: "5",
    type: "competition",
    category: "competitor",
    title: "GE HealthCare Sustainability Push",
    rawObservation: "Major investment in green messaging, targeting ESG-conscious hospital networks",
    behavior: "GE is targeting hospital systems with formal ESG commitments, offering carbon footprint audits as part of sales process.",
    insight: "Sustainability is becoming a procurement qualifier, not just a differentiator. Some RFPs now require environmental impact statements.",
    pattern: "Hospital networks with ESG mandates are 30% more likely to shortlist vendors with sustainability certifications.",
    source: "Competitive Intelligence",
    timestamp: "6h ago",
    importance: "medium",
    tags: ["GE", "sustainability", "ESG"]
  },
  {
    id: "6",
    type: "market",
    category: "market",
    title: "Category Trend: Value-Based Care",
    rawObservation: "Sustainability messaging up 45% in healthcare tech sector YoY",
    behavior: "Healthcare marketers are pivoting from feature-led to outcome-led messaging at unprecedented scale.",
    insight: "The buyer's mental model has changed. They're not buying equipment—they're buying measurable patient outcomes.",
    pattern: "Brands that lead with outcomes in their first 3 touchpoints see 2x higher engagement rates.",
    source: "Industry Analysis",
    timestamp: "1d ago",
    importance: "medium",
    tags: ["trends", "outcomes", "messaging"]
  },
  {
    id: "7",
    type: "competition",
    category: "competitor",
    title: "Philips Remote Care Expansion",
    rawObservation: "Aggressive pricing on remote monitoring solutions targeting rural hospitals",
    behavior: "Philips is offering 30-40% discounts on remote care bundles to rural and underserved hospital networks.",
    insight: "They're building installed base now, betting on recurring service revenue. The device is the trojan horse.",
    pattern: "Rural hospitals with limited IT resources prefer bundled solutions. Philips is capturing this segment.",
    source: "Sales Intelligence",
    timestamp: "2d ago",
    importance: "medium",
    tags: ["philips", "remote care", "pricing"]
  },
  {
    id: "8",
    type: "customer",
    category: "market",
    title: "CIO Peer Network Intelligence",
    rawObservation: "Healthcare CIOs increasingly relying on informal peer networks for threat intelligence",
    behavior: "CIOs maintain private WhatsApp and Slack groups with counterparts at other health systems for real-time security alerts.",
    insight: "The most valuable threat intelligence isn't coming from vendors—it's coming from peers who face the same attackers.",
    pattern: "Peer-sourced alerts result in 5x faster response times than vendor notifications.",
    source: "CIO Roundtable",
    timestamp: "3d ago",
    importance: "high",
    tags: ["CIO", "security", "peer networks"]
  },
];

const typeConfig = {
  customer: { icon: Users, color: "text-healthcare-teal", bg: "bg-healthcare-teal/10", label: "Customer Intel" },
  competition: { icon: Building2, color: "text-warning", bg: "bg-warning/10", label: "Competitor Intel" },
  market: { icon: TrendingUp, color: "text-healthcare-sky", bg: "bg-healthcare-sky/10", label: "Market Intel" },
};

export default function ObservationsPage() {
  const navigate = useNavigate();
  const { brandId } = useParams();
  const { user, isLoading } = useAuth();
  const [activeCategory, setActiveCategory] = useState<"all" | "market" | "competitor">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [allObservations, setAllObservations] = useState<Observation[]>(observations);
  const [selectedObservation, setSelectedObservation] = useState<Observation | null>(null);
  const [showContentGenerator, setShowContentGenerator] = useState(false);
  const [activeView, setActiveView] = useState<"list" | "timeline">("list");

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  const handleSaveObservation = (observation: ObservationData) => {
    const newObs: Observation = {
      ...observation,
      category: observation.type === "competition" ? "competitor" : "market",
      timestamp: "Just now",
    };
    setAllObservations([newObs, ...allObservations]);
  };

  const handleGenerateContent = (obs: Observation) => {
    setSelectedObservation(obs);
    setShowContentGenerator(true);
    setExpandedId(null);
  };

  const filteredObservations = allObservations.filter(obs => {
    const matchesCategory = activeCategory === "all" || obs.category === activeCategory;
    const matchesSearch = obs.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          obs.rawObservation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const marketIntel = allObservations.filter(o => o.category === "market");
  const competitorIntel = allObservations.filter(o => o.category === "competitor");

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(`/brand/${brandId}`)}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
                <Sparkles className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <span className="font-display text-xl tracking-wider">NOVA</span>
                <p className="text-xs text-muted-foreground">Observation Hub</p>
              </div>
            </div>
          </div>
          
          <Button onClick={() => setIsFormOpen(true)}>
            <Plus className="w-4 h-4 mr-2" /> Add Observation
          </Button>
        </div>
      </motion.header>

      {/* Observation Form Modal */}
      <ObservationForm 
        isOpen={isFormOpen} 
        onClose={() => setIsFormOpen(false)} 
        onSave={handleSaveObservation} 
      />

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Page Title */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="font-display text-4xl tracking-wide mb-3">
            OBSERVATION <span className="text-primary">HUB</span>
          </h1>
          <p className="text-muted-foreground text-lg">
            Observation → Behavior → Insight → Pattern — The foundation of strategic content
          </p>
        </motion.div>

        {/* Flow Visualization */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-r from-healthcare-teal/10 via-healthcare-navy/10 to-primary/10 border border-border p-6 mb-8"
        >
          <div className="flex items-center justify-between">
            {[
              { icon: Eye, label: "Observation", desc: "Raw market signal" },
              { icon: Brain, label: "Behavior", desc: "What they do" },
              { icon: Lightbulb, label: "Insight", desc: "Why they do it" },
              { icon: GitBranch, label: "Pattern", desc: "What it means" },
            ].map((step, index) => (
              <div key={step.label} className="flex items-center">
                <div className="text-center">
                  <div className="w-14 h-14 mx-auto mb-2 bg-card border-2 border-primary flex items-center justify-center">
                    <step.icon className="w-6 h-6 text-primary" />
                  </div>
                  <p className="font-display text-sm tracking-wide">{step.label}</p>
                  <p className="text-xs text-muted-foreground mt-1">{step.desc}</p>
                </div>
                {index < 3 && (
                  <ChevronRight className="w-5 h-5 text-muted-foreground mx-4" />
                )}
              </div>
            ))}
          </div>
        </motion.div>

        {/* View Toggle & Category Tabs & Search */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6"
        >
          <div className="flex items-center gap-4">
            {/* View Toggle */}
            <div className="flex items-center gap-1 bg-muted rounded-lg p-1">
              <button
                onClick={() => setActiveView("list")}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5",
                  activeView === "list" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                List
              </button>
              <button
                onClick={() => setActiveView("timeline")}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5",
                  activeView === "timeline" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <GitCommit className="w-3.5 h-3.5" />
                Timeline
              </button>
            </div>

            {/* Category Tabs */}
            {[
              { id: "all", label: "All Observations", count: allObservations.length },
              { id: "market", label: "Market Intelligence", count: marketIntel.length },
              { id: "competitor", label: "Competitor Intelligence", count: competitorIntel.length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id as typeof activeCategory)}
                className={`px-4 py-2 text-sm font-display tracking-wide transition-all ${
                  activeCategory === tab.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label} ({tab.count})
              </button>
            ))}
          </div>
          
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search observations..."
              className="w-full h-10 pl-10 pr-4 bg-muted border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        </motion.div>

        {/* Observations List */}
        {/* Timeline View */}
        {activeView === "timeline" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <OBIPFlowTimeline />
          </motion.div>
        )}

        {/* List View */}
        {activeView === "list" && (
        <div className="space-y-4">
          <AnimatePresence>
            {filteredObservations.map((obs, index) => {
              const config = typeConfig[obs.type];
              const isExpanded = expandedId === obs.id;
              
              return (
                <motion.div
                  key={obs.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-card border border-border overflow-hidden"
                >
                  {/* Header Row */}
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : obs.id)}
                    className="w-full p-6 text-left hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-10 h-10 flex items-center justify-center flex-shrink-0 ${config.bg}`}>
                        <config.icon className={`w-5 h-5 ${config.color}`} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-3">
                            <h3 className="font-medium text-foreground">{obs.title}</h3>
                            {obs.importance === "high" && (
                              <span className="px-2 py-0.5 text-[10px] bg-error/10 text-error font-display">HIGH</span>
                            )}
                          </div>
                          <ChevronRight className={`w-5 h-5 text-muted-foreground transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                        </div>
                        
                        <p className="text-sm text-muted-foreground mb-3">{obs.rawObservation}</p>
                        
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className={`${config.color}`}>{config.label}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <ExternalLink className="w-3 h-3" />
                            {obs.source}
                          </span>
                          <span>•</span>
                          <span>{obs.timestamp}</span>
                        </div>
                      </div>
                    </div>
                  </button>
                  
                  {/* Expanded Content */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="px-6 pb-6 pt-2 border-t border-border">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {/* Behavior */}
                            <div className="p-4 bg-healthcare-teal/5 border-l-4 border-l-healthcare-teal">
                              <div className="flex items-center gap-2 mb-2">
                                <Brain className="w-4 h-4 text-healthcare-teal" />
                                <span className="font-display text-sm tracking-wide">BEHAVIOR</span>
                              </div>
                              <p className="text-sm text-muted-foreground">{obs.behavior}</p>
                            </div>
                            
                            {/* Insight */}
                            <div className="p-4 bg-healthcare-navy/5 border-l-4 border-l-healthcare-navy">
                              <div className="flex items-center gap-2 mb-2">
                                <Lightbulb className="w-4 h-4 text-healthcare-navy" />
                                <span className="font-display text-sm tracking-wide">INSIGHT</span>
                              </div>
                              <p className="text-sm text-muted-foreground">{obs.insight}</p>
                            </div>
                            
                            {/* Pattern */}
                            <div className="p-4 bg-primary/5 border-l-4 border-l-primary">
                              <div className="flex items-center gap-2 mb-2">
                                <GitBranch className="w-4 h-4 text-primary" />
                                <span className="font-display text-sm tracking-wide">PATTERN</span>
                              </div>
                              <p className="text-sm text-muted-foreground">{obs.pattern}</p>
                            </div>
                          </div>
                          
                          {/* Tags */}
                          <div className="flex items-center gap-2 mt-4">
                            {obs.tags.map((tag) => (
                              <span key={tag} className="px-2 py-1 text-xs bg-muted text-muted-foreground">
                                #{tag}
                              </span>
                            ))}
                          </div>
                          
                          {/* Actions */}
                          <div className="flex justify-end gap-2 mt-4">
                            <Button variant="outline" size="sm">
                              Create Story
                            </Button>
                            <Button size="sm" onClick={() => handleGenerateContent(obs)}>
                              <Wand2 className="w-3 h-3 mr-1" /> Generate Content
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
        )}
        <AnimatePresence>
          {showContentGenerator && selectedObservation && (
            <motion.div
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 100 }}
              className="fixed right-0 top-16 w-[500px] h-[calc(100vh-4rem)] bg-background border-l border-border overflow-y-auto shadow-2xl z-40"
            >
              <div className="p-4 border-b border-border flex items-center justify-between">
                <h3 className="font-display text-sm tracking-wide">CONTENT GENERATOR</h3>
                <Button variant="ghost" size="sm" onClick={() => setShowContentGenerator(false)}>
                  Close
                </Button>
              </div>
              <div className="p-4">
                <OBIPToContentGenerator 
                  observation={{
                    id: selectedObservation.id,
                    type: selectedObservation.type,
                    title: selectedObservation.title,
                    rawObservation: selectedObservation.rawObservation,
                    behavior: selectedObservation.behavior,
                    insight: selectedObservation.insight,
                    pattern: selectedObservation.pattern,
                    source: selectedObservation.source,
                    importance: selectedObservation.importance,
                    tags: selectedObservation.tags,
                    createdAt: selectedObservation.timestamp,
                  }} 
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
