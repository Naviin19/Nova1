import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useContentBriefs, ContentBrief } from "@/contexts/ContentBriefContext";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  ArrowLeft, 
  Instagram,
  Linkedin,
  Twitter,
  Mail,
  Youtube,
  Eye,
  Heart,
  Share2,
  MessageCircle,
  TrendingUp,
  TrendingDown,
  Filter,
  Grid,
  List,
  Calendar,
  Image,
  Video,
  FileText,
  ExternalLink,
  Wand2,
  Clock,
  Target,
  BarChart3,
  ChevronRight,
  Trash2,
  Edit3
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ContentItem {
  id: string;
  title: string;
  description: string;
  platform: "instagram" | "linkedin" | "twitter" | "email" | "youtube";
  format: "image" | "video" | "carousel" | "reel" | "newsletter" | "article";
  status: "published" | "scheduled" | "draft";
  publishedAt: string;
  thumbnail: string;
  persona: string;
  sprinkleType: string;
  metrics: {
    reach: string;
    impressions: string;
    engagement: string;
    clicks: string;
    shares: string;
    comments: string;
    saves: string;
    ctr: string;
  };
  performance: "exceeds" | "meets" | "below";
  trend: "up" | "down" | "stable";
}

const contentLibrary: ContentItem[] = [
  {
    id: "1",
    title: "The Quietest Revolution in Patient Care",
    description: "A deep dive into how silent MRI technology is transforming the pediatric imaging experience, reducing anxiety and improving diagnostic outcomes.",
    platform: "linkedin",
    format: "carousel",
    status: "published",
    publishedAt: "Jan 15, 2024",
    thumbnail: "gradient-1",
    persona: "Hospital Procurement Director",
    sprinkleType: "Visual Break",
    metrics: {
      reach: "124,500",
      impressions: "187,200",
      engagement: "6.8%",
      clicks: "3,420",
      shares: "892",
      comments: "156",
      saves: "1,234",
      ctr: "2.7%"
    },
    performance: "exceeds",
    trend: "up"
  },
  {
    id: "2",
    title: "Stop Comparing Specs. Start Comparing Outcomes.",
    description: "Challenging the traditional equipment comparison framework with an outcomes-first approach to medical device procurement.",
    platform: "instagram",
    format: "reel",
    status: "published",
    publishedAt: "Jan 12, 2024",
    thumbnail: "gradient-2",
    persona: "Chief Medical Officer",
    sprinkleType: "Message Break",
    metrics: {
      reach: "89,200",
      impressions: "134,800",
      engagement: "5.2%",
      clicks: "2,156",
      shares: "567",
      comments: "234",
      saves: "890",
      ctr: "1.9%"
    },
    performance: "exceeds",
    trend: "up"
  },
  {
    id: "3",
    title: "Your EMR Doesn't Need Another Update",
    description: "An email series exploring the partnership approach to healthcare IT, focusing on integration over iteration.",
    platform: "email",
    format: "newsletter",
    status: "published",
    publishedAt: "Jan 10, 2024",
    thumbnail: "gradient-3",
    persona: "Healthcare CIO",
    sprinkleType: "Channel Break",
    metrics: {
      reach: "45,600",
      impressions: "45,600",
      engagement: "3.1%",
      clicks: "1,234",
      shares: "89",
      comments: "45",
      saves: "234",
      ctr: "4.2%"
    },
    performance: "meets",
    trend: "stable"
  },
  {
    id: "4",
    title: "When Precision Meets Compassion",
    description: "A video story following a day in the life of an interventional radiologist using AI-assisted guidance systems.",
    platform: "youtube",
    format: "video",
    status: "published",
    publishedAt: "Jan 8, 2024",
    thumbnail: "gradient-4",
    persona: "Clinical Operations Manager",
    sprinkleType: "Story Break",
    metrics: {
      reach: "67,800",
      impressions: "98,400",
      engagement: "4.5%",
      clicks: "5,670",
      shares: "345",
      comments: "178",
      saves: "567",
      ctr: "3.1%"
    },
    performance: "exceeds",
    trend: "up"
  },
  {
    id: "5",
    title: "The Hidden Cost of Downtime",
    description: "Infographic breaking down the true cost of equipment failures in a busy emergency department.",
    platform: "linkedin",
    format: "image",
    status: "published",
    publishedAt: "Jan 5, 2024",
    thumbnail: "gradient-5",
    persona: "Hospital CEO",
    sprinkleType: "Data Break",
    metrics: {
      reach: "56,700",
      impressions: "78,900",
      engagement: "3.8%",
      clicks: "1,890",
      shares: "234",
      comments: "89",
      saves: "456",
      ctr: "2.4%"
    },
    performance: "meets",
    trend: "stable"
  },
  {
    id: "6",
    title: "Burnout Isn't a Buzzword",
    description: "A candid look at nursing burnout through the lens of patient safety metrics and Joint Commission compliance.",
    platform: "twitter",
    format: "carousel",
    status: "published",
    publishedAt: "Jan 3, 2024",
    thumbnail: "gradient-6",
    persona: "Nursing Administrator",
    sprinkleType: "Empathy Break",
    metrics: {
      reach: "34,500",
      impressions: "52,100",
      engagement: "4.2%",
      clicks: "1,234",
      shares: "567",
      comments: "312",
      saves: "123",
      ctr: "2.1%"
    },
    performance: "meets",
    trend: "down"
  },
  {
    id: "7",
    title: "AI in Diagnostics: Beyond the Hype",
    description: "Cutting through the marketing noise to explore practical AI applications in diagnostic imaging.",
    platform: "linkedin",
    format: "article",
    status: "scheduled",
    publishedAt: "Jan 20, 2024",
    thumbnail: "gradient-7",
    persona: "Healthcare IT Director",
    sprinkleType: "Authority Break",
    metrics: {
      reach: "—",
      impressions: "—",
      engagement: "—",
      clicks: "—",
      shares: "—",
      comments: "—",
      saves: "—",
      ctr: "—"
    },
    performance: "meets",
    trend: "stable"
  },
  {
    id: "8",
    title: "Sustainability in the OR",
    description: "How leading hospitals are reducing their environmental footprint without compromising patient outcomes.",
    platform: "instagram",
    format: "carousel",
    status: "draft",
    publishedAt: "—",
    thumbnail: "gradient-8",
    persona: "Sustainability Officer",
    sprinkleType: "Purpose Break",
    metrics: {
      reach: "—",
      impressions: "—",
      engagement: "—",
      clicks: "—",
      shares: "—",
      comments: "—",
      saves: "—",
      ctr: "—"
    },
    performance: "meets",
    trend: "stable"
  },
];

const platformConfig = {
  instagram: { icon: Instagram, color: "text-pink-400", bg: "bg-pink-400/10" },
  linkedin: { icon: Linkedin, color: "text-blue-400", bg: "bg-blue-400/10" },
  twitter: { icon: Twitter, color: "text-sky-400", bg: "bg-sky-400/10" },
  email: { icon: Mail, color: "text-green-400", bg: "bg-green-400/10" },
  youtube: { icon: Youtube, color: "text-red-400", bg: "bg-red-400/10" },
};

const formatConfig = {
  image: { icon: Image, label: "Image" },
  video: { icon: Video, label: "Video" },
  carousel: { icon: Grid, label: "Carousel" },
  reel: { icon: Video, label: "Reel" },
  newsletter: { icon: Mail, label: "Newsletter" },
  article: { icon: FileText, label: "Article" },
};

const performanceStyles = {
  exceeds: { label: "EXCEEDS", class: "bg-success/10 text-success border-success/30" },
  meets: { label: "MEETS", class: "bg-warning/10 text-warning border-warning/30" },
  below: { label: "BELOW", class: "bg-error/10 text-error border-error/30" },
};

const statusStyles = {
  published: "bg-success/10 text-success",
  scheduled: "bg-primary/10 text-primary",
  draft: "bg-muted text-muted-foreground",
};

const gradientBgs = {
  "gradient-1": "bg-gradient-to-br from-healthcare-teal to-healthcare-navy",
  "gradient-2": "bg-gradient-to-br from-accent to-primary",
  "gradient-3": "bg-gradient-to-br from-healthcare-sky to-healthcare-teal",
  "gradient-4": "bg-gradient-to-br from-primary to-healthcare-navy",
  "gradient-5": "bg-gradient-to-br from-warning to-accent",
  "gradient-6": "bg-gradient-to-br from-healthcare-navy to-primary",
  "gradient-7": "bg-gradient-to-br from-healthcare-teal to-primary",
  "gradient-8": "bg-gradient-to-br from-primary to-healthcare-teal",
};

export default function ContentLibraryPage() {
  const navigate = useNavigate();
  const { brandId } = useParams();
  const { user, isLoading } = useAuth();
  const { briefs, deleteBrief, updateBrief } = useContentBriefs();
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeFilter, setActiveFilter] = useState<"all" | "published" | "scheduled" | "draft" | "briefs">("all");
  const [activePlatform, setActivePlatform] = useState<string>("all");
  const [expandedBriefId, setExpandedBriefId] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  const filteredContent = activeFilter === "briefs" ? [] : contentLibrary.filter(item => {
    const matchesStatus = activeFilter === "all" || item.status === activeFilter;
    const matchesPlatform = activePlatform === "all" || item.platform === activePlatform;
    return matchesStatus && matchesPlatform;
  });

  // Stats
  const totalReach = contentLibrary
    .filter(c => c.status === "published")
    .reduce((acc, c) => acc + parseInt(c.metrics.reach.replace(/,/g, '') || '0'), 0);
  
  const avgEngagement = (contentLibrary
    .filter(c => c.status === "published" && c.metrics.engagement !== "—")
    .reduce((acc, c) => acc + parseFloat(c.metrics.engagement), 0) / 
    contentLibrary.filter(c => c.status === "published" && c.metrics.engagement !== "—").length
  ).toFixed(1);

  const handleDeleteBrief = (id: string) => {
    deleteBrief(id);
    toast.success("Brief deleted");
  };

  const handlePublishBrief = (brief: ContentBrief) => {
    updateBrief(brief.id, { status: "ready" });
    toast.success("Brief marked as ready for publishing");
  };

  const contentTypeIcons = {
    image: Image,
    video: Video,
    article: FileText
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(`/brand/${brandId}`)}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
                <Sparkles className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <span className="font-display text-xl tracking-wider">NOVA</span>
                <p className="text-xs text-muted-foreground">Content Library</p>
              </div>
            </div>
          </div>
          
          <Button>
            <Sparkles className="w-4 h-4 mr-2" /> Create Content
          </Button>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Page Title & Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="font-display text-4xl tracking-wide mb-3">
            CONTENT <span className="text-primary">LIBRARY</span>
          </h1>
          <p className="text-muted-foreground text-lg mb-6">
            All your BIP-powered content with performance metrics
          </p>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { label: "Total Content", value: contentLibrary.length, icon: FileText },
              { label: "Content Briefs", value: briefs.length, icon: Wand2 },
              { label: "Published", value: contentLibrary.filter(c => c.status === "published").length, icon: Eye },
              { label: "Total Reach", value: `${(totalReach / 1000).toFixed(0)}K`, icon: TrendingUp },
              { label: "Avg. Engagement", value: `${avgEngagement}%`, icon: Heart },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + index * 0.05 }}
                className="p-4 bg-card border border-border"
              >
                <stat.icon className="w-5 h-5 text-primary mb-2" />
                <p className="font-display text-2xl">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6"
        >
          <div className="flex flex-wrap items-center gap-2">
            {/* Status Filter */}
            {[
              { id: "all", label: "All" },
              { id: "briefs", label: `Briefs (${briefs.length})` },
              { id: "published", label: "Published" },
              { id: "scheduled", label: "Scheduled" },
              { id: "draft", label: "Drafts" },
            ].map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id as typeof activeFilter)}
                className={`px-3 py-1.5 text-xs font-display tracking-wide transition-all ${
                  activeFilter === filter.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground"
                }`}
              >
                {filter.label}
              </button>
            ))}
            
            <span className="text-muted-foreground mx-2">|</span>
            
            {/* Platform Filter */}
            <button
              onClick={() => setActivePlatform("all")}
              className={`px-3 py-1.5 text-xs font-display tracking-wide transition-all ${
                activePlatform === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              All Platforms
            </button>
            {Object.entries(platformConfig).map(([key, config]) => (
              <button
                key={key}
                onClick={() => setActivePlatform(key)}
                className={`p-1.5 transition-all ${
                  activePlatform === key
                    ? config.bg
                    : "bg-muted hover:bg-muted/80"
                }`}
              >
                <config.icon className={`w-4 h-4 ${activePlatform === key ? config.color : "text-muted-foreground"}`} />
              </button>
            ))}
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-2 transition-colors ${viewMode === "grid" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2 transition-colors ${viewMode === "list" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </motion.div>

        {/* Briefs Section */}
        {activeFilter === "briefs" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {briefs.length === 0 ? (
              <div className="text-center py-16 bg-card border border-border rounded-xl">
                <Wand2 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-display text-xl mb-2">No Content Briefs Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Generate content briefs from observations in the Observation Hub
                </p>
                <Button onClick={() => navigate(`/brand/${brandId}/observations`)}>
                  Go to Observations
                </Button>
              </div>
            ) : (
              briefs.map((brief, index) => {
                const TypeIcon = contentTypeIcons[brief.contentType];
                const isExpanded = expandedBriefId === brief.id;
                
                return (
                  <motion.div
                    key={brief.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-card border border-border rounded-xl overflow-hidden"
                  >
                    {/* Brief Header */}
                    <button
                      onClick={() => setExpandedBriefId(isExpanded ? null : brief.id)}
                      className="w-full p-6 text-left hover:bg-muted/30 transition-colors"
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
                          <TypeIcon className="w-6 h-6 text-primary" />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                              <h3 className="font-medium text-foreground">{brief.title}</h3>
                              <span className={cn(
                                "px-2 py-0.5 text-[10px] font-display rounded-full",
                                brief.status === "published" ? "bg-success/10 text-success" :
                                brief.status === "ready" ? "bg-primary/10 text-primary" :
                                "bg-muted text-muted-foreground"
                              )}>
                                {brief.status.toUpperCase()}
                              </span>
                            </div>
                            <ChevronRight className={cn(
                              "w-5 h-5 text-muted-foreground transition-transform",
                              isExpanded && "rotate-90"
                            )} />
                          </div>
                          
                          <p className="text-sm text-muted-foreground mb-2">
                            From observation: {brief.observationTitle}
                          </p>
                          
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {new Date(brief.createdAt).toLocaleDateString()}
                            </span>
                            <span className="capitalize">{brief.contentType}</span>
                            <span>{brief.contentStructure.format}</span>
                          </div>
                        </div>
                      </div>
                    </button>
                    
                    {/* Expanded Content */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="px-6 pb-6 pt-2 border-t border-border space-y-4">
                            {/* OBIP Flow */}
                            <div>
                              <h4 className="font-display text-sm tracking-wide mb-3">OBIP FLOW</h4>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                {[
                                  { label: "Observation", value: brief.obipFlow.observation, icon: Eye },
                                  { label: "Behavior", value: brief.obipFlow.behavior, icon: Target },
                                  { label: "Insight", value: brief.obipFlow.insight, icon: Heart },
                                  { label: "Pattern", value: brief.obipFlow.pattern, icon: TrendingUp },
                                ].map((item) => (
                                  <div key={item.label} className="p-3 bg-muted/30 rounded-lg">
                                    <div className="flex items-center gap-1.5 mb-1">
                                      <item.icon className="w-3 h-3 text-primary" />
                                      <span className="text-[10px] font-display tracking-wide">{item.label}</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground line-clamp-2">{item.value}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                            
                            {/* Sprinkle */}
                            {brief.sprinkle && (
                              <div className="p-3 bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg border border-primary/20">
                                <div className="flex items-center gap-1.5 mb-1">
                                  <Sparkles className="w-3 h-3 text-primary" />
                                  <span className="text-[10px] font-display tracking-wide text-primary">THE SPRINKLE</span>
                                </div>
                                <p className="text-xs text-foreground">{brief.sprinkle}</p>
                              </div>
                            )}
                            
                            {/* Measurement Params */}
                            <div>
                              <h4 className="font-display text-sm tracking-wide mb-3 flex items-center gap-2">
                                <BarChart3 className="w-4 h-4" />
                                MEASUREMENT TARGETS
                              </h4>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                                <div className="text-center p-3 bg-muted/30 rounded-lg">
                                  <p className="text-xs text-muted-foreground">Primary KPI</p>
                                  <p className="font-medium text-sm">{brief.measurementParams.primaryKPI}</p>
                                </div>
                                <div className="text-center p-3 bg-muted/30 rounded-lg">
                                  <p className="text-xs text-muted-foreground">Target Impressions</p>
                                  <p className="font-medium text-sm">{brief.measurementParams.benchmarks.impressions}</p>
                                </div>
                                <div className="text-center p-3 bg-muted/30 rounded-lg">
                                  <p className="text-xs text-muted-foreground">Target Engagement</p>
                                  <p className="font-medium text-sm">{brief.measurementParams.benchmarks.engagement}</p>
                                </div>
                                <div className="text-center p-3 bg-muted/30 rounded-lg">
                                  <p className="text-xs text-muted-foreground">Target Conversion</p>
                                  <p className="font-medium text-sm">{brief.measurementParams.benchmarks.conversion}</p>
                                </div>
                              </div>
                            </div>
                            
                            {/* Actions */}
                            <div className="flex justify-end gap-2 pt-2">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleDeleteBrief(brief.id)}
                              >
                                <Trash2 className="w-4 h-4 mr-1" />
                                Delete
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => navigate(`/brand/${brandId}/observations`)}
                              >
                                <Edit3 className="w-4 h-4 mr-1" />
                                Edit Brief
                              </Button>
                              {brief.status === "draft" && (
                                <Button 
                                  size="sm"
                                  onClick={() => handlePublishBrief(brief)}
                                >
                                  <Sparkles className="w-4 h-4 mr-1" />
                                  Mark Ready
                                </Button>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })
            )}
          </motion.div>
        )}

        {/* Content Grid/List */}
        {activeFilter !== "briefs" && (
        <AnimatePresence mode="wait">
          {viewMode === "grid" ? (
            <motion.div
              key="grid"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {filteredContent.map((item, index) => {
                const platform = platformConfig[item.platform];
                const format = formatConfig[item.format];
                const perf = performanceStyles[item.performance];
                
                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-card border border-border overflow-hidden group hover:border-primary/50 transition-all cursor-pointer"
                  >
                    {/* Thumbnail */}
                    <div className={`h-40 ${gradientBgs[item.thumbnail as keyof typeof gradientBgs]} relative`}>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <format.icon className="w-12 h-12 text-white/30" />
                      </div>
                      
                      {/* Status Badge */}
                      <div className="absolute top-3 left-3">
                        <span className={`px-2 py-1 text-[10px] font-display tracking-wide ${statusStyles[item.status]}`}>
                          {item.status.toUpperCase()}
                        </span>
                      </div>
                      
                      {/* Platform Badge */}
                      <div className="absolute top-3 right-3">
                        <div className={`w-8 h-8 flex items-center justify-center ${platform.bg}`}>
                          <platform.icon className={`w-4 h-4 ${platform.color}`} />
                        </div>
                      </div>
                      
                      {/* Performance Badge */}
                      {item.status === "published" && (
                        <div className="absolute bottom-3 right-3">
                          <span className={cn("px-2 py-1 text-[10px] font-display tracking-wide border", perf.class)}>
                            {perf.label}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    {/* Content */}
                    <div className="p-4">
                      <h3 className="font-medium text-foreground mb-2 line-clamp-2">{item.title}</h3>
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{item.description}</p>
                      
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                        <span className="text-accent">{item.sprinkleType}</span>
                        <span>•</span>
                        <span>{item.persona}</span>
                      </div>
                      
                      {/* Metrics */}
                      {item.status === "published" && (
                        <div className="grid grid-cols-4 gap-2 pt-3 border-t border-border">
                          {[
                            { icon: Eye, value: item.metrics.reach, label: "Reach" },
                            { icon: Heart, value: item.metrics.engagement, label: "Eng." },
                            { icon: Share2, value: item.metrics.shares, label: "Shares" },
                            { icon: MessageCircle, value: item.metrics.comments, label: "Comments" },
                          ].map((metric, i) => (
                            <div key={i} className="text-center">
                              <p className="font-display text-sm text-foreground">{metric.value}</p>
                              <p className="text-[10px] text-muted-foreground">{metric.label}</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          ) : (
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-3"
            >
              {filteredContent.map((item, index) => {
                const platform = platformConfig[item.platform];
                const format = formatConfig[item.format];
                const perf = performanceStyles[item.performance];
                
                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.03 }}
                    className="bg-card border border-border p-4 flex items-center gap-4 hover:border-primary/50 transition-all cursor-pointer"
                  >
                    {/* Thumbnail */}
                    <div className={`w-16 h-16 flex-shrink-0 ${gradientBgs[item.thumbnail as keyof typeof gradientBgs]} flex items-center justify-center`}>
                      <format.icon className="w-6 h-6 text-white/50" />
                    </div>
                    
                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium text-foreground truncate">{item.title}</h3>
                        <span className={`px-2 py-0.5 text-[10px] font-display ${statusStyles[item.status]}`}>
                          {item.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{item.description}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <platform.icon className={`w-3 h-3 ${platform.color}`} />
                          {item.platform}
                        </span>
                        <span>•</span>
                        <span>{format.label}</span>
                        <span>•</span>
                        <span className="text-accent">{item.sprinkleType}</span>
                      </div>
                    </div>
                    
                    {/* Metrics */}
                    {item.status === "published" && (
                      <div className="hidden md:flex items-center gap-6 text-center">
                        <div>
                          <p className="font-display text-sm text-foreground">{item.metrics.reach}</p>
                          <p className="text-[10px] text-muted-foreground">Reach</p>
                        </div>
                        <div>
                          <p className="font-display text-sm text-foreground">{item.metrics.engagement}</p>
                          <p className="text-[10px] text-muted-foreground">Engagement</p>
                        </div>
                        <div>
                          <p className="font-display text-sm text-foreground">{item.metrics.ctr}</p>
                          <p className="text-[10px] text-muted-foreground">CTR</p>
                        </div>
                        <span className={cn("px-2 py-1 text-[10px] font-display tracking-wide border", perf.class)}>
                          {perf.label}
                        </span>
                      </div>
                    )}
                    
                    {/* Trend */}
                    {item.status === "published" && (
                      <div className="flex-shrink-0">
                        {item.trend === "up" && <TrendingUp className="w-5 h-5 text-success" />}
                        {item.trend === "down" && <TrendingDown className="w-5 h-5 text-error" />}
                        {item.trend === "stable" && <span className="text-muted-foreground">—</span>}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
        )}
      </main>
    </div>
  );
}
