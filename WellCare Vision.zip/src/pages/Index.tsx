import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { ContentFlywheel } from "@/components/dashboard/ContentFlywheel";
import { RecentStories } from "@/components/dashboard/RecentStories";
import { ObservationHub } from "@/components/dashboard/ObservationHub";
import { PerformanceChart } from "@/components/dashboard/PerformanceChart";
import { BIPFramework } from "@/components/dashboard/BIPFramework";
import { TopContent } from "@/components/dashboard/TopContent";
import { CompetitorRadar } from "@/components/dashboard/CompetitorRadar";
import { Eye, Users, FileText, Target } from "lucide-react";

const metrics = [
  {
    title: "Total Reach",
    value: "847K",
    change: 23,
    changeLabel: "vs last period",
    icon: Eye,
    status: "success" as const,
  },
  {
    title: "Personas Activated",
    value: "12",
    change: 8,
    changeLabel: "of 18 total",
    icon: Users,
    status: "success" as const,
  },
  {
    title: "Content Live",
    value: "34",
    change: 15,
    changeLabel: "across 4 platforms",
    icon: FileText,
    status: "success" as const,
  },
  {
    title: "Conversion Rate",
    value: "4.2%",
    change: -2,
    changeLabel: "needs attention",
    icon: Target,
    status: "warning" as const,
  },
];

const Index = () => {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6 sunburst-pattern">
          {/* Page Title */}
          <div className="mb-6">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <span>HealthTech Expo India 2024</span>
              <span>·</span>
              <span>Healthcare Category</span>
            </div>
            <h1 className="font-display text-3xl tracking-wide text-foreground">
              CONTENT INTELLIGENCE HUB
            </h1>
            <p className="text-muted-foreground mt-1">
              Transform strategic intelligence into compelling healthcare narratives
            </p>
          </div>

          {/* Metric Cards Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {metrics.map((metric, index) => (
              <MetricCard key={metric.title} {...metric} index={index} />
            ))}
          </div>

          {/* Content Flywheel */}
          <div className="mb-6">
            <ContentFlywheel />
          </div>

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Left Column - Stories & Content */}
            <div className="lg:col-span-2 space-y-6">
              <RecentStories />
              <TopContent />
            </div>
            
            {/* Right Column - Intelligence */}
            <div className="space-y-6">
              <ObservationHub />
              <CompetitorRadar />
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PerformanceChart />
            <BIPFramework />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Index;