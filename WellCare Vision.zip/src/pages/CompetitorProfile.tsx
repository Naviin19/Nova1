import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowLeft, 
  TrendingUp, 
  TrendingDown,
  Minus,
  ExternalLink,
  Image,
  MessageSquare,
  BarChart3,
  Target,
  Calendar,
  Globe,
  Linkedin,
  Twitter,
  Facebook,
  Instagram,
  Play,
  Eye,
  ThumbsUp,
  Share2,
  AlertTriangle,
  CheckCircle,
  Sparkles,
  Building2,
  Users,
  DollarSign,
  Megaphone
} from "lucide-react";

interface CompetitorData {
  id: string;
  name: string;
  logo: string;
  category: string;
  description: string;
  headquarters: string;
  employees: string;
  revenue: string;
  marketShare: string;
  threatLevel: "high" | "medium" | "low";
  lastActivity: string;
  website: string;
  socialLinks: { platform: string; url: string; followers: string }[];
  adCreatives: AdCreative[];
  messagingAnalysis: MessagingAnalysis;
  trendData: TrendDataPoint[];
  keyStrengths: string[];
  keyWeaknesses: string[];
  recentMoves: RecentMove[];
}

interface AdCreative {
  id: string;
  title: string;
  type: "image" | "video" | "carousel";
  platform: string;
  thumbnail: string;
  engagement: { views: number; likes: number; shares: number };
  datePosted: string;
  cta: string;
  targeting: string;
}

interface MessagingAnalysis {
  primaryThemes: { theme: string; frequency: number }[];
  toneAnalysis: { tone: string; percentage: number }[];
  keyPhrases: string[];
  valuePropositions: string[];
  audienceSegments: string[];
  callToActions: string[];
}

interface TrendDataPoint {
  month: string;
  shareOfVoice: number;
  adSpend: number;
  engagement: number;
  ourShareOfVoice: number;
}

interface RecentMove {
  date: string;
  title: string;
  description: string;
  impact: "positive" | "negative" | "neutral";
}

const competitorDatabase: Record<string, CompetitorData> = {
  "siemens-healthineers": {
    id: "siemens-healthineers",
    name: "Siemens Healthineers",
    logo: "SH",
    category: "Medical Imaging & Diagnostics",
    description: "Global leader in medical technology with focus on diagnostic imaging, laboratory diagnostics, and advanced therapies.",
    headquarters: "Erlangen, Germany",
    employees: "69,500+",
    revenue: "$21.7B",
    marketShare: "24%",
    threatLevel: "high",
    lastActivity: "2 hours ago",
    website: "siemens-healthineers.com",
    socialLinks: [
      { platform: "LinkedIn", url: "#", followers: "1.2M" },
      { platform: "Twitter", url: "#", followers: "89K" },
      { platform: "Facebook", url: "#", followers: "456K" },
    ],
    adCreatives: [
      { id: "1", title: "AI-Powered Radiology Suite", type: "video", platform: "LinkedIn", thumbnail: "gradient-1", engagement: { views: 45000, likes: 2300, shares: 890 }, datePosted: "Jan 12, 2024", cta: "Request Demo", targeting: "Radiologists, Hospital Admins" },
      { id: "2", title: "Precision Medicine Campaign", type: "image", platform: "Facebook", thumbnail: "gradient-2", engagement: { views: 32000, likes: 1800, shares: 450 }, datePosted: "Jan 8, 2024", cta: "Learn More", targeting: "Oncologists, Research Directors" },
      { id: "3", title: "Remote Scanning Solutions", type: "carousel", platform: "Instagram", thumbnail: "gradient-3", engagement: { views: 28000, likes: 3200, shares: 670 }, datePosted: "Jan 5, 2024", cta: "Explore Features", targeting: "Rural Hospitals, Clinics" },
      { id: "4", title: "Syngo Virtual Cockpit", type: "video", platform: "LinkedIn", thumbnail: "gradient-4", engagement: { views: 67000, likes: 4100, shares: 1200 }, datePosted: "Dec 28, 2023", cta: "Watch Demo", targeting: "Hospital CIOs, IT Directors" },
      { id: "5", title: "Value-Based Care Outcomes", type: "image", platform: "Twitter", thumbnail: "gradient-5", engagement: { views: 19000, likes: 980, shares: 320 }, datePosted: "Dec 22, 2023", cta: "Download Report", targeting: "Healthcare Executives" },
      { id: "6", title: "Sustainability in Healthcare", type: "image", platform: "LinkedIn", thumbnail: "gradient-6", engagement: { views: 41000, likes: 2700, shares: 890 }, datePosted: "Dec 15, 2023", cta: "Read Story", targeting: "Procurement, Sustainability Officers" },
    ],
    messagingAnalysis: {
      primaryThemes: [
        { theme: "AI & Machine Learning", frequency: 34 },
        { theme: "Patient Outcomes", frequency: 28 },
        { theme: "Operational Efficiency", frequency: 22 },
        { theme: "Sustainability", frequency: 16 },
      ],
      toneAnalysis: [
        { tone: "Professional", percentage: 45 },
        { tone: "Innovative", percentage: 30 },
        { tone: "Empathetic", percentage: 15 },
        { tone: "Authoritative", percentage: 10 },
      ],
      keyPhrases: [
        "Pioneering breakthroughs",
        "AI-powered diagnostics",
        "Value-based healthcare",
        "Digital twin technology",
        "Precision medicine",
        "Remote collaboration"
      ],
      valuePropositions: [
        "Reduce diagnostic time by 40%",
        "Improve patient throughput",
        "Lower total cost of ownership",
        "Seamless integration with existing systems"
      ],
      audienceSegments: [
        "Hospital C-Suite Executives",
        "Radiologists & Imaging Specialists",
        "Healthcare IT Decision Makers",
        "Procurement & Supply Chain"
      ],
      callToActions: [
        "Request a Demo",
        "Download Whitepaper",
        "Speak to an Expert",
        "Calculate Your ROI"
      ]
    },
    trendData: [
      { month: "Aug", shareOfVoice: 22, adSpend: 850, engagement: 78, ourShareOfVoice: 18 },
      { month: "Sep", shareOfVoice: 24, adSpend: 920, engagement: 82, ourShareOfVoice: 17 },
      { month: "Oct", shareOfVoice: 23, adSpend: 880, engagement: 79, ourShareOfVoice: 19 },
      { month: "Nov", shareOfVoice: 26, adSpend: 1100, engagement: 85, ourShareOfVoice: 18 },
      { month: "Dec", shareOfVoice: 28, adSpend: 1250, engagement: 88, ourShareOfVoice: 20 },
      { month: "Jan", shareOfVoice: 27, adSpend: 1180, engagement: 86, ourShareOfVoice: 21 },
    ],
    keyStrengths: [
      "Market leader in diagnostic imaging",
      "Strong brand recognition globally",
      "Extensive R&D investment ($1.8B/year)",
      "Comprehensive service network"
    ],
    keyWeaknesses: [
      "Premium pricing limits SMB penetration",
      "Complex product portfolio",
      "Slower to adopt cloud-native solutions",
      "Regional gaps in emerging markets"
    ],
    recentMoves: [
      { date: "Jan 15, 2024", title: "Launched AI Companion for Cardiology", description: "New AI-powered decision support system for cardiac imaging analysis.", impact: "negative" },
      { date: "Jan 8, 2024", title: "Expanded Partnership with Epic", description: "Deeper EHR integration announced for seamless workflow.", impact: "negative" },
      { date: "Dec 20, 2023", title: "Price Reduction on Entry-Level CT", description: "10% price cut on Somatom Go series targeting mid-size hospitals.", impact: "negative" },
      { date: "Dec 5, 2023", title: "Sustainability Report Published", description: "Committed to carbon neutrality by 2030, gaining ESG-focused buyers.", impact: "neutral" },
    ]
  },
  "ge-healthcare": {
    id: "ge-healthcare",
    name: "GE HealthCare",
    logo: "GE",
    category: "Medical Technology",
    description: "Leading global medical technology company creating integrated solutions and services in imaging, ultrasound, patient care solutions, and pharmaceutical diagnostics.",
    headquarters: "Chicago, USA",
    employees: "51,000+",
    revenue: "$19.6B",
    marketShare: "21%",
    threatLevel: "high",
    lastActivity: "5 hours ago",
    website: "gehealthcare.com",
    socialLinks: [
      { platform: "LinkedIn", url: "#", followers: "980K" },
      { platform: "Twitter", url: "#", followers: "156K" },
      { platform: "Instagram", url: "#", followers: "78K" },
    ],
    adCreatives: [
      { id: "1", title: "Edison AI Platform", type: "video", platform: "LinkedIn", thumbnail: "gradient-7", engagement: { views: 52000, likes: 2800, shares: 920 }, datePosted: "Jan 14, 2024", cta: "Explore Edison", targeting: "Healthcare CIOs, Data Scientists" },
      { id: "2", title: "Rural Healthcare Access", type: "image", platform: "Facebook", thumbnail: "gradient-8", engagement: { views: 38000, likes: 2100, shares: 680 }, datePosted: "Jan 10, 2024", cta: "See Impact", targeting: "Rural Hospital Networks" },
      { id: "3", title: "Maternal Health Solutions", type: "carousel", platform: "Instagram", thumbnail: "gradient-9", engagement: { views: 45000, likes: 4500, shares: 1100 }, datePosted: "Jan 6, 2024", cta: "Learn More", targeting: "OB-GYN, Women's Health" },
      { id: "4", title: "Precision Care Pathways", type: "video", platform: "LinkedIn", thumbnail: "gradient-10", engagement: { views: 61000, likes: 3400, shares: 980 }, datePosted: "Jan 2, 2024", cta: "Watch Now", targeting: "Oncologists, Hospital Executives" },
    ],
    messagingAnalysis: {
      primaryThemes: [
        { theme: "Precision Care", frequency: 31 },
        { theme: "Digital Innovation", frequency: 27 },
        { theme: "Accessibility", frequency: 24 },
        { theme: "Workforce Solutions", frequency: 18 },
      ],
      toneAnalysis: [
        { tone: "Empowering", percentage: 40 },
        { tone: "Innovative", percentage: 28 },
        { tone: "Compassionate", percentage: 20 },
        { tone: "Technical", percentage: 12 },
      ],
      keyPhrases: [
        "Precision care for all",
        "Edison intelligence",
        "Connected ecosystem",
        "Clinician-first design",
        "Sustainable healthcare"
      ],
      valuePropositions: [
        "Improve diagnostic confidence",
        "Reduce clinician burnout",
        "Expand access to underserved",
        "Accelerate time to treatment"
      ],
      audienceSegments: [
        "Health System Executives",
        "Clinical Decision Makers",
        "Government Healthcare Programs",
        "Research Institutions"
      ],
      callToActions: [
        "Schedule Consultation",
        "View Case Studies",
        "Request Pricing",
        "Join Webinar"
      ]
    },
    trendData: [
      { month: "Aug", shareOfVoice: 19, adSpend: 720, engagement: 72, ourShareOfVoice: 18 },
      { month: "Sep", shareOfVoice: 21, adSpend: 780, engagement: 75, ourShareOfVoice: 17 },
      { month: "Oct", shareOfVoice: 22, adSpend: 850, engagement: 78, ourShareOfVoice: 19 },
      { month: "Nov", shareOfVoice: 20, adSpend: 800, engagement: 74, ourShareOfVoice: 18 },
      { month: "Dec", shareOfVoice: 23, adSpend: 920, engagement: 80, ourShareOfVoice: 20 },
      { month: "Jan", shareOfVoice: 24, adSpend: 980, engagement: 82, ourShareOfVoice: 21 },
    ],
    keyStrengths: [
      "Strong ultrasound portfolio",
      "Edison AI platform momentum",
      "Spin-off agility from GE",
      "Government contract expertise"
    ],
    keyWeaknesses: [
      "Brand perception still tied to GE conglomerate",
      "Fewer premium imaging offerings",
      "Service network gaps in Asia",
      "Debt from spin-off"
    ],
    recentMoves: [
      { date: "Jan 14, 2024", title: "Edison 3.0 Platform Launch", description: "Major update with 50+ new AI algorithms for imaging.", impact: "negative" },
      { date: "Jan 3, 2024", title: "Partnership with Tempus", description: "Collaboration on precision oncology data integration.", impact: "negative" },
      { date: "Dec 18, 2023", title: "Acquired Caption Health", description: "AI-guided ultrasound startup to democratize cardiac imaging.", impact: "negative" },
    ]
  },
  "philips-healthcare": {
    id: "philips-healthcare",
    name: "Philips Healthcare",
    logo: "PH",
    category: "Health Technology",
    description: "Health technology company focused on improving people's health and well-being through meaningful innovation across the health continuum.",
    headquarters: "Amsterdam, Netherlands",
    employees: "77,000+",
    revenue: "$18.2B",
    marketShare: "18%",
    threatLevel: "medium",
    lastActivity: "1 day ago",
    website: "philips.com/healthcare",
    socialLinks: [
      { platform: "LinkedIn", url: "#", followers: "890K" },
      { platform: "Twitter", url: "#", followers: "112K" },
      { platform: "Facebook", url: "#", followers: "234K" },
    ],
    adCreatives: [
      { id: "1", title: "Connected Care Vision", type: "video", platform: "LinkedIn", thumbnail: "gradient-11", engagement: { views: 34000, likes: 1900, shares: 560 }, datePosted: "Jan 11, 2024", cta: "Discover More", targeting: "Health System Leaders" },
      { id: "2", title: "Ambient Experience", type: "carousel", platform: "Instagram", thumbnail: "gradient-12", engagement: { views: 28000, likes: 3100, shares: 780 }, datePosted: "Jan 7, 2024", cta: "See Gallery", targeting: "Pediatric Hospitals, Patient Experience" },
      { id: "3", title: "Sleep & Respiratory Care", type: "image", platform: "Facebook", thumbnail: "gradient-13", engagement: { views: 42000, likes: 2400, shares: 890 }, datePosted: "Jan 4, 2024", cta: "Learn Solutions", targeting: "Sleep Specialists, Pulmonologists" },
    ],
    messagingAnalysis: {
      primaryThemes: [
        { theme: "Patient Experience", frequency: 35 },
        { theme: "Connected Care", frequency: 28 },
        { theme: "Workflow Optimization", frequency: 22 },
        { theme: "Home Healthcare", frequency: 15 },
      ],
      toneAnalysis: [
        { tone: "Caring", percentage: 42 },
        { tone: "Innovative", percentage: 25 },
        { tone: "Human-centered", percentage: 23 },
        { tone: "Professional", percentage: 10 },
      ],
      keyPhrases: [
        "Better care experiences",
        "Hospital to home",
        "Ambient intelligence",
        "Seamless care",
        "Health continuum"
      ],
      valuePropositions: [
        "Transform patient experience",
        "Enable care beyond hospital walls",
        "Reduce length of stay",
        "Support aging in place"
      ],
      audienceSegments: [
        "Patient Experience Officers",
        "Home Health Providers",
        "Sleep Medicine Specialists",
        "Hospital Designers & Architects"
      ],
      callToActions: [
        "Transform Your Care",
        "Watch Patient Stories",
        "Connect With Us",
        "Download Guide"
      ]
    },
    trendData: [
      { month: "Aug", shareOfVoice: 17, adSpend: 620, engagement: 68, ourShareOfVoice: 18 },
      { month: "Sep", shareOfVoice: 16, adSpend: 580, engagement: 65, ourShareOfVoice: 17 },
      { month: "Oct", shareOfVoice: 18, adSpend: 650, engagement: 70, ourShareOfVoice: 19 },
      { month: "Nov", shareOfVoice: 17, adSpend: 600, engagement: 67, ourShareOfVoice: 18 },
      { month: "Dec", shareOfVoice: 19, adSpend: 720, engagement: 72, ourShareOfVoice: 20 },
      { month: "Jan", shareOfVoice: 18, adSpend: 680, engagement: 70, ourShareOfVoice: 21 },
    ],
    keyStrengths: [
      "Strong patient monitoring portfolio",
      "Leading in ambient care solutions",
      "Home healthcare innovation",
      "Strong design-thinking culture"
    ],
    keyWeaknesses: [
      "Respironics recall impact on trust",
      "Reduced imaging investments",
      "Restructuring distractions",
      "Premium positioning limits volume"
    ],
    recentMoves: [
      { date: "Jan 11, 2024", title: "Ambient Experience 4.0", description: "New immersive imaging environment for reduced patient anxiety.", impact: "neutral" },
      { date: "Dec 28, 2023", title: "Hospital-at-Home Expansion", description: "Partnered with 15 new health systems for remote patient monitoring.", impact: "negative" },
    ]
  }
};

const gradientStyles: Record<string, string> = {
  "gradient-1": "from-healthcare-teal to-healthcare-navy",
  "gradient-2": "from-primary to-accent",
  "gradient-3": "from-accent to-healthcare-teal",
  "gradient-4": "from-healthcare-navy to-primary",
  "gradient-5": "from-healthcare-teal to-primary",
  "gradient-6": "from-primary to-healthcare-navy",
  "gradient-7": "from-accent to-primary",
  "gradient-8": "from-healthcare-navy to-healthcare-teal",
  "gradient-9": "from-primary to-healthcare-teal",
  "gradient-10": "from-healthcare-teal to-accent",
  "gradient-11": "from-healthcare-navy to-accent",
  "gradient-12": "from-accent to-healthcare-navy",
  "gradient-13": "from-primary to-accent",
};

const platformIcons: Record<string, React.ElementType> = {
  LinkedIn: Linkedin,
  Twitter: Twitter,
  Facebook: Facebook,
  Instagram: Instagram,
};

export default function CompetitorProfile() {
  const { competitorId, brandId } = useParams();
  const navigate = useNavigate();
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  
  const competitor = competitorId ? competitorDatabase[competitorId] : null;

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/auth');
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!competitor) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-2xl mb-4">Competitor not found</h1>
          <Button onClick={() => navigate(`/brand/${brandId}`)}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const formatNumber = (num: number) => {
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="h-16 border-b border-border bg-card/80 backdrop-blur-sm flex items-center px-6 sticky top-0 z-50"
      >
        <Button variant="ghost" size="icon" onClick={() => navigate(`/brand/${brandId}`)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="ml-4 flex items-center gap-3">
          <div className={`w-10 h-10 flex items-center justify-center font-display text-white ${
            competitor.threatLevel === "high" ? "bg-destructive" : 
            competitor.threatLevel === "medium" ? "bg-accent" : "bg-muted"
          }`}>
            {competitor.logo}
          </div>
          <div>
            <h1 className="font-display text-lg tracking-wide">{competitor.name}</h1>
            <p className="text-xs text-muted-foreground">{competitor.category}</p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className={`px-3 py-1 text-xs font-medium ${
            competitor.threatLevel === "high" ? "bg-destructive/20 text-destructive" : 
            competitor.threatLevel === "medium" ? "bg-accent/20 text-accent" : "bg-muted text-muted-foreground"
          }`}>
            {competitor.threatLevel.toUpperCase()} THREAT
          </span>
          <Button variant="outline" size="sm">
            <ExternalLink className="w-3 h-3 mr-2" />
            {competitor.website}
          </Button>
        </div>
      </motion.header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Overview Cards */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <div className="bg-card border border-border p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Building2 className="w-4 h-4" />
              <span className="text-xs">Headquarters</span>
            </div>
            <p className="font-medium text-sm">{competitor.headquarters}</p>
          </div>
          <div className="bg-card border border-border p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Users className="w-4 h-4" />
              <span className="text-xs">Employees</span>
            </div>
            <p className="font-medium text-sm">{competitor.employees}</p>
          </div>
          <div className="bg-card border border-border p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <DollarSign className="w-4 h-4" />
              <span className="text-xs">Revenue</span>
            </div>
            <p className="font-medium text-sm">{competitor.revenue}</p>
          </div>
          <div className="bg-card border border-border p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Target className="w-4 h-4" />
              <span className="text-xs">Market Share</span>
            </div>
            <p className="font-medium text-sm">{competitor.marketShare}</p>
          </div>
        </motion.div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-sidebar-accent border border-border p-1 h-auto">
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-4 py-2">
              <BarChart3 className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="creatives" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-4 py-2">
              <Image className="w-4 h-4 mr-2" />
              Ad Gallery
            </TabsTrigger>
            <TabsTrigger value="messaging" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-4 py-2">
              <MessageSquare className="w-4 h-4 mr-2" />
              Messaging
            </TabsTrigger>
            <TabsTrigger value="trends" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-4 py-2">
              <TrendingUp className="w-4 h-4 mr-2" />
              Trends
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Description & Social */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="lg:col-span-2 space-y-6"
              >
                <div className="bg-card border border-border p-6">
                  <h3 className="font-display text-lg mb-4">COMPANY OVERVIEW</h3>
                  <p className="text-muted-foreground leading-relaxed mb-6">{competitor.description}</p>
                  
                  <div className="flex flex-wrap gap-3">
                    {competitor.socialLinks.map((social) => {
                      const Icon = platformIcons[social.platform] || Globe;
                      return (
                        <a 
                          key={social.platform}
                          href={social.url}
                          className="flex items-center gap-2 px-3 py-2 bg-muted/50 hover:bg-muted transition-colors text-sm"
                        >
                          <Icon className="w-4 h-4" />
                          <span>{social.platform}</span>
                          <span className="text-muted-foreground">({social.followers})</span>
                        </a>
                      );
                    })}
                  </div>
                </div>

                {/* Recent Moves */}
                <div className="bg-card border border-border p-6">
                  <h3 className="font-display text-lg mb-4">RECENT COMPETITIVE MOVES</h3>
                  <div className="space-y-4">
                    {competitor.recentMoves.map((move, index) => (
                      <motion.div 
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className={`flex gap-4 p-4 border-l-4 ${
                          move.impact === "negative" ? "border-l-destructive bg-destructive/5" :
                          move.impact === "positive" ? "border-l-green-500 bg-green-500/5" :
                          "border-l-muted bg-muted/30"
                        }`}
                      >
                        <div className="flex-shrink-0">
                          {move.impact === "negative" ? (
                            <AlertTriangle className="w-5 h-5 text-destructive" />
                          ) : move.impact === "positive" ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <Minus className="w-5 h-5 text-muted-foreground" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs text-muted-foreground">{move.date}</span>
                          </div>
                          <h4 className="font-medium text-sm mb-1">{move.title}</h4>
                          <p className="text-sm text-muted-foreground">{move.description}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* SWOT-lite */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="space-y-6"
              >
                <div className="bg-card border border-border p-6">
                  <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    KEY STRENGTHS
                  </h3>
                  <ul className="space-y-2">
                    {competitor.keyStrengths.map((strength, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="w-1.5 h-1.5 bg-green-500 mt-2 flex-shrink-0" />
                        {strength}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-card border border-border p-6">
                  <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-accent" />
                    KEY WEAKNESSES
                  </h3>
                  <ul className="space-y-2">
                    {competitor.keyWeaknesses.map((weakness, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="w-1.5 h-1.5 bg-accent mt-2 flex-shrink-0" />
                        {weakness}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            </div>
          </TabsContent>

          {/* Ad Gallery Tab */}
          <TabsContent value="creatives">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-display text-xl">AD CREATIVE GALLERY</h3>
                <div className="flex gap-2">
                  {["All", "LinkedIn", "Facebook", "Instagram", "Twitter"].map((platform) => (
                    <Button 
                      key={platform} 
                      variant={platform === "All" ? "default" : "outline"} 
                      size="sm"
                    >
                      {platform}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {competitor.adCreatives.map((ad, index) => {
                  const PlatformIcon = platformIcons[ad.platform] || Globe;
                  return (
                    <motion.div
                      key={ad.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="bg-card border border-border overflow-hidden group hover:border-primary transition-colors"
                    >
                      {/* Thumbnail */}
                      <div className={`aspect-video bg-gradient-to-br ${gradientStyles[ad.thumbnail] || "from-muted to-muted-foreground"} relative`}>
                        {ad.type === "video" && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-12 h-12 bg-black/50 rounded-full flex items-center justify-center group-hover:bg-black/70 transition-colors">
                              <Play className="w-5 h-5 text-white ml-0.5" />
                            </div>
                          </div>
                        )}
                        {ad.type === "carousel" && (
                          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
                            {[1, 2, 3, 4].map((i) => (
                              <div key={i} className={`w-1.5 h-1.5 rounded-full ${i === 1 ? "bg-white" : "bg-white/50"}`} />
                            ))}
                          </div>
                        )}
                        <div className="absolute top-2 right-2">
                          <span className="px-2 py-1 bg-black/50 text-white text-xs flex items-center gap-1">
                            <PlatformIcon className="w-3 h-3" />
                            {ad.platform}
                          </span>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-4">
                        <h4 className="font-medium text-sm mb-2">{ad.title}</h4>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
                          <Calendar className="w-3 h-3" />
                          {ad.datePosted}
                        </div>

                        {/* Engagement */}
                        <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                          <span className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {formatNumber(ad.engagement.views)}
                          </span>
                          <span className="flex items-center gap-1">
                            <ThumbsUp className="w-3 h-3" />
                            {formatNumber(ad.engagement.likes)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Share2 className="w-3 h-3" />
                            {formatNumber(ad.engagement.shares)}
                          </span>
                        </div>

                        {/* Meta */}
                        <div className="flex flex-wrap gap-2">
                          <span className="px-2 py-1 bg-primary/10 text-primary text-xs">{ad.cta}</span>
                          <span className="px-2 py-1 bg-muted text-muted-foreground text-xs">{ad.targeting}</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </TabsContent>

          {/* Messaging Tab */}
          <TabsContent value="messaging">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              {/* Primary Themes */}
              <div className="bg-card border border-border p-6">
                <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                  <Megaphone className="w-5 h-5 text-primary" />
                  PRIMARY THEMES
                </h3>
                <div className="space-y-4">
                  {competitor.messagingAnalysis.primaryThemes.map((theme, i) => (
                    <div key={i}>
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span>{theme.theme}</span>
                        <span className="text-muted-foreground">{theme.frequency}%</span>
                      </div>
                      <div className="h-2 bg-muted overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${theme.frequency}%` }}
                          transition={{ duration: 0.8, delay: i * 0.1 }}
                          className="h-full bg-primary"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tone Analysis */}
              <div className="bg-card border border-border p-6">
                <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-healthcare-teal" />
                  TONE ANALYSIS
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  {competitor.messagingAnalysis.toneAnalysis.map((tone, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.1 }}
                      className="p-4 bg-muted/30 text-center"
                    >
                      <div className="text-2xl font-display text-primary mb-1">{tone.percentage}%</div>
                      <div className="text-xs text-muted-foreground">{tone.tone}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Key Phrases */}
              <div className="bg-card border border-border p-6">
                <h3 className="font-display text-lg mb-4">KEY PHRASES</h3>
                <div className="flex flex-wrap gap-2">
                  {competitor.messagingAnalysis.keyPhrases.map((phrase, i) => (
                    <motion.span
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="px-3 py-2 bg-healthcare-teal/10 text-healthcare-teal text-sm border border-healthcare-teal/20"
                    >
                      "{phrase}"
                    </motion.span>
                  ))}
                </div>
              </div>

              {/* Value Propositions */}
              <div className="bg-card border border-border p-6">
                <h3 className="font-display text-lg mb-4">VALUE PROPOSITIONS</h3>
                <ul className="space-y-3">
                  {competitor.messagingAnalysis.valuePropositions.map((prop, i) => (
                    <motion.li
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-center gap-3 text-sm"
                    >
                      <Sparkles className="w-4 h-4 text-accent flex-shrink-0" />
                      {prop}
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Audience Segments */}
              <div className="bg-card border border-border p-6">
                <h3 className="font-display text-lg mb-4">TARGET AUDIENCES</h3>
                <div className="grid grid-cols-2 gap-2">
                  {competitor.messagingAnalysis.audienceSegments.map((segment, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-center gap-2 p-3 bg-muted/30 text-sm"
                    >
                      <Users className="w-4 h-4 text-muted-foreground" />
                      {segment}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* CTAs */}
              <div className="bg-card border border-border p-6">
                <h3 className="font-display text-lg mb-4">CALL-TO-ACTIONS</h3>
                <div className="flex flex-wrap gap-2">
                  {competitor.messagingAnalysis.callToActions.map((cta, i) => (
                    <motion.span
                      key={i}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.1 }}
                      className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium"
                    >
                      {cta}
                    </motion.span>
                  ))}
                </div>
              </div>
            </motion.div>
          </TabsContent>

          {/* Trends Tab */}
          <TabsContent value="trends">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-6"
            >
              {/* Share of Voice Comparison */}
              <div className="bg-card border border-border p-6">
                <h3 className="font-display text-lg mb-6">SHARE OF VOICE TREND</h3>
                <div className="space-y-6">
                  {competitor.trendData.map((data, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground w-12">{data.month}</span>
                        <div className="flex-1 mx-4 flex gap-2 items-center">
                          <div className="flex-1 h-4 bg-muted overflow-hidden relative">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${data.shareOfVoice * 2}%` }}
                              transition={{ duration: 0.8, delay: index * 0.05 }}
                              className="h-full bg-destructive absolute left-0"
                            />
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${data.ourShareOfVoice * 2}%` }}
                              transition={{ duration: 0.8, delay: index * 0.05 + 0.2 }}
                              className="h-full bg-primary absolute left-0 opacity-60"
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-xs">
                          <span className="text-destructive">{competitor.name.split(" ")[0]}: {data.shareOfVoice}%</span>
                          <span className="text-primary">You: {data.ourShareOfVoice}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-6 mt-6 pt-6 border-t border-border">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-destructive" />
                    <span className="text-xs text-muted-foreground">{competitor.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-primary" />
                    <span className="text-xs text-muted-foreground">Your Brand</span>
                  </div>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-card border border-border p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-display text-sm">EST. AD SPEND</h4>
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  </div>
                  <div className="text-3xl font-display text-primary mb-2">
                    ${competitor.trendData[competitor.trendData.length - 1].adSpend}K
                  </div>
                  <p className="text-xs text-muted-foreground">Monthly average (Jan 2024)</p>
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center gap-2 text-sm">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <span className="text-green-500">+18%</span>
                      <span className="text-muted-foreground">vs 6 months ago</span>
                    </div>
                  </div>
                </div>

                <div className="bg-card border border-border p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-display text-sm">ENGAGEMENT INDEX</h4>
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  </div>
                  <div className="text-3xl font-display text-healthcare-teal mb-2">
                    {competitor.trendData[competitor.trendData.length - 1].engagement}
                  </div>
                  <p className="text-xs text-muted-foreground">Score out of 100</p>
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center gap-2 text-sm">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <span className="text-green-500">+10pts</span>
                      <span className="text-muted-foreground">vs 6 months ago</span>
                    </div>
                  </div>
                </div>

                <div className="bg-card border border-border p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-display text-sm">SOV DIFFERENTIAL</h4>
                    <TrendingDown className="w-4 h-4 text-destructive" />
                  </div>
                  <div className="text-3xl font-display text-destructive mb-2">
                    -{competitor.trendData[competitor.trendData.length - 1].shareOfVoice - competitor.trendData[competitor.trendData.length - 1].ourShareOfVoice}%
                  </div>
                  <p className="text-xs text-muted-foreground">Gap to close</p>
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex items-center gap-2 text-sm">
                      <TrendingUp className="w-4 h-4 text-green-500" />
                      <span className="text-green-500">Improving</span>
                      <span className="text-muted-foreground">was -8% in Aug</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
