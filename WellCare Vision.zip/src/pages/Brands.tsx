import { useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { 
  Sparkles, 
  Plus, 
  ArrowRight, 
  Building2, 
  Users, 
  FileText,
  TrendingUp,
  Settings,
  LogOut
} from "lucide-react";

interface Brand {
  id: string;
  name: string;
  category: string;
  logo: string;
  color: string;
  stats: {
    content: number;
    reach: string;
    personas: number;
  };
  status: "active" | "draft" | "review";
}

const brands: Brand[] = [
  {
    id: "careplus-hospitals",
    name: "CarePlus Hospital Network",
    category: "Hospital Management & Healthcare Services",
    logo: "CP",
    color: "bg-healthcare-teal",
    stats: { content: 45, reach: "1.2M", personas: 15 },
    status: "active"
  },
];

const statusStyles = {
  active: "bg-primary/20 text-primary border-primary/30",
  draft: "bg-muted text-muted-foreground border-border",
  review: "bg-accent/20 text-accent border-accent/30"
};

export default function Brands() {
  const navigate = useNavigate();
  const { user, logout, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/auth');
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="sticky top-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border"
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl tracking-wider">NOVA</span>
          </div>
          
          <div className="flex items-center gap-4">
            {user?.isAdmin && (
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" /> Admin Panel
              </Button>
            )}
            <div className="flex items-center gap-3 px-4 py-2 bg-card border border-border">
              <div className="w-8 h-8 bg-primary/20 flex items-center justify-center">
                <span className="text-xs font-bold text-primary">
                  {user?.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </span>
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Welcome Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="font-display text-4xl tracking-wide mb-3">
            WELCOME BACK, <span className="text-primary">{user?.name.split(' ')[0].toUpperCase()}</span>
          </h1>
          <p className="text-muted-foreground text-lg">
            Select a brand to manage its content intelligence hub
          </p>
        </motion.div>

        {/* Quick Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
        >
          {[
            { icon: Building2, label: "Total Brands", value: brands.length },
            { icon: FileText, label: "Active Content", value: brands.reduce((a, b) => a + b.stats.content, 0) },
            { icon: Users, label: "Total Personas", value: brands.reduce((a, b) => a + b.stats.personas, 0) },
            { icon: TrendingUp, label: "Combined Reach", value: "3.2M" },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 + index * 0.05 }}
              className="p-4 bg-card border border-border"
            >
              <stat.icon className="w-5 h-5 text-primary mb-2" />
              <p className="font-display text-2xl">{stat.value}</p>
              <p className="text-xs text-muted-foreground uppercase tracking-wide">{stat.label}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Section Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-xl tracking-wide">YOUR BRANDS</h2>
          <Button onClick={() => navigate('/brands/add')}>
            <Plus className="w-4 h-4 mr-2" /> Add Brand
          </Button>
        </div>

        {/* Brand Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {brands.map((brand, index) => (
            <motion.div
              key={brand.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.08, type: "spring", stiffness: 100 }}
              whileHover={{ y: -6, transition: { duration: 0.2, type: "spring", stiffness: 300 } }}
              onClick={() => navigate(`/brand/${brand.id}`)}
              className="group p-6 bg-card border border-border hover:border-primary/50 cursor-pointer transition-all duration-300 relative overflow-hidden"
            >
              {/* Hover Gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Brand Header */}
              <div className="flex items-start justify-between mb-6 relative z-10">
                <div className="flex items-center gap-4">
                  <motion.div 
                    className={`w-14 h-14 ${brand.color} flex items-center justify-center text-white font-display text-lg relative overflow-hidden`}
                    whileHover={{ scale: 1.05 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                    {brand.logo}
                  </motion.div>
                  <div>
                    <h3 className="font-medium text-foreground group-hover:text-primary transition-colors duration-300">
                      {brand.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{brand.category}</p>
                  </div>
                </div>
              </div>

              {/* Status Badge */}
              <div className="mb-6 relative z-10">
                <span className={`inline-flex items-center px-3 py-1 text-xs uppercase tracking-wide border ${statusStyles[brand.status]} transition-all duration-300`}>
                  <span className={`w-1.5 h-1.5 rounded-full mr-2 ${
                    brand.status === 'active' ? 'bg-primary animate-pulse' :
                    brand.status === 'review' ? 'bg-accent' : 'bg-muted-foreground'
                  }`} />
                  {brand.status}
                </span>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mb-6 relative z-10">
                {[
                  { value: brand.stats.content, label: "Content" },
                  { value: brand.stats.reach, label: "Reach" },
                  { value: brand.stats.personas, label: "Personas" }
                ].map((stat, i) => (
                  <motion.div 
                    key={stat.label}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 + index * 0.08 + i * 0.05 }}
                  >
                    <p className="font-display text-xl text-foreground group-hover:text-primary transition-colors duration-300">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </motion.div>
                ))}
              </div>

              {/* Action */}
              <div className="flex items-center justify-between pt-4 border-t border-border relative z-10">
                <span className="text-sm text-muted-foreground group-hover:text-primary transition-colors duration-300">
                  View Dashboard
                </span>
                <motion.div
                  animate={{ x: [0, 4, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 1 }}
                >
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
                </motion.div>
              </div>
              
              {/* Corner Accent */}
              <div className="absolute bottom-0 right-0 w-12 h-12 border-r-2 border-b-2 border-transparent group-hover:border-primary/30 transition-colors duration-500" />
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  );
}
