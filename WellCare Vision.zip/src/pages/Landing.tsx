import { Button } from "@/components/ui/button";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, Sparkles, Eye, BookOpen, BarChart3, Zap, Shield, Globe, ChevronDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect, useRef } from "react";

const features = [
  {
    icon: Eye,
    title: "Observation Hub",
    description: "Real-time market intelligence from customers, competitors, and industry trends.",
    gradient: "from-healthcare-teal to-healthcare-teal-light"
  },
  {
    icon: BookOpen,
    title: "Visitor Stories",
    description: "AI-generated narratives using BIP framework to engage your personas.",
    gradient: "from-healthcare-navy to-healthcare-navy-light"
  },
  {
    icon: BarChart3,
    title: "Performance Analytics",
    description: "Track content performance and optimize your healthcare marketing.",
    gradient: "from-primary to-healthcare-teal"
  },
  {
    icon: Zap,
    title: "Content Flywheel",
    description: "Continuous cycle of creation, publication, measurement, and learning.",
    gradient: "from-accent to-gold-light"
  },
];

const stats = [
  { value: "50+", label: "Healthcare Brands" },
  { value: "2M+", label: "Audience Reach" },
  { value: "98%", label: "Client Retention" },
  { value: "24/7", label: "Real-time Intel" },
];

export default function Landing() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });
  
  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95]);
  const heroY = useTransform(scrollYProgress, [0, 0.5], [0, 50]);

  useEffect(() => {
    if (user) {
      navigate('/brands');
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Navbar */}
      <motion.nav 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="fixed top-0 left-0 right-0 z-50 bg-background/70 backdrop-blur-xl border-b border-border/50"
      >
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <motion.div 
            className="flex items-center gap-3"
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 400 }}
          >
            <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl tracking-wider">NOVA</span>
          </motion.div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate('/auth')} className="hidden sm:flex">
              Sign In
            </Button>
            <Button onClick={() => navigate('/auth')} className="btn-premium">
              Get Started <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section ref={heroRef} className="pt-32 pb-20 px-6 sunburst-pattern relative min-h-screen flex flex-col justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background pointer-events-none" />
        
        {/* Floating Elements */}
        <motion.div 
          className="absolute top-40 left-10 w-32 h-32 bg-primary/10 blur-3xl"
          animate={{ 
            x: [0, 30, 0],
            y: [0, -20, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div 
          className="absolute bottom-40 right-10 w-48 h-48 bg-accent/10 blur-3xl"
          animate={{ 
            x: [0, -20, 0],
            y: [0, 30, 0],
            scale: [1, 1.2, 1]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
        
        <motion.div 
          style={{ opacity: heroOpacity, scale: heroScale, y: heroY }}
          className="max-w-7xl mx-auto relative"
        >
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-4xl mx-auto"
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/20 mb-8 backdrop-blur-sm"
            >
              <Shield className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary">Trusted by Leading Healthcare Enterprises</span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="font-display text-5xl md:text-7xl tracking-wide leading-tight mb-6"
            >
              TRANSFORM <span className="text-gradient">INTELLIGENCE</span>
              <br />INTO IMPACT
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10"
            >
              NOVA turns strategic market observations into compelling healthcare content 
              that resonates with your audience and drives measurable results.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button size="lg" className="text-lg px-8 btn-premium group" onClick={() => navigate('/auth')}>
                Start Your Journey 
                <motion.span
                  className="ml-2"
                  animate={{ x: [0, 4, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <ArrowRight className="w-5 h-5" />
                </motion.span>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 hover-lift">
                <Globe className="mr-2 w-5 h-5" /> Watch Demo
              </Button>
            </motion.div>
          </motion.div>

          {/* Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7 + index * 0.1, type: "spring", stiffness: 200 }}
                whileHover={{ scale: 1.03, y: -2 }}
                className="text-center p-6 bg-card/80 backdrop-blur-sm border border-border card-premium"
              >
                <motion.div 
                  className="font-display text-4xl text-primary mb-2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                >
                  {stat.value}
                </motion.div>
                <div className="text-sm text-muted-foreground uppercase tracking-wide">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
        
        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="flex flex-col items-center gap-2 text-muted-foreground"
          >
            <span className="text-xs uppercase tracking-widest">Scroll</span>
            <ChevronDown className="w-5 h-5" />
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-6 bg-card/30 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background pointer-events-none" />
        <div className="max-w-7xl mx-auto relative">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <motion.span 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-primary text-sm uppercase tracking-widest mb-4 block"
            >
              Features
            </motion.span>
            <h2 className="font-display text-4xl tracking-wide mb-4">
              POWERED BY <span className="text-gradient">INTELLIGENCE</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              From observation to publication, NOVA provides the complete toolkit for 
              healthcare marketing excellence.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ y: -4 }}
                className="group p-8 bg-card border border-border hover:border-primary/50 transition-all duration-300 relative overflow-hidden"
              >
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />
                
                <motion.div 
                  className="w-14 h-14 bg-primary/10 flex items-center justify-center mb-6 relative z-10"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <feature.icon className="w-7 h-7 text-primary" />
                </motion.div>
                <h3 className="font-display text-xl tracking-wide mb-3 relative z-10">{feature.title}</h3>
                <p className="text-muted-foreground relative z-10">{feature.description}</p>
                
                {/* Corner Accent */}
                <div className="absolute bottom-0 right-0 w-16 h-16 border-r-2 border-b-2 border-primary/20 group-hover:border-primary/40 transition-colors" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6 sunburst-pattern relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent pointer-events-none" />
        
        {/* Decorative Elements */}
        <motion.div 
          className="absolute top-20 left-1/4 w-px h-32 bg-gradient-to-b from-transparent via-primary/30 to-transparent"
          initial={{ scaleY: 0 }}
          whileInView={{ scaleY: 1 }}
          viewport={{ once: true }}
        />
        <motion.div 
          className="absolute top-10 right-1/4 w-px h-48 bg-gradient-to-b from-transparent via-accent/30 to-transparent"
          initial={{ scaleY: 0 }}
          whileInView={{ scaleY: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto text-center relative"
        >
          <motion.div
            animate={{ 
              rotate: [0, 360],
              scale: [1, 1.1, 1]
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute -top-20 left-1/2 -translate-x-1/2 w-40 h-40 border border-primary/10 rounded-full"
          />
          
          <motion.div
            whileHover={{ scale: 1.1, rotate: 10 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Sparkles className="w-14 h-14 text-primary mx-auto mb-6" />
          </motion.div>
          <h2 className="font-display text-4xl md:text-5xl tracking-wide mb-6">
            READY TO ELEVATE YOUR
            <br />
            <span className="text-gradient">HEALTHCARE MARKETING?</span>
          </h2>
          <p className="text-muted-foreground text-lg mb-10">
            Join leading healthcare enterprises using NOVA to transform market intelligence 
            into compelling content that drives results.
          </p>
          <Button size="lg" className="text-lg px-10 btn-premium" onClick={() => navigate('/auth')}>
            Get Started Free <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-border/50 bg-card/30">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <motion.div 
            className="flex items-center gap-3"
            whileHover={{ scale: 1.02 }}
          >
            <div className="w-8 h-8 bg-primary flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display tracking-wider">NOVA</span>
          </motion.div>
          <div className="flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#" className="link-underline hover:text-foreground transition-colors">Privacy</a>
            <a href="#" className="link-underline hover:text-foreground transition-colors">Terms</a>
            <a href="#" className="link-underline hover:text-foreground transition-colors">Contact</a>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2024 NOVA Healthcare Intelligence
          </p>
        </div>
      </footer>
    </div>
  );
}
