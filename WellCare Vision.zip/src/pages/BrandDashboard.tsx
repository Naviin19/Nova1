import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { ContentFlywheel } from "@/components/dashboard/ContentFlywheel";
import { RecentStories } from "@/components/dashboard/RecentStories";
import { ObservationHub } from "@/components/dashboard/ObservationHub";
import { PerformanceChart } from "@/components/dashboard/PerformanceChart";
import { BIPFramework } from "@/components/dashboard/BIPFramework";
import { TopContent } from "@/components/dashboard/TopContent";
import { CompetitorRadar } from "@/components/dashboard/CompetitorRadar";
import { VisitorStoryCreator } from "@/components/dashboard/VisitorStoryCreator";
import { StoryToContentGenerator } from "@/components/dashboard/StoryToContentGenerator";
import { ContentBriefGenerator } from "@/components/dashboard/ContentBriefGenerator";
import { PersonasSection } from "@/components/dashboard/PersonasSection";
import { CreateTab } from "@/components/dashboard/flywheel/CreateTab";
import { PublishTab } from "@/components/dashboard/flywheel/PublishTab";
import { MeasureTab } from "@/components/dashboard/flywheel/MeasureTab";
import { LearnTab } from "@/components/dashboard/flywheel/LearnTab";
import { 
  Sparkles, 
  ArrowLeft, 
  Eye, 
  Users, 
  FileText, 
  Target,
  LayoutDashboard,
  BookOpen,
  BarChart3,
  Building2,
  Settings,
  Bell,
  Search,
  ChevronDown,
  PenTool,
  Send,
  Lightbulb,
  Heart,
  Activity
} from "lucide-react";

const brandData: Record<string, { name: string; category: string; logo: string; color: string; tagline: string }> = {
  "careplus-hospitals": { 
    name: "CarePlus Hospital Network", 
    category: "Hospital Management & Healthcare Services", 
    logo: "CP", 
    color: "bg-healthcare-teal",
    tagline: "Excellence in Healthcare, Compassion in Care"
  },
};

// CarePlus specific metrics
const metrics = [
  { title: "Personas Active", value: "6", change: 100, changeLabel: "fully configured", icon: Users, status: "success" as const },
  { title: "Content Published", value: "156", change: 28, changeLabel: "this quarter", icon: FileText, status: "success" as const },
  { title: "Patient Satisfaction", value: "4.6/5", change: 7, changeLabel: "+0.3 vs last year", icon: Activity, status: "success" as const },
];

const navItems = [
  { id: "overview", icon: LayoutDashboard, label: "Overview" },
  { id: "personas", icon: Users, label: "Personas" },
  { id: "create", icon: PenTool, label: "Create" },
  { id: "publish", icon: Send, label: "Publish" },
  { id: "measure", icon: BarChart3, label: "Measure" },
  { id: "learn", icon: Lightbulb, label: "Learn" },
  { id: "observations", icon: Eye, label: "Observations" },
  { id: "stories", icon: BookOpen, label: "Visitor Stories" },
  { id: "brand", icon: Building2, label: "Brand Book" },
  { id: "settings", icon: Settings, label: "Settings" },
];

export default function BrandDashboard() {
  const { brandId } = useParams();
  const navigate = useNavigate();
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  
  const brand = brandId ? brandData[brandId] : null;

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/auth');
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!brand) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-2xl mb-4">Brand not found</h1>
          <Button onClick={() => navigate('/brands')}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Brands
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <motion.aside 
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="w-72 h-screen bg-sidebar border-r border-sidebar-border flex flex-col sticky top-0"
      >
        {/* Logo */}
        <div className="p-6 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary flex items-center justify-center glow-teal">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-xl tracking-wider text-foreground">NOVA</h1>
              <p className="text-xs text-muted-foreground tracking-wide">HEALTHCARE INTEL</p>
            </div>
          </div>
        </div>

        {/* Brand Selector */}
        <div className="px-4 py-4 border-b border-sidebar-border">
          <button 
            onClick={() => navigate('/brands')}
            className="w-full flex items-center justify-between px-3 py-2 bg-sidebar-accent text-sidebar-foreground text-sm hover:bg-muted transition-colors"
          >
            <div className="flex items-center gap-2">
              <div className={`w-6 h-6 ${brand.color} flex items-center justify-center`}>
                <span className="text-xs font-bold text-white">{brand.logo[0]}</span>
              </div>
              <span className="truncate">{brand.name}</span>
            </div>
            <ChevronDown className="w-4 h-4 flex-shrink-0" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item, index) => (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * index, duration: 0.3 }}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-all duration-200 ${
                activeTab === item.id
                  ? "bg-sidebar-accent text-foreground border-l-[3px] border-l-accent"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-foreground border-l-[3px] border-l-transparent"
              }`}
            >
              <item.icon className="w-4 h-4" />
              <span>{item.label}</span>
            </motion.button>
          ))}
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-8 h-8 bg-healthcare-teal/20 flex items-center justify-center">
              <span className="text-xs font-bold text-healthcare-teal">
                {user?.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-foreground truncate">{user?.name}</p>
              <p className="text-xs text-muted-foreground truncate">
                {user?.isAdmin ? "Administrator" : "Marketing Lead"}
              </p>
            </div>
          </div>
        </div>
      </motion.aside>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <motion.header 
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="h-16 border-b border-border bg-card/50 backdrop-blur-sm flex items-center justify-between px-6 sticky top-0 z-40"
        >
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/brands')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="relative hidden sm:block">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input 
                type="text" 
                placeholder="Search observations, content, personas..."
                className="w-80 h-9 pl-10 pr-4 bg-sidebar-accent border-0 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-4 h-4" />
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-accent text-[10px] text-white flex items-center justify-center">
                3
              </span>
            </Button>
            <Button>
              <Sparkles className="w-4 h-4 mr-2" /> Generate Content
            </Button>
          </div>
        </motion.header>
        
        <main className="flex-1 overflow-y-auto p-6 sunburst-pattern">
          {/* Page Title */}
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <span>{brand.name}</span>
              <span>·</span>
              <span>{brand.category}</span>
            </div>
            <h1 className="font-display text-3xl tracking-wide text-foreground">
              {activeTab === "overview" && "CONTENT INTELLIGENCE HUB"}
              {activeTab === "personas" && "HEALTHCARE PERSONAS"}
              {activeTab === "create" && "CREATE CONTENT"}
              {activeTab === "publish" && "PUBLISH & SCHEDULE"}
              {activeTab === "measure" && "MEASURE PERFORMANCE"}
              {activeTab === "learn" && "LEARN & OPTIMIZE"}
              {activeTab === "observations" && "OBSERVATION HUB"}
              {activeTab === "stories" && "VISITOR STORIES"}
              {activeTab === "content" && "CONTENT LIBRARY"}
              {activeTab === "brand" && "BRAND BOOK"}
              {activeTab === "settings" && "SETTINGS"}
            </h1>
            <p className="text-muted-foreground mt-1">
              {brand.tagline || "Transform strategic intelligence into compelling healthcare narratives"}
            </p>
          </motion.div>

          <AnimatePresence mode="wait">
            {activeTab === "overview" && (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  {metrics.map((metric, index) => (
                    <MetricCard key={metric.title} {...metric} index={index} />
                  ))}
                </div>
                <div className="mb-6">
                  <ContentFlywheel 
                    onStageClick={(stageId) => setActiveTab(stageId)} 
                    activeStage={activeTab}
                  />
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                  <div className="lg:col-span-2 space-y-6">
                    <RecentStories />
                    <TopContent />
                  </div>
                  <div className="space-y-6">
                    <ObservationHub brandId={brandId} />
                    <CompetitorRadar />
                  </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <PerformanceChart />
                  <BIPFramework />
                </div>
              </motion.div>
            )}

            {activeTab === "personas" && (
              <motion.div
                key="personas"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <PersonasSection />
              </motion.div>
            )}

            {activeTab === "create" && <CreateTab />}
            {activeTab === "publish" && <PublishTab />}
            {activeTab === "measure" && <MeasureTab />}
            {activeTab === "learn" && <LearnTab />}

            {activeTab === "observations" && (
              <motion.div
                key="observations"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid grid-cols-1 lg:grid-cols-2 gap-6"
              >
                <ObservationHub brandId={brandId} />
                <CompetitorRadar />
              </motion.div>
            )}

            {activeTab === "stories" && (
              <motion.div
                key="stories"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  <VisitorStoryCreator onStoryComplete={(story) => console.log('Story:', story)} />
                  <StoryToContentGenerator />
                </div>
                <ContentBriefGenerator />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <RecentStories />
                  <BIPFramework />
                </div>
              </motion.div>
            )}

            {activeTab === "brand" && (
              <motion.div
                key="brand"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-card border border-border p-8"
              >
                <div className="flex items-center gap-4 mb-8">
                  <div className={`w-20 h-20 ${brand.color} flex items-center justify-center text-white font-display text-2xl`}>
                    {brand.logo}
                  </div>
                  <div>
                    <h2 className="font-display text-2xl">{brand.name}</h2>
                    <p className="text-muted-foreground">{brand.category}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-display text-lg mb-4">BRAND COLORS</h3>
                    <div className="flex gap-3">
                      <div className="w-12 h-12 bg-healthcare-teal" />
                      <div className="w-12 h-12 bg-healthcare-navy" />
                      <div className="w-12 h-12 bg-accent" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-display text-lg mb-4">BRAND VOICE</h3>
                    <p className="text-muted-foreground text-sm">
                      Professional, Trustworthy, Innovative, Patient-Centric
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === "settings" && (
              <motion.div
                key="settings"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-card border border-border p-8"
              >
                <h2 className="font-display text-xl mb-6">BRAND SETTINGS</h2>
                <p className="text-muted-foreground">
                  Configure your brand settings, integrations, and team permissions.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
